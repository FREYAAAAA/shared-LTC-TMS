//
//  FAboutUsVC.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/10/12.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import MessageUI
import FirebaseDatabase

class CNAAboutUsVC: UIViewController, MFMailComposeViewControllerDelegate, UITextViewDelegate, UITableViewDelegate, UITableViewDataSource{
    
    var sponsorlist = [event]()
    
    @IBOutlet weak var SponsorListTBV: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sponsorlist.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as! sponsorlistTBV
        cell.textLabel?.text = sponsorlist[indexPath.row].mission
        cell.detailTextLabel?.text = sponsorlist[indexPath.row].url1
        
        if let sponsorImageUrl = sponsorlist[indexPath.row].url{
            let url = URL(string: sponsorImageUrl)
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                if error != nil{
                    print(error!)
                    return
                }
                DispatchQueue.main.async {
                    cell.sponsorImage.image = UIImage(data: data!)
                }
                }.resume()
            
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let website = sponsorlist[indexPath.row].url1
        UIApplication.shared.open(URL(string: website!)!, options: [:], completionHandler: nil)
    }
    
    
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let CNAhomepage = storyboard?.instantiateViewController(withIdentifier: "CNAVC") as? CNAVC
        CNAhomepage?.myID = self.UID.text!
        self.present(CNAhomepage!, animated: false, completion: nil)
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var HBpage: UIStackView!
    @IBAction func HamburgerPageIcon(_ sender: UIButton) {
        if(HBpage.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.HBpage.window!.layer.add(transition, forKey: kCATransition)
            
            HBpage.isHidden = false
        }
        else{
            HBpage.isHidden = true
        }
    }
    @IBAction func Portfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "PortfolioVC") as? PortfolioVC
        portfoliopage?.myID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func Task(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionVC") as? TaskInstructionVC
        taskpage?.myID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func workingschedule(_ sender: UIButton) {
        let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "WorkingScheduleVC") as? WorkingScheduleVC
        workingschedulepage?.myID3 = self.UID.text!
        self.present(workingschedulepage!, animated: false, completion: nil)
    }
    @IBAction func workinghour(_ sender: UIButton) {
        let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "WorkingHourVC") as? WorkingHourVC
        workinghourpage?.myID4 = self.UID.text!
        self.present(workinghourpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "CNAAboutUsVC") as? CNAAboutUsVC
        aboutuspage?.CNAAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "help_support") as? help_support
        helpmenu?.myID5 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        
        DoubleConfirm(userMessage: "Are you sure to logout?")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "OK", style: .default, handler:{(action) in
            
            if UserDefaults.standard.bool(forKey: "test") == true{
                UserDefaults.standard.set(false, forKey: "test")
            }
            UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
            UserDefaults.standard.set(false, forKey: "AutoLoginON")
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.CNAAboutmyID).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CNAAboutmyID).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    //Call, Email bottom, Google Map
    @IBAction func CallBottom(_ sender: UIButton) {
        let url : NSURL = URL(string: "TEL://123456789")! as NSURL
        UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
    }
    @IBAction func EmailBottom(_ sender: UIButton) {
        let mailsend = MFMailComposeViewController()
        mailsend.mailComposeDelegate = self
        mailsend.setToRecipients(["raymond159357@gmail.com"])
        mailsend.setSubject("Test")
        
        if MFMailComposeViewController.canSendMail(){
            self.present(mailsend, animated: true, completion: nil)
        }
        else{
            print("NO")
        }
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    @IBAction func goGoogle(_ sender: UIButton) {
        UIApplication.shared.open(URL(string: "https://www.google.com.tw/maps/place/%E9%8A%98%E5%82%B3%E5%A4%A7%E5%AD%B8+%E6%A1%83%E5%9C%92%E6%A0%A1%E5%8D%80/@24.985171,121.339809,17z/data=!4m8!1m2!2m1!1z6YqY5YKz5aSn5a24!3m4!1s0x34681e8f88001f51:0xde8e62ebe5442d75!8m2!3d24.9844926!4d121.3423688")!, options: [:], completionHandler: nil)
    }
    
    
    
    @IBOutlet weak var UID: UILabel!
    var CNAAboutmyID = String()
    
    @IBOutlet weak var descriptionBox: UITextView!
    @IBOutlet weak var CenterName: UILabel!
    @IBOutlet weak var CenterEmail: UILabel!
    @IBOutlet weak var CenterContactNo: UILabel!
    @IBOutlet weak var CenterAddress: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.UID.text = CNAAboutmyID
        
        fetchsponsor()
        
        //Description
        Database.database().reference().child("CenterInformation").child("ContactInfo").child("Aboutus").observe(.value, with: { (snapshot) in
            self.descriptionBox.text = snapshot.value as? String
        }, withCancel: nil)
        
        //Info
        Database.database().reference().child("CenterInformation").child("ContactInfo").observe(.childAdded, with: { (snapshot) in
            if snapshot.key == "Name"{
                self.CenterName.text = "\(snapshot.key) : \(snapshot.value as! String)"
            }else if snapshot.key == "Email"{
                self.CenterEmail.text = "\(snapshot.key) : \(snapshot.value as! String)"
            }else if snapshot.key == "Contact No"{
                self.CenterContactNo.text = "\(snapshot.key) : \(snapshot.value as! String)"
            }else if snapshot.key == "Address"{
                self.CenterAddress.text = "\(snapshot.key) : \(snapshot.value as! String)"
            }
        }, withCancel: nil)
        
        SponsorListTBV.register(sponsorlistTBV.self, forCellReuseIdentifier: "cellID")
    }
    
    func fetchsponsor(){
        Database.database().reference().child("CenterInformation").child("Sponsor").observe(.childAdded, with: { (snapshot1) in
            let sponsorURL = event()
            sponsorURL.mission = snapshot1.key
            
            if snapshot1.hasChildren(){
                for snap in snapshot1.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        if tag == "photo"{
                            let Imageurl = node.value as? String
                            sponsorURL.url = Imageurl!
                        }else if tag == "url"{
                            let weburl = node.value as? String
                            sponsorURL.url1 = weburl!
                        }
                    }
                }
                self.sponsorlist.append(sponsorURL)
                self.SponsorListTBV.reloadData()
            }
        }, withCancel: nil)
    }
    
    
}

class CNAsponsorlistTBV: UITableViewCell {
    override func layoutSubviews() {
        super .layoutSubviews()
        
        textLabel?.frame = CGRect(x: 56, y: textLabel!.frame.origin.y, width: textLabel!.frame.width, height: textLabel!.frame.height)
        detailTextLabel?.frame = CGRect(x: 56, y: detailTextLabel!.frame.origin.y, width: detailTextLabel!.frame.width, height: detailTextLabel!.frame.height)
    }
    
    let sponsorImage: UIImageView = {
        let imageview = UIImageView()
        imageview.translatesAutoresizingMaskIntoConstraints = false
        imageview.layer.cornerRadius = 20
        imageview.layer.masksToBounds = true
        return imageview
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
        
        addSubview(sponsorImage)
        
        sponsorImage.leftAnchor.constraint(equalTo: leftAnchor, constant: 8).isActive = true
        sponsorImage.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        sponsorImage.widthAnchor.constraint(equalToConstant: 40).isActive = true
        sponsorImage.heightAnchor.constraint(equalToConstant: 40).isActive = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}
