//
//  ViewController.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/8/2.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {
    
    var ref:DatabaseReference!

    @IBOutlet weak var UserIDTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    
    
    @IBAction func LoginBottom(_ sender: UIButton) {
        
        ref = Database.database().reference()
        
        let userID = UserIDTextField.text;
        let userPassword = PasswordTextField.text;
        
        //if the TextFields are empty or not
        if((userID?.isEmpty)! || (userPassword?.isEmpty)!){
            self.alertMessage(userMessage: "All fields are required.")
            return;
        }
        
        //if id or password correct or not
        else{
            ref.child("CNAuserset").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
                if userPassword == snapshot.value as? String{
                    
                }
                else{
                    self.alertMessage(userMessage: "Wrong ID or Password!")
                }
            }, withCancel: nil)
     
        }

    }
    
    
    
    
    func alertMessage(userMessage: String){
        let alert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: .alert)
        let okaction = UIAlertAction(title: "ok", style: .default, handler: nil)
        alert.addAction(okaction)
        self.present(alert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

