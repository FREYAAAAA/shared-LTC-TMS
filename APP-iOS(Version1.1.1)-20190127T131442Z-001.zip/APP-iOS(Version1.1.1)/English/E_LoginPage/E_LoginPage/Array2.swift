//
//  Array2.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/9/22.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit

class typeAry2: NSObject {
    var typeAry:String!
    var Ary2:String!
}
