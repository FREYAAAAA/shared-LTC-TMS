//
//  Array1.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/9/22.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit
class array1: NSObject {
    var typesTask: String!
    var list2: String!
}
