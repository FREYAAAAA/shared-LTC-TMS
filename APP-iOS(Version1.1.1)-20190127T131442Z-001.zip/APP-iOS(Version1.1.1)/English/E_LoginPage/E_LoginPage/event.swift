//
//  event.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/8/22.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit

class event: NSObject {
    var mission: String!
    var url: String!
    var url1: String!
}

