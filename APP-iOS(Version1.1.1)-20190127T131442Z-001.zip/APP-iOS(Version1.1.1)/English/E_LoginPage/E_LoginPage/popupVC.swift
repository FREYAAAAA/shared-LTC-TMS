//
//  popupVC.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/10/11.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class popupVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var detaillist = [event]()

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return detaillist.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath)
        cell.textLabel?.text = detaillist[indexPath.row].url
        cell.textLabel?.numberOfLines = 0
        
        return cell
    }
    
    var detailidentify = String()
    @IBOutlet weak var detailTBV: UITableView!
    func fetchdata(){
        if detailidentify == "1"{
            Database.database().reference().child("Patient").child(FmyIDpop).child(datepop).child("daily_status").observe(.childAdded, with: { (snapshot) in
                let SBdetail = event()
                SBdetail.mission = snapshot.key
//                SBdetail.url = snapshot.value as? String
                
                var detailKeyArr = SBdetail.mission.components(separatedBy: "_")
                let feces = detailKeyArr[0]
                
                
                if feces == "feces"{
                    let finaldata = (snapshot.value as! String).replacingOccurrences(of: "\"" , with: "")
                    SBdetail.url = "\(detailKeyArr[1])  \(finaldata)"
                    
                    self.detaillist.append(SBdetail)
                }
                
//                self.detaillist.append(SBdetail)
                self.detailTBV.reloadData()
            }, withCancel: nil)
        }else if detailidentify == "2"{
            Database.database().reference().child("Patient").child(FmyIDpop).child(datepop).child("daily_status").observe(.childAdded, with: { (snapshot) in
                let oxygendetail = event()
                oxygendetail.mission = snapshot.key
                
                var oxygendetailArr = oxygendetail.mission.components(separatedBy: "_")
                
                if oxygendetailArr[0] == "oxygen"{
                    let finaldata = (snapshot.value as! String).replacingOccurrences(of: "\"", with: "")
                    oxygendetail.url = "\(oxygendetailArr[2])  \(finaldata)"
                    
                    self.detaillist.append(oxygendetail)
                    self.detailTBV.reloadData()
                }
            }, withCancel: nil)
        }else if detailidentify == "3"{
            Database.database().reference().child("Patient").child(FmyIDpop).child(datepop).child("daily_status").observe(.childAdded, with: { (snapshot) in
                let steamdetail = event()
                steamdetail.mission = snapshot.key
                
                var steamdetailArr = steamdetail.mission.components(separatedBy: "_")
                
                if steamdetailArr[0] == "steam"{
                    let finaldata = (snapshot.value as! String).replacingOccurrences(of: "\"", with: "")
                    steamdetail.url = "\(steamdetailArr[2])  \(finaldata)"
                    
                    self.detaillist.append(steamdetail)
                    self.detailTBV.reloadData()
                }
            }, withCancel: nil)
        }
        
    }
    
    @IBAction func popupoff(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    //for passing data
    var FmyIDpop = String()
    var datepop = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchdata()
    }

}
