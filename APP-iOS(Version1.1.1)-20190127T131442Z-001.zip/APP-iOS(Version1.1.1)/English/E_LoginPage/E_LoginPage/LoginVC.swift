//
//  LoginViewController.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/8/2.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase
import MessageUI

class LoginVC: UIViewController, MFMailComposeViewControllerDelegate {
    
    var ref:DatabaseReference!

    @IBOutlet weak var UserIDTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    
    
    @IBAction func LoginBottom(_ sender: UIButton) {
        
        ref = Database.database().reference()
        
        let userID = UserIDTextField.text;
        let userPassword = PasswordTextField.text;
        
        //if the TextFields are empty or not
        if((userID?.isEmpty)! || (userPassword?.isEmpty)!){
            self.alertMessage(userMessage: "All fields are required.")
            return;
        }
        
        //if ID or password correct or not
        else{
            self.ref.child("CNA").child(userID!).child("Portfolio").child("Password").observeSingleEvent(of: .value, with: { (snapshot) in
                if userPassword == (snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""){
                    
                    //policy
                    let message = "1. Do not try to modify the app.\n2. Please protect the patient's privacy.\n3. Please read the system Policy.\nThank you!"
                    let alert = UIAlertController(title: "Welcome to LTC-TMS! Before using...", message: message, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Read Policy", style: .default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Understood", style: .default, handler: { (action) in
                        
                        let formatter1 = DateFormatter()
                        formatter1.dateFormat = "yyyy-MM-dd"
                        let str = formatter1.string(from: Date())
                        
                        let formatter2 = DateFormatter()
                        formatter2.dateFormat = "HH:mm:ss"
                        let str2 = formatter2.string(from: Date())
                        
                        Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LoginHistory").child("\(str)").child("\(str2)").setValue("Manual")
                        Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LatestLogin").setValue("\(str)-\(str2)")
                        
                        let CNAHomePage = self.storyboard?.instantiateViewController(withIdentifier: "CNAVC") as? CNAVC
                        //userID tag
                        CNAHomePage?.myID = self.UserIDTextField.text!
                        self.present(CNAHomePage!, animated: true, completion: nil)
                    }))
                    
                    let paragraphStyle = NSMutableParagraphStyle()
                    paragraphStyle.alignment = .left
                    
                    let messageText = NSMutableAttributedString(string: message, attributes: [
                        NSAttributedStringKey.paragraphStyle: paragraphStyle,
                        NSAttributedStringKey.font: UIFont.systemFont(ofSize: 14.0),
                        NSAttributedStringKey.foregroundColor : UIColor.black])
                    
                    alert.setValue(messageText, forKey: "attributedMessage")
                    self.present(alert, animated: true, completion: nil)
                    

                    
                    //auto login as CNA
                    UserDefaults.standard.set(true, forKey: "AutoLoginCNA")
                    
                }
                else{
                    self.ref.child("Patient").child(userID!).child("Portfolio").child("Password").observeSingleEvent(of: .value, with: { (snapshot) in
                        if userPassword == (snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""){
                            
                            //policy
                            let message = "1. Do not try to modify the app.\n2. Please protect the patient's privacy.\n3. Please read the system Policy.\nThank you!"
                            let alert = UIAlertController(title: "Welcome to LTC-TMS! Before using...", message: message, preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "Read Policy", style: .default, handler: nil))
                            alert.addAction(UIAlertAction(title: "Understood", style: .default, handler: { (action) in
                                
                                let formatter1 = DateFormatter()
                                formatter1.dateFormat = "yyyy-MM-dd"
                                let str = formatter1.string(from: Date())
                                
                                let formatter2 = DateFormatter()
                                formatter2.dateFormat = "HH:mm:ss"
                                let str2 = formatter2.string(from: Date())
                                
                                Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LoginHistory").child("\(str)").child("\(str2)").setValue("Manual")
                                Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LatestLogin").setValue("\(str)-\(str2)")
                                
                                let FamilyHomePage = self.storyboard?.instantiateViewController(withIdentifier: "FamilyVC") as? FamilyVC
                                //userID tag
                                FamilyHomePage?.FmyID = self.UserIDTextField.text!
                                self.present(FamilyHomePage!, animated: true, completion: nil)
                            }))
                            
                            let paragraphStyle = NSMutableParagraphStyle()
                            paragraphStyle.alignment = .left
                            
                            let messageText = NSMutableAttributedString(string: message, attributes: [
                                NSAttributedStringKey.paragraphStyle: paragraphStyle,
                                NSAttributedStringKey.font: UIFont.systemFont(ofSize: 14.0),
                                NSAttributedStringKey.foregroundColor : UIColor.black])
                            
                            alert.setValue(messageText, forKey: "attributedMessage")
                            self.present(alert, animated: true, completion: nil)

                            
                            
                            
                            //auto login as Family
                            UserDefaults.standard.set(true, forKey: "AutoLoginFAM")
                        }
                        else{
                            self.alertMessage(userMessage: "Wrong ID or Password!!")
                        }
                    }, withCancel: nil)
                }
            }, withCancel: nil)
        }
    
        //remember ID (1)
        UserDefaults.standard.set(UserIDTextField.text, forKey: "userID")
    }
    

    //remember ID CheckBox
    @IBOutlet weak var checkbox: UIButton!
    @IBAction func ClickCheckBox(_ sender: UIButton) {
        if checkbox.isSelected{
            checkbox.isSelected = false
            if checkbox2.isSelected{
                checkbox2.isSelected = false
                UserDefaults.standard.set(false, forKey: "test")
            }
        }
        else{
            checkbox.isSelected = true
        }
        //remember ID (2)
        UserDefaults.standard.set(checkbox.isSelected, forKey: "rememberIDON")
    }
    
    //Auto Login CheckBox
    @IBOutlet weak var checkbox2: UIButton!
    @IBAction func ClickCheckBox2(_ sender: UIButton) {
        if checkbox2.isSelected{
            checkbox2.isSelected = false
            UserDefaults.standard.set(false, forKey: "test")
        }
        else{
            if checkbox.isSelected == false{
                checkbox.isSelected = true
                checkbox2.isSelected = true
                UserDefaults.standard.set(checkbox.isSelected, forKey: "rememberIDON")
                
            }else if checkbox.isSelected == true{
                checkbox2.isSelected = true
                UserDefaults.standard.set(checkbox.isSelected, forKey: "rememberIDON")
            }
        }
        //auto Login
        UserDefaults.standard.set(true, forKey: "test")
        UserDefaults.standard.set(checkbox2.isSelected, forKey: "AutoLoginON")
    }
    
    
    //提示視窗
    func alertMessage(userMessage: String){
        let alert = UIAlertController(title: "Notice", message: userMessage, preferredStyle: .alert)
        let okaction = UIAlertAction(title: "ok", style: .default, handler: nil)
        alert.addAction(okaction)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    //forgot password
    var IDtextfield:UITextField?
    @IBAction func clickforgotpassword(_ sender: UIButton) {
        forgotAlert(userMessage: "Enter your User ID to get start.")
    }
    func forgotAlert(userMessage:String){
        let alert1 = UIAlertController(title: "Reset Password", message: userMessage, preferredStyle: .alert)
        let cancelaction1 = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
        let nextaction1 = UIAlertAction(title: "continue", style: .default) { (action) in
            let IDtextfield = alert1.textFields![0] as UITextField
            
            
            //make sure ID is correct
            Database.database().reference().child("CNA").observe(.childAdded, with: { (snapshot) in
                if (snapshot.key).replacingOccurrences(of: "\"", with: "") == IDtextfield.text{
                    let alert2 = UIAlertController(title: "Reset Password", message: "Input your information below.", preferredStyle: .alert)
                    let cancelaction2 = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
                    let nextaction2 = UIAlertAction(title: "continue", style: .default) { (action) in
                        let name = alert2.textFields![0] as UITextField
                        let questionfield1 = alert2.textFields![1] as UITextField
                        let NationalID = alert2.textFields![2] as UITextField
                        
                        
                        
                        //make sure question is correct
                        Database.database().reference().child("CNA").child(IDtextfield.text!).child("Portfolio").child("Name").observe(.value, with: { (snapshot1) in
                            if (snapshot1.value as? String)?.replacingOccurrences(of: "\"", with: "") == name.text{
                                Database.database().reference().child("CNA").child(IDtextfield.text!).child("Portfolio").child("Email").observe(.value, with: { (snap) in
                                    if snap.value as? String == questionfield1.text{
                                        Database.database().reference().child("CNA").child(IDtextfield.text!).child("Portfolio").child("NationalID").observe(.value, with: { (snap1) in
                                            if snap1.value as? String == NationalID.text{
                                                let alert4 = UIAlertController(title: "Reset Password", message: "Enter the new password.", preferredStyle: .alert)
                                                let cancelaction4 = UIAlertAction(title: "cancel", style: .default, handler: nil)
                                                let nextaction4 = UIAlertAction(title: "reset", style: .default, handler: { (action) in
                                                    let newpassword = alert4.textFields![0] as UITextField
                                                    let newpasswordconfirm = alert4.textFields![1] as UITextField
                                                    
                                                    
                                                    //make sure no empty(s) or different password
                                                    if newpassword.text == newpasswordconfirm.text && (newpassword.text?.isEmpty == false || newpasswordconfirm.text?.isEmpty == false) {
                                                        
                                                        //Change Password History
                                                        
                                                        Database.database().reference().child("CNA").child(IDtextfield.text!).child("Portfolio").child("Password").setValue(newpassword.text!)
                                                        
                                                        let dateformatter = DateFormatter()
                                                        dateformatter.dateFormat = "yyyy-MM-dd-HH:mm:ss"
                                                        let str = dateformatter.string(from: Date())
                                                        Database.database().reference().child("CNA").child(IDtextfield.text!).child("Portfolio").child("Password").observe(.value, with: { (snap2) in
                                                            Database.database().reference().child("AccountStatus").child(snapshot.key).child("ChangePasswordHistory").child(str).setValue("PreviousPassword~\(String(describing: (newpassword.text)!))")
                                                        })
                                                        self.alertMessage(userMessage: "Succeed!\nRemember to login by the new password.")
                                                    }
                                                    else{
                                                        let wrong = UIAlertController(title: "Error", message: "Empty fields exist or password not matching, do you want to continue?", preferredStyle: .actionSheet)
                                                        let cancel = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
                                                        let continueAlert = UIAlertAction(title: "continue", style: .default, handler: { (action) in
                                                            self.present(alert4, animated: true, completion: nil)
                                                        })
                                                        wrong.addAction(cancel)
                                                        wrong.addAction(continueAlert)
                                                        self.present(wrong, animated: true, completion: nil)
                                                    }
                                                })
                                                
                                                alert4.addTextField(configurationHandler: { (newpassword) in
                                                    newpassword.placeholder = "New Password"
                                                    newpassword.isSecureTextEntry = true
                                                })
                                                alert4.addTextField(configurationHandler: { (confirmpassword) in
                                                    confirmpassword.placeholder = "Confirm Password"
                                                    confirmpassword.isSecureTextEntry = true
                                                })
                                                alert4.addAction(cancelaction4)
                                                alert4.addAction(nextaction4)
                                                self.present(alert4, animated: true, completion: nil)
                                            }
                                            else{
                                                let wrong = UIAlertController(title: "Error", message: "Empty fields exist or wrong information, do you want to continue?", preferredStyle: .actionSheet)
                                                let cancel = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
                                                let continueAlert = UIAlertAction(title: "continue", style: .default, handler: { (action) in
                                                    self.present(alert2, animated: true, completion: nil)
                                                })
                                                wrong.addAction(cancel)
                                                wrong.addAction(continueAlert)
                                                self.present(wrong, animated: true, completion: nil)
                                                self.alertMessage(userMessage: "Empty fields exist or wrong information!")
                                            }
                                        }, withCancel: nil)
                                    }
                                    else{
                                        let wrong = UIAlertController(title: "Error", message: "Empty fields exist or wrong information, do you want to continue?", preferredStyle: .actionSheet)
                                        let cancel = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
                                        let continueAlert = UIAlertAction(title: "continue", style: .default, handler: { (action) in
                                            self.present(alert2, animated: true, completion: nil)
                                        })
                                        wrong.addAction(cancel)
                                        wrong.addAction(continueAlert)
                                        self.present(wrong, animated: true, completion: nil)
                                        self.alertMessage(userMessage: "Empty fields exist or wrong information!")
                                    }
                                }, withCancel: nil)
                                
                                
                            }
                            else{
                                let wrong = UIAlertController(title: "Error", message: "Empty fields exist or wrong information, do you want to continue?", preferredStyle: .actionSheet)
                                let cancel = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
                                let continueAlert = UIAlertAction(title: "continue", style: .default, handler: { (action) in
                                    self.present(alert2, animated: true, completion: nil)
                                })
                                wrong.addAction(cancel)
                                wrong.addAction(continueAlert)
                                self.present(wrong, animated: true, completion: nil)
                                self.alertMessage(userMessage: "Empty fields exist or wrong information!")
                            }
                        }, withCancel: nil)
                    }
                    alert2.addTextField(configurationHandler: { (name) in
                        name.placeholder = "name"
                    })
                    alert2.addTextField(configurationHandler: { (answerfield) in
                        answerfield.placeholder = "example@example.com"
                    })
                    alert2.addTextField(configurationHandler: { (NationalID) in
                        NationalID.placeholder = "A123456789"
                    })
                    alert2.addAction(cancelaction2)
                    alert2.addAction(nextaction2)
                    self.present(alert2, animated: true, completion: nil)
                    
                }else{
                    Database.database().reference().child("Patient").observe(.childAdded, with: { (snapshot2) in
                        if snapshot2.key == IDtextfield.text{
                            let alert3 = UIAlertController(title: "Reset Password", message: "Input your information below.", preferredStyle: .alert)
                            let cancelaction3 = UIAlertAction(title: "cancel", style: .default, handler: nil)
                            let nextaction3 = UIAlertAction(title: "Next", style: .default) { (action) in
                                let name = alert3.textFields![0] as UITextField
                                let questionfield2 = alert3.textFields![1] as UITextField
                                let NationalID = alert3.textFields![2] as UITextField
                                
                                //make sure question is correct
                                Database.database().reference().child("Patient").child(IDtextfield.text!).child("Portfolio").child("Name").observe(.value, with: { (snapshot1) in
                                    if snapshot1.value as? String == name.text{
                                        Database.database().reference().child("Patient").child(IDtextfield.text!).child("Portfolio").child("Email").observe(.value, with: { (snap) in
                                            if snap.value as? String == questionfield2.text{
                                                Database.database().reference().child("Patient").child(IDtextfield.text!).child("Portfolio").child("NationalID").observe(.value, with: { (snap1) in
                                                    if snap1.value as? String == NationalID.text{
                                                        let alert5 = UIAlertController(title: "Reset Password", message: "Enter the new password.", preferredStyle: .alert)
                                                        let cancelaction5 = UIAlertAction(title: "cancel", style: .default, handler: nil)
                                                        let nextaction5 = UIAlertAction(title: "reset", style: .default, handler: { (action) in
                                                            let newpassword = alert5.textFields![0] as UITextField
                                                            let newpasswordconfirm = alert5.textFields![1] as UITextField
                                                            
                                                            
                                                            //make sure no empty(s) or different password
                                                            if newpassword.text == newpasswordconfirm.text && (newpassword.text?.isEmpty == false || newpasswordconfirm.text?.isEmpty == false){
                                                                Database.database().reference().child("Patient").child(IDtextfield.text!).child("Portfolio").child("Password").setValue(newpassword.text!)
                                                                self.alertMessage(userMessage: "Succeed!")
                                                            }else{
                                                                let wrong = UIAlertController(title: "Error", message: "Empty fields exist or password not matching, do you want to continue?", preferredStyle: .actionSheet)
                                                                let cancel = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
                                                                let continueAlert = UIAlertAction(title: "continue", style: .default, handler: { (action) in
                                                                    self.present(alert5, animated: true, completion: nil)
                                                                })
                                                                wrong.addAction(cancel)
                                                                wrong.addAction(continueAlert)
                                                                self.present(wrong, animated: true, completion: nil)
                                                            }
                                                        })
                                                        
                                                        alert5.addTextField(configurationHandler: { (newpassword) in
                                                            newpassword.placeholder = "New Password"
                                                            newpassword.isSecureTextEntry = true
                                                        })
                                                        alert5.addTextField(configurationHandler: { (confirmpassword) in
                                                            confirmpassword.placeholder = "Confirm Password"
                                                            confirmpassword.isSecureTextEntry = true
                                                        })
                                                        alert5.addAction(cancelaction5)
                                                        alert5.addAction(nextaction5)
                                                        self.present(alert5, animated: true, completion: nil)
                                                    }
                                                    else{
                                                        let wrong = UIAlertController(title: "Error", message: "Empty fields exist or wrong information, do you want to continue?", preferredStyle: .actionSheet)
                                                        let cancel = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
                                                        let continueAlert = UIAlertAction(title: "continue", style: .default, handler: { (action) in
                                                            self.present(alert3, animated: true, completion: nil)
                                                        })
                                                        wrong.addAction(cancel)
                                                        wrong.addAction(continueAlert)
                                                        self.present(wrong, animated: true, completion: nil)
                                                        self.alertMessage(userMessage: "Empty fields exist or wrong information!")
                                                    }
                                                }, withCancel: nil)
                                            }
                                            else{
                                                let wrong = UIAlertController(title: "Error", message: "Empty fields exist or wrong information, do you want to continue?", preferredStyle: .actionSheet)
                                                let cancel = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
                                                let continueAlert = UIAlertAction(title: "continue", style: .default, handler: { (action) in
                                                    self.present(alert3, animated: true, completion: nil)
                                                })
                                                wrong.addAction(cancel)
                                                wrong.addAction(continueAlert)
                                                self.present(wrong, animated: true, completion: nil)
                                                self.alertMessage(userMessage: "Empty fields exist or wrong information!")
                                            }
                                        }, withCancel: nil)
                                    }
                                    else{
                                        let wrong = UIAlertController(title: "Error", message: "Empty fields exist or wrong information, do you want to continue?", preferredStyle: .actionSheet)
                                        let cancel = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
                                        let continueAlert = UIAlertAction(title: "continue", style: .default, handler: { (action) in
                                            self.present(alert3, animated: true, completion: nil)
                                        })
                                        wrong.addAction(cancel)
                                        wrong.addAction(continueAlert)
                                        self.present(wrong, animated: true, completion: nil)
                                        self.alertMessage(userMessage: "Empty fields exist or wrong information!")
                                    }
                                }, withCancel: nil)
                            }
                            alert3.addTextField(configurationHandler: { (name) in
                                name.placeholder = "name"
                            })
                            alert3.addTextField(configurationHandler: { (answerfield) in
                                answerfield.placeholder = "example@example.com"
                            })
                            alert3.addTextField(configurationHandler: { (NationalID) in
                                NationalID.placeholder = "A123456789"
                            })
                            alert3.addAction(cancelaction3)
                            alert3.addAction(nextaction3)
                            self.present(alert3, animated: true, completion: nil)
                        }
                        else{
                            self.alertMessage(userMessage: "Empty fields exist or wrong ID!")
                        }
                    }, withCancel: nil)
                }
            }, withCancel: nil)
        }
        let forgotID = UIAlertAction(title: "forgot ID", style: .default) { (action) in
            let IDalert = UIAlertController(title: "Find the user ID", message: "Enter the information below to find your ID. (If you are family user, the follow fields are about patient.)", preferredStyle: .alert)
            let cancel = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
            let continueAction = UIAlertAction(title: "continue", style: .default, handler: { (action) in
                let name = IDalert.textFields![0] as UITextField
                let email = IDalert.textFields![1] as UITextField
                
                Database.database().reference().child("CNA").observe(.childAdded, with: { (snapshot) in
                    Database.database().reference().child("CNA").child(snapshot.key).child("Portfolio").child("Name").observe(.value, with: { (snapshot1) in
                        if name.text == snapshot1.value as? String{
                            Database.database().reference().child("CNA").child(snapshot.key).child("Portfolio").child("Email").observe(.value, with: { (snapshot2) in
                                if email.text == snapshot2.value as? String{
                                    self.alertMessage(userMessage: "Here is your User ID : \(snapshot.key)")
                                }
                                else{
                                    self.alertMessage(userMessage: "Wrong information !")
                                }
                            }, withCancel: nil)
                        }
                        else{
                            Database.database().reference().child("Patient").observe(.childAdded, with: { (snapshot3) in
                                Database.database().reference().child("Patient").child(snapshot3.key).child("Portfolio").child("Name").observe(.value, with: { (snapshot4) in
                                    if name.text == snapshot4.value as? String{
                                        Database.database().reference().child("Patient").child(snapshot3.key).child("Portfolio").child("Email").observe(.value, with: { (snapshot5) in
                                            if email.text == snapshot5.value as? String{
                                                self.alertMessage(userMessage: "Here is your User ID : \(snapshot3.key)")
                                            }
                                            else{
                                                self.alertMessage(userMessage: "Wrong information !")
                                            }
                                        }, withCancel: nil)
                                    }
                                }, withCancel: nil)
                            }, withCancel: nil)
                        }
                    }, withCancel: nil)
                }, withCancel: nil)
            })
            IDalert.addTextField(configurationHandler: { (name) in
                name.placeholder = "name"
            })
            IDalert.addTextField(configurationHandler: { (email) in
                email.placeholder = "email address"
            })
            IDalert.addAction(cancel)
            IDalert.addAction(continueAction)
            self.present(IDalert, animated: true, completion: nil)
        }
        
        alert1.addTextField { (IDtextfield) in
            IDtextfield.placeholder = "Enter your ID first"
        }
        alert1.addAction(nextaction1)
        alert1.addAction(forgotID)
        alert1.addAction(cancelaction1)
        
        self.present(alert1, animated: true, completion: nil)
    }
    
    @IBAction func readpolicy(_ sender: UIButton) {
        Database.database().reference().child("Policy").child("P1").child("System Policy").observe(.value, with: { (snapshot) in
            UIApplication.shared.open(URL(string: (snapshot.value as? String)!)!, options: [:], completionHandler: nil)
        }, withCancel: nil)
    }
    
    

    
    //After typing, touch screen, keyboard will drop down.
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        UserIDTextField.endEditing(true)
        PasswordTextField.endEditing(true)
    }
    
    
    //Call, Email bottom
    @IBAction func CallBottom(_ sender: UIButton) {
        Database.database().reference().child("CenterInformation").child("ContactInfo").child("Contact No").observe(.value) { (snapshot) in
            
            let url : NSURL = URL(string: "TEL://\(snapshot.value as! String)")! as NSURL
            UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
            
        }
    }
    @IBAction func EmailBottom(_ sender: UIButton) {
        let mailsend = MFMailComposeViewController()
        mailsend.mailComposeDelegate = self
        Database.database().reference().child("CenterInformation").child("ContactInfo").child("Email").observe(.value) { (snapshot) in
            
            mailsend.setToRecipients(["\(snapshot.value as! String)"])
            mailsend.setSubject("Test")
        }
        
        if MFMailComposeViewController.canSendMail(){
            self.present(mailsend, animated: true, completion: nil)
        }
        else{
            print("NO")
        }
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //remember ID (3)
        if let y = UserDefaults.standard.object(forKey: "rememberIDON")as? Bool{
            checkbox.isSelected = y
        }
        if(checkbox.isSelected == true){
            if let x = UserDefaults.standard.object(forKey: "userID")as? String{
                UserIDTextField.text = x
            }
        }
        
        
        //auto login
        if let isON = UserDefaults.standard.object(forKey: "AutoLoginON")as? Bool{
            checkbox2.isSelected = isON
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        //Auto Login
        if (UserDefaults.standard.bool(forKey: "test") == true){
            
            //auto login as CNA
            if (UserDefaults.standard.bool(forKey: "AutoLoginCNA") == true){
                
                let formatter1 = DateFormatter()
                formatter1.dateFormat = "yyyy-MM-dd"
                let str = formatter1.string(from: Date())
                
                let formatter2 = DateFormatter()
                formatter2.dateFormat = "HH:mm:ss"
                let str2 = formatter2.string(from: Date())
                
                Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LoginHistory").child("\(str)").child("\(str2)").setValue("Auto")
                Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LatestLogin").setValue("\(str)-\(str2)")
                
                let CNAHomePage = self.storyboard?.instantiateViewController(withIdentifier: "CNAVC") as? CNAVC
                //userID tag
                CNAHomePage?.myID = self.UserIDTextField.text!
                self.present(CNAHomePage!, animated: true, completion: nil)
                
            }else{
                
                //auto login as Family
                if (UserDefaults.standard.bool(forKey: "AutoLoginFAM") == true){
                    
                    let formatter1 = DateFormatter()
                    formatter1.dateFormat = "yyyy-MM-dd"
                    let str = formatter1.string(from: Date())
                    
                    let formatter2 = DateFormatter()
                    formatter2.dateFormat = "HH:mm:ss"
                    let str2 = formatter2.string(from: Date())
                    
                    Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LoginHistory").child("\(str)").child("\(str2)").setValue("Auto")
                    Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LatestLogin").setValue("\(str)-\(str2)")
                    
                    let FamilyHomePage = self.storyboard?.instantiateViewController(withIdentifier: "FamilyVC") as? FamilyVC
                    //userID tag
                    FamilyHomePage?.FmyID = self.UserIDTextField.text!
                    self.present(FamilyHomePage!, animated: true, completion: nil)
                }
            }
            
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

