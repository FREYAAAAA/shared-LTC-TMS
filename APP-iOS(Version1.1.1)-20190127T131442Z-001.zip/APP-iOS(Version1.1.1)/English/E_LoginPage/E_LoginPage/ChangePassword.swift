//
//  ChangePassword.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/6.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class ChangePassword: UIViewController {
    
    @IBAction func cancelbutton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var currentField: UITextField!
    @IBOutlet weak var newField: UITextField!
    @IBOutlet weak var confirmField: UITextField!
    @IBOutlet weak var savebutton: UIButton!
    @IBAction func savebuttonclick(_ sender: UIButton) {
        
        //CNA user
        Database.database().reference().child("CNA").child(resetpasswordID).child("Portfolio").child("Password").observe(.value, with: { (snapshot) in
            if self.currentField.text == (snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""){
                
                
                if self.newField.text == self.confirmField.text{
                    
                    if self.newField.text == (snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""){
                        self.alertMessage(userMessage: "New Password should be different from the previous one.")
                    }
                        
                    else if (self.newField.text)!.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "#") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "/") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "\"") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: ",") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: ":") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "@") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "$") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "{") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "}") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "(") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: ")") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "*") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "[") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }else if (self.newField.text)!.range(of: "]") != nil{
                        self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                    }
                        
                    else if self.newField.text!.count < 8{
                        self.alertMessage(userMessage: "Password should more or equal than 8 characters.")
                    }
                    
                    else{
                        let finalconfirm = UIAlertController(title: "Notice", message: "Are you sure you want to change the password?", preferredStyle: .alert)
                        finalconfirm.addAction(UIAlertAction(title: "Regret", style: .default, handler: nil))
                        finalconfirm.addAction(UIAlertAction(title: "Agree", style: .default, handler: { (action) in
                            
                            let dateformatter = DateFormatter()
                            dateformatter.dateFormat = "yyyy-MM-dd-hh:mm:ss"
                            let str = dateformatter.string(from: Date())
                            
                        Database.database().reference().child("CNA").child(self.resetpasswordID).child("Portfolio").child("Password").setValue(self.confirmField.text)
                          
                            
                        //Change Password History
                        Database.database().reference().child("AccountStatus").child("App").child(self.resetpasswordID).child("ChangePasswordHistory").child(str).setValue("\(String(describing: (self.currentField.text)!))~\(String(describing: (self.newField.text)!))")
                            
                            
                            let resetsucceed = UIAlertController(title: "Succeed", message: "", preferredStyle: .alert)
                            resetsucceed.addAction(UIAlertAction(title: "Done", style: .default, handler: { (action) in
                                self.dismiss(animated: true, completion: nil)
                            }))
                            self.present(resetsucceed, animated: true, completion: nil)
                        }))
                        self.present(finalconfirm, animated: true, completion: nil)
                    }
                }else{
                    let errorMessage = UIAlertController(title: "Oops", message: "New Password does not match with the confirm one.", preferredStyle: .alert)
                    errorMessage.addAction(UIAlertAction(title: "Got it", style: .default, handler: nil))
                    self.present(errorMessage, animated: true, completion: nil)
                }
                
            }
            
            
            
            
            else{
                
                //family user
                Database.database().reference().child("Patient").child(self.resetpasswordID).child("Portfolio").child("Password").observe(.value, with: { (snapshot) in
                    if self.currentField.text == (snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""){
                        
                        
                        if self.newField.text == self.confirmField.text{
                            
                            if self.newField.text == snapshot.value as? String{
                                self.alertMessage(userMessage: "New Password should be different from the previous one.")
                            }
                            
                            else if (self.newField.text)!.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "#") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "/") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "\"") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: ",") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: ":") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "@") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "$") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "{") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "}") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "(") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: ")") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "*") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "[") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }else if (self.newField.text)!.range(of: "]") != nil{
                                self.alertMessage(userMessage: "Password should not contain with space or symbols.")
                            }
                            
                            else if self.newField.text!.count < 8{
                                self.alertMessage(userMessage: "Password should more or equal than 8 characters.")
                            }
                            
                            else{
                                let finalconfirm = UIAlertController(title: "Notice", message: "Are you sure you want to change the password?", preferredStyle: .alert)
                                finalconfirm.addAction(UIAlertAction(title: "Regret", style: .default, handler: nil))
                                finalconfirm.addAction(UIAlertAction(title: "Agree", style: .default, handler: { (action) in
                                    
                                    let dateformatter = DateFormatter()
                                    dateformatter.dateFormat = "yyyy-MM-dd-hh:mm:ss"
                                    let str = dateformatter.string(from: Date())
                                    
                                    Database.database().reference().child("Patient").child(self.resetpasswordID).child("Portfolio").child("Password").setValue(self.confirmField.text)
                                    
                                    
                                    //Change Password History
                                    Database.database().reference().child("AccountStatus").child("App").child(self.resetpasswordID).child("ChangePasswordHistory").child(str).setValue("\(String(describing: (self.currentField.text)!))~\(String(describing: (self.newField.text)!))")
                                    
                                    
                                    let resetsucceed = UIAlertController(title: "Succeed", message: "", preferredStyle: .alert)
                                    resetsucceed.addAction(UIAlertAction(title: "Done", style: .default, handler: { (action) in
                                        self.dismiss(animated: true, completion: nil)
                                    }))
                                    self.present(resetsucceed, animated: true, completion: nil)
                                }))
                                self.present(finalconfirm, animated: true, completion: nil)
                            }
                        }else{
                            let errorMessage = UIAlertController(title: "Oops", message: "New Password does not match with the confirm one.", preferredStyle: .alert)
                            errorMessage.addAction(UIAlertAction(title: "Got it", style: .default, handler: nil))
                            self.present(errorMessage, animated: true, completion: nil)
                        }
                    }else{
                        let errorMessage = UIAlertController(title: "Oops", message: "Current password is incorrect.", preferredStyle: .alert)
                        errorMessage.addAction(UIAlertAction(title: "Got it", style: .default, handler: nil))
                        self.present(errorMessage, animated: true, completion: nil)
                    }
                }, withCancel: nil)
            }
        }, withCancel: nil)
        
    }
    
    func alertMessage(userMessage: String){
        let alert = UIAlertController(title: "Oops", message: userMessage, preferredStyle: .alert)
        let okaction = UIAlertAction(title: "Got it", style: .default, handler: nil)
        alert.addAction(okaction)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    //set save button enable or not
    @IBAction func Field1(_ sender: UITextField) {
        if currentField.text?.isEmpty == false && newField.text?.isEmpty == false && confirmField.text?.isEmpty == false{
            savebutton.isEnabled = true
        }else if currentField.text?.isEmpty == true || newField.text?.isEmpty == true || confirmField.text?.isEmpty == true{
            savebutton.isEnabled = false
        }
    }
    @IBAction func FIeld2(_ sender: UITextField) {
        if currentField.text?.isEmpty == false && newField.text?.isEmpty == false &&  confirmField.text?.isEmpty == false{
            savebutton.isEnabled = true
        }else if currentField.text?.isEmpty == true || newField.text?.isEmpty == true || confirmField.text?.isEmpty == true{
            savebutton.isEnabled = false
        }
    }
    @IBAction func Field3(_ sender: UITextField) {
        if currentField.text?.isEmpty == false && newField.text?.isEmpty == false && confirmField.text?.isEmpty == false {
            savebutton.isEnabled = true
        }else if currentField.text?.isEmpty == true || newField.text?.isEmpty == true || confirmField.text?.isEmpty == true{
            savebutton.isEnabled = false
        }
    }
    
    
    
    var resetpasswordID = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        savebutton.isEnabled = false
        
        
    }
    


}
