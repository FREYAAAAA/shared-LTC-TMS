//
//  HelpVC.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/9/17.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class HelpVC: UIViewController, UITextViewDelegate {
    
    //checkboxs
    @IBOutlet weak var centerCheckBox: UIButton!
    @IBOutlet weak var systemCheckBox: UIButton!
    @IBAction func clickCenter(_ sender: UIButton) {
        if centerCheckBox.isSelected{
            centerCheckBox.isSelected = true
        }else{
            centerCheckBox.isSelected = true
            systemCheckBox.isSelected = false
        }
    }
    @IBAction func clickSystem(_ sender: UIButton) {
        if systemCheckBox.isSelected{
            systemCheckBox.isSelected = true
        }else{
            systemCheckBox.isSelected = true
            centerCheckBox.isSelected = false
        }
    }
    
    
    //feedback ID
    @IBOutlet weak var feedbackID: UILabel!
    

    //submit button
    @IBAction func Submit(_ sender: UIButton) {
        
        let formatter1 = DateFormatter()
        formatter1.dateFormat = "yyyy-M-d"
        let str = formatter1.string(from: Date())
        
        let formatter2 = DateFormatter()
        formatter2.dateFormat = "HH:mm:ss"
        let str2 = formatter2.string(from: Date())
        
        if feedbackField.text == "Feel free to write a feedback or problem(s)!" || feedbackField.text.isEmpty == true{
            let failmessage = UIAlertController(title: "Notice", message: "Please enter some feedback.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            failmessage.addAction(ok)
            self.present(failmessage, animated: true, completion: nil)
        }else{
            
            if centerCheckBox.isSelected{
                let alert = UIAlertController(title: "Confirm", message: "Submit the feedback?", preferredStyle: .alert)
                let cancelaction = UIAlertAction(title: "cancel", style: .default, handler: nil)
                let okaction = UIAlertAction(title: "Sure", style: .default, handler: {(action) in
                    
                   let x = Int((self.feedbackID.text!).replacingOccurrences(of: "\"", with: ""))! + 1
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("Center").child(str).child("ID-\(x)").child("Received").child(str2).setValue("\"\(String(describing: (self.feedbackField.text)!))\"")
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("Center").child(str).child("ID-\(x)").child("Replied").child(" ").setValue(" ")
                    
                    
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("TimesOfFeedback").setValue("\(x)")
                    
                    self.alertMessage(userMessage: "Thanks for the feedback.")
                    
                })
                alert.addAction(cancelaction)
                alert.addAction(okaction)
                self.present(alert, animated: true, completion: nil)
            }
            else{
                let alert = UIAlertController(title: "Confirm", message: "Submit the feedback?", preferredStyle: .alert)
                let cancelaction = UIAlertAction(title: "cancel", style: .default, handler: nil)
                let okaction = UIAlertAction(title: "Sure", style: .default, handler: {(action) in
                    
                    let x = Int((self.feedbackID.text!).replacingOccurrences(of: "\"", with: ""))! + 1
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("System").child(str).child("ID-\(x)").child("Received").child(str2).setValue("\"\(String(describing: (self.feedbackField.text)!))\"")
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("System").child(str).child("ID-\(x)").child("Replied").child(" ").setValue(" ")
                    
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("TimesOfFeedback").setValue("\(x)")
                    
                    self.alertMessage(userMessage: "Thanks for the feedback.")
                    
                })
                alert.addAction(cancelaction)
                alert.addAction(okaction)
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func alertMessage(userMessage: String){
        let alert2 = UIAlertController(title: "Succeed!", message: userMessage, preferredStyle: .alert)
        let thanks = UIAlertAction(title: "Done", style: .default) { (action) in
            self.dismiss(animated: true, completion: nil)
        }
        alert2.addAction(thanks)
        self.present(alert2, animated: true, completion: nil)
    }
    
    
    
    //dismiss VC
    @IBAction func Done(_ sender: Any) {
        if feedbackField.text.isEmpty == true || feedbackField.text == "Feel free to write a feedback or problem(s)!"{
            dismiss(animated: true, completion: nil)
        }else{
            let alert = UIAlertController(title: "Leave", message: "You haven't submit your feedback, do you want to leave?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "cancel", style: .default, handler: nil))
            alert.addAction(UIAlertAction(title: "leave", style: .default, handler: { (action) in
                self.dismiss(animated: true, completion: nil)
            }))
            present(alert, animated: true, completion: nil)
        }
        
    }
    
    //keyboard down
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        feedbackField.endEditing(true)
    }
    
    @IBOutlet weak var feedbackField: UITextView!
    @IBOutlet weak var UID: UILabel!
    var myID6 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UID.text = myID6
        
        //feedbackID
        Database.database().reference().child("Feedback").observe(.childAdded, with: { (snapshot) in
            if snapshot.key == self.UID.text{
                Database.database().reference().child("Feedback").child(self.UID.text!).child("TimesOfFeedback").observe(.value, with: { (snapshot1) in
                    self.feedbackID.text = "\(String(describing: (snapshot1.value as! String).replacingOccurrences(of: "\"", with: "")))"
                    
                }, withCancel: nil)
            }
        }, withCancel: nil)
        
        
        //placeholder
        feedbackField.text = "Feel free to write a feedback or problem(s)!"
        feedbackField.textColor = UIColor.lightGray
        feedbackField.delegate = self
    }
    
    
    
    //placeholder
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == "Feel free to write a feedback or problem(s)!"{
            textView.text = ""
            textView.textColor = UIColor.black
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text == ""{
            textView.text = "Feel free to write a feedback or problem(s)!"
            textView.textColor = UIColor.lightGray
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

}
