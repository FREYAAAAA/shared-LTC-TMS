//
//  WelcomeVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/12/3.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit

class WelcomeVC: UIViewController {
    
    @IBOutlet weak var languageList: UITableView!
    
    @IBOutlet weak var english: UIButton!
    @IBOutlet weak var chinese: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        languageList.layer.borderWidth = 5.0
        languageList.layer.borderColor = UIColor.lightGray.cgColor
        languageList.layer.cornerRadius = 10.0
        
        
    
        // Do any additional setup after loading the view.
    }

}
