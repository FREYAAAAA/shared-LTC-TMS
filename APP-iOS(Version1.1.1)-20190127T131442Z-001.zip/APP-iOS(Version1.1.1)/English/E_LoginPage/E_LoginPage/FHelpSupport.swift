//
//  FHelpSupport.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/6.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import MessageUI
import FirebaseDatabase

class FHelpSupport: UIViewController, MFMailComposeViewControllerDelegate, UITextViewDelegate, UITableViewDelegate, UITableViewDataSource {
    
    let conbinelist = [
        ["Send Feedback", "Feedback History"],
        ["Call Center", "E-mail Center", "Locate Center"],
        ["Switch Language", "Change Password", "System Policy"]
    ]
    let headerlist = ["", "", ""]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return conbinelist[section].count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return conbinelist.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let label = UILabel()
        label.text = headerlist[section]
        
        return label
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cellID")
        let name = conbinelist[indexPath.section][indexPath.row]
        
        
        cell.textLabel?.text = name
        cell.textLabel?.font = UIFont(descriptor: .init(), size: 20)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let name = conbinelist[indexPath.section][indexPath.row]
        if name == "Send Feedback"{
            let helppage = storyboard?.instantiateViewController(withIdentifier: "HelpVC") as? HelpVC
            helppage?.myID6 = self.FmyID6
            self.present(helppage!, animated: true, completion: nil)
        }
        else if name == "Feedback History"{
            let FBhistory = storyboard?.instantiateViewController(withIdentifier: "feedbackHistory") as? feedbackHistory
            FBhistory?.myID7 = self.FmyID6
            self.present(FBhistory!, animated: true, completion: nil)
        }
        else if name == "Call Center"{
            Database.database().reference().child("CenterInformation").child("ContactInfo").child("Contact No").observe(.value) { (snapshot) in
                
                let url : NSURL = URL(string: "TEL://\(snapshot.value as! String)")! as NSURL
                UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
                
            }
        }
        else if name == "E-mail Center"{
            let mailsend = MFMailComposeViewController()
            mailsend.mailComposeDelegate = self
            Database.database().reference().child("CenterInformation").child("ContactInfo").child("Email").observe(.value) { (snapshot) in
                
                mailsend.setToRecipients(["\(snapshot.value as! String)"])
                mailsend.setSubject("Test")
            }
            
            if MFMailComposeViewController.canSendMail(){
                self.present(mailsend, animated: true, completion: nil)
            }
            else{
                print("NO")
            }
        }
        else if name == "Locate Center"{
            UIApplication.shared.open(URL(string: "https://www.google.com.tw/maps/place/%E9%8A%98%E5%82%B3%E5%A4%A7%E5%AD%B8+%E6%A1%83%E5%9C%92%E6%A0%A1%E5%8D%80/@24.985171,121.339809,17z/data=!4m8!1m2!2m1!1z6YqY5YKz5aSn5a24!3m4!1s0x34681e8f88001f51:0xde8e62ebe5442d75!8m2!3d24.9844926!4d121.3423688")!, options: [:], completionHandler: nil)
        }
        else if name == "Switch Language"{
            let switchlanguage = UIAlertController(title: "choose the language", message: "", preferredStyle: .alert)
            switchlanguage.addAction(UIAlertAction(title: "English", style: .default, handler: nil))
            switchlanguage.addAction(UIAlertAction(title: "中文", style: .default, handler: { (action) in
                let languageswitch = self.storyboard?.instantiateViewController(withIdentifier: "C_FHelpSupport") as? C_FHelpSupport
                languageswitch?.CFmyID6 = self.FmyID6
                self.present(languageswitch!, animated: false, completion: nil)
            }))
            
            present(switchlanguage, animated: true, completion: nil)
        }
        else if name == "Change Password"{
            let passwordpage = storyboard?.instantiateViewController(withIdentifier: "ChangePassword") as? ChangePassword
            passwordpage?.resetpasswordID = self.FmyID6
            self.present(passwordpage!, animated: true, completion: nil)
        }
        else if name == "System Policy"{
            Database.database().reference().child("Policy").child("P1").child("System Policy").observe(.value, with: { (snapshot) in
                UIApplication.shared.open(URL(string: (snapshot.value as? String)!)!, options: [:], completionHandler: nil)
            }, withCancel: nil)
        }
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let FAMhomepage = storyboard?.instantiateViewController(withIdentifier: "FamilyVC") as? FamilyVC
        FAMhomepage?.FmyID = self.FmyID6
        self.present(FAMhomepage!, animated: false, completion: nil)
    }
    
    //hamburgerIcon
    @IBOutlet weak var Hamburger: UIStackView!
    @IBAction func HamburgerBottom(_ sender: UIButton) {
        if(Hamburger.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.Hamburger.window!.layer.add(transition, forKey: kCATransition)
            
            Hamburger.isHidden = false
        }
        else{
            Hamburger.isHidden = true
        }
    }
    @IBAction func clickEPortfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "F_PortfolioVC") as? F_PortfolioVC
        portfoliopage?.FmyID1 = self.FmyID6
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func clickTask(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "F_TaskInstructionVC") as? F_TaskInstructionVC
        taskpage?.FmyID2 = self.FmyID6
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func clickDailyRecord(_ sender: UIButton) {
        let dailypage = storyboard?.instantiateViewController(withIdentifier: "DailyStatusRecordVC") as? DailyStatusRecordVC
        dailypage?.FmyID3 = self.FmyID6
        self.present(dailypage!, animated: false, completion: nil)
    }
    @IBAction func clickVitalRecod(_ sender: UIButton) {
        let vitalpage = storyboard?.instantiateViewController(withIdentifier: "VitalStatusRecordVC") as? VitalStatusRecordVC
        vitalpage?.FmyID4 = self.FmyID6
        self.present(vitalpage!, animated: false, completion: nil)
    }
    @IBAction func clickAIRecord(_ sender: UIButton) {
        let AIpage = storyboard?.instantiateViewController(withIdentifier: "AIStatusRecordVC") as? AIStatusRecordVC
        AIpage?.FmyID5 = self.FmyID6
        self.present(AIpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "AboutUsVC") as? AboutUsVC
        aboutuspage?.AboutmyID = self.FmyID6
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func clickHelpSupport(_ sender: UIButton) {
        if Hamburger.isHidden == false{
            Hamburger.isHidden = true
        }
    }
    
    //logoutIcon
    @IBAction func LogoutIcon(_ sender: UIButton) {
        
        DoubleConfirm(userMessage: "Are you sure to logout?")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "OK", style: .default, handler:{(action) in
            
            if UserDefaults.standard.bool(forKey: "test") == true{
                UserDefaults.standard.set(false, forKey: "test")
            }
            UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
            UserDefaults.standard.set(false, forKey: "AutoLoginON")
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.FmyID6).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.FmyID6).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        
        self.present(confirm, animated: true, completion: nil)
    }
    
    
    var FmyID6 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
