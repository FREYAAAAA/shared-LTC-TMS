//
//  F TaskInstructionVC.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/8/20.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class F_TaskInstructionVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    var ref:DatabaseReference!
    
    //tableview setting
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == taskTBV{
            if isSeaching{
                return searchtask.count
            }
            return tasklist.count
        }
        else{
            return typelist.count
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == taskTBV{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellIDB", for: indexPath) as! FTableViewB
            if isSeaching{
                cell.textLabel?.text = searchtask[indexPath.row].mission
                
                return cell
            }else{
                
                cell.textLabel?.text = tasklist[indexPath.row].mission
                
                return cell
            }
        }
        else{
            //let cell = UITableViewCell(style: .default, reuseIdentifier: cellID)
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellIDS", for: indexPath) as! FTableViewS
            cell.textLabel?.text = typelist[indexPath.row].typeAry
            
            
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == typeTBV{
            selectBottom.setTitle("\(typelist[indexPath.row].typeAry!)", for: .normal)
            UIView.animate(withDuration: 0.3) {
                self.typeTBV.isHidden = true
                
                tasklist.removeAll()
                
                Database.database().reference().child("Patient").child(self.UID.text!).child("Task").child("\(typelist[indexPath.row].typeAry!)").observe(.childAdded, with: { (snapshot) in
                    
                    let task = event()
                    task.mission = snapshot.key
                    
                    tasklist.append(task)
                    self.taskTBV.reloadData()
                    
                }, withCancel: nil)
            }
        }
        else{
            if isSeaching{
                if (FSearchTaskBar.text?.isEmpty)!{
                    if selectBottom.titleLabel?.text == "Select Instruction Type"{
                        
                        let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                        detailpage?.myname = tasklist[indexPath.row].mission
                        detailpage?.mytype = tasklist[indexPath.row].url
                        self.present(detailpage!, animated: true, completion: nil)
                    }
                    else{
                        let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                        detailpage?.myname = tasklist[indexPath.row].mission
                        detailpage?.mytype = (selectBottom.titleLabel?.text)!
                        self.present(detailpage!, animated: true, completion: nil)
                    }
                }
                else{
                    if selectBottom.titleLabel?.text == "Select Instruction Type"{
                        let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                        detailpage?.myname = searchtask[indexPath.row].mission
                        detailpage?.mytype = searchtask[indexPath.row].url
                        self.present(detailpage!, animated: true, completion: nil)
                    }
                    else{
                        let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                        detailpage?.myname = searchtask[indexPath.row].mission
                        detailpage?.mytype = (selectBottom.titleLabel?.text)!
                        self.present(detailpage!, animated: true, completion: nil)
                    }
                }
            }
            else{
                if selectBottom.titleLabel?.text == "Select Instruction Type"{
                    
                    let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                    detailpage?.myname = tasklist[indexPath.row].mission
                    detailpage?.mytype = tasklist[indexPath.row].url
                    self.present(detailpage!, animated: true, completion: nil)
                }
                else{
                    let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                    detailpage?.myname = tasklist[indexPath.row].mission
                    detailpage?.mytype = (selectBottom.titleLabel?.text)!
                    self.present(detailpage!, animated: true, completion: nil)
                }
            }
        }
    }
    
    //SelectType bottom
    @IBOutlet weak var selectBottom: UIButton!
    @IBAction func clickonBottom(_ sender: UIButton) {
        if typeTBV.isHidden == true{
            UIView.animate(withDuration: 0.3) {
                self.typeTBV.isHidden = false
            }
        }
        else{
            UIView.animate(withDuration: 0.3) {
                self.typeTBV.isHidden = true
            }
        }
        
    }
    
    //tableviewcell data fetching
    @IBOutlet weak var typeTBV: UITableView!
    @IBOutlet weak var taskTBV: UITableView!
    func fetchTask() {
        Database.database().reference().child("Patient").child(UID.text!).child("Task").observe(.childAdded, with: { (snapshot1) in
            if snapshot1.hasChildren(){
                for snap in snapshot1.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        //                              let data = node.value as? String
                        
                        let tasks = event()
                        tasks.mission = tag
                        tasks.url = snapshot1.key
                        
                        
                        tasklist.append(tasks)
                        self.taskTBV.reloadData()
                        
                    }
                }
            }
        }, withCancel: nil)
    }
    func fetchType() {
        Database.database().reference().child("Patient").child(UID.text!).child("Task").observe(.childAdded, with: { (snapshot) in
            let types = typeAry2()
            types.typeAry = snapshot.key
            
            typelist.append(types)
            self.typeTBV.reloadData()
        }, withCancel: nil)
    }
    
    
    
    //searchbar
    var searchtask = [event]()
    var isSeaching = false
    @IBOutlet weak var FSearchTaskBar: UISearchBar!
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isSeaching = true
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        isSeaching = false
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        isSeaching = false
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

        guard !searchText.isEmpty else{
            searchtask = tasklist
            taskTBV.reloadData()
            return
        }
        searchtask = tasklist.filter({ (tasktypein) -> Bool in
            guard let text = searchBar.text?.lowercased() else {return false}
            return tasktypein.mission.lowercased().contains(text.lowercased())
        })
        taskTBV.reloadData()
        
    }
    
    //cancel bottom
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSeaching = false
        searchBar.text = ""
        
        FSearchTaskBar.endEditing(true)
        
        taskTBV.reloadData()
    }
    
    
    

    
        
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let familyhomepage = storyboard?.instantiateViewController(withIdentifier: "FamilyVC") as? FamilyVC
        familyhomepage?.FmyID = self.UID.text!
        self.present(familyhomepage!, animated: false, completion: nil)
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var Hamburger: UIStackView!
    @IBAction func HamburgerBottom(_ sender: UIButton) {
        if(Hamburger.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.Hamburger.window!.layer.add(transition, forKey: kCATransition)
            
            Hamburger.isHidden = false
        }
        else{
            Hamburger.isHidden = true
        }
    }
    @IBAction func clickPortfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "F_PortfolioVC") as? F_PortfolioVC
        portfoliopage?.FmyID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func clickTask(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "F_TaskInstructionVC") as? F_TaskInstructionVC
        taskpage?.FmyID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func clickDailyRecord(_ sender: UIButton) {
        let dailypage = storyboard?.instantiateViewController(withIdentifier: "DailyStatusRecordVC") as? DailyStatusRecordVC
        dailypage?.FmyID3 = self.UID.text!
        self.present(dailypage!, animated: false, completion: nil)
    }
    @IBAction func clickVitalRecod(_ sender: UIButton) {
        let vitalpage = storyboard?.instantiateViewController(withIdentifier: "VitalStatusRecordVC") as? VitalStatusRecordVC
        vitalpage?.FmyID4 = self.UID.text!
        self.present(vitalpage!, animated: false, completion: nil)
    }
    @IBAction func clickAIRecord(_ sender: UIButton) {
        let AIpage = storyboard?.instantiateViewController(withIdentifier: "AIStatusRecordVC") as? AIStatusRecordVC
        AIpage?.FmyID5 = self.UID.text!
        self.present(AIpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "AboutUsVC") as? AboutUsVC
        aboutuspage?.AboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "FHelpSupport") as? FHelpSupport
        helpmenu?.FmyID6 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        
        DoubleConfirm(userMessage: "Are you sure to logout?")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "OK", style: .default, handler:{(action) in
            
            if UserDefaults.standard.bool(forKey: "test") == true{
                UserDefaults.standard.set(false, forKey: "test")
            }
            UserDefaults.standard.set(false, forKey: "AutoLoginFAM")
            UserDefaults.standard.set(false, forKey: "AutoLoginON")
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.FmyID2).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.FmyID2).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    
    //userID tag
    @IBOutlet weak var UID: UILabel!
    var FmyID2 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UID.text = FmyID2
        
        
        tasklist.removeAll()
        fetchTask()
        typelist.removeAll()
        fetchType()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}



class FTableViewS: UITableViewCell {
    
}

class FTableViewB: UITableViewCell {
    
}
