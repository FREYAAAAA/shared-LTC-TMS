//
//  F PortfolioVC.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/8/20.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseStorage

class F_PortfolioVC: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    var infolist = [event]()
    let cellID = "cellID"
    var ref: DatabaseReference!
    
    @IBOutlet weak var portfolioTableview: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return infolist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: cellID)
        ref = Database.database().reference()
        cell.textLabel?.text = self.infolist[indexPath.row].mission
        cell.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
        
        if infolist[indexPath.row].mission == "Address"{
            cell.detailTextLabel?.text = self.infolist[indexPath.row].url
            cell.detailTextLabel?.textColor = UIColor.black
            cell.selectionStyle = .none
            cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20.0)
            cell.detailTextLabel?.numberOfLines = 0
        }else{
            cell.detailTextLabel?.text = self.infolist[indexPath.row].url
            cell.detailTextLabel?.textColor = UIColor.black
            cell.selectionStyle = .none
            cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20.0)
        }
        
        return cell
    }
    
    
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let familyhomepage = storyboard?.instantiateViewController(withIdentifier: "FamilyVC") as? FamilyVC
        familyhomepage?.FmyID = self.UID.text!
        self.present(familyhomepage!, animated: false, completion: nil)
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var Hamburger: UIStackView!
    @IBAction func HamburgerBottom(_ sender: UIButton) {
        if(Hamburger.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.Hamburger.window!.layer.add(transition, forKey: kCATransition)
            
            Hamburger.isHidden = false
        }
        else{
            Hamburger.isHidden = true
        }
    }
    @IBAction func clickPortfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "F_PortfolioVC") as? F_PortfolioVC
        portfoliopage?.FmyID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func clickTask(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "F_TaskInstructionVC") as? F_TaskInstructionVC
        taskpage?.FmyID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func clickDailyRecord(_ sender: UIButton) {
        let dailypage = storyboard?.instantiateViewController(withIdentifier: "DailyStatusRecordVC") as? DailyStatusRecordVC
        dailypage?.FmyID3 = self.UID.text!
        self.present(dailypage!, animated: false, completion: nil)
    }
    @IBAction func clickVitalRecod(_ sender: UIButton) {
        let vitalpage = storyboard?.instantiateViewController(withIdentifier: "VitalStatusRecordVC") as? VitalStatusRecordVC
        vitalpage?.FmyID4 = self.UID.text!
        self.present(vitalpage!, animated: false, completion: nil)
    }
    @IBAction func clickAIRecord(_ sender: UIButton) {
        let AIpage = storyboard?.instantiateViewController(withIdentifier: "AIStatusRecordVC") as? AIStatusRecordVC
        AIpage?.FmyID5 = self.UID.text!
        self.present(AIpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "AboutUsVC") as? AboutUsVC
        aboutuspage?.AboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "FHelpSupport") as? FHelpSupport
        helpmenu?.FmyID6 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        
        DoubleConfirm(userMessage: "Are you sure to logout?")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "OK", style: .default, handler:{(action) in
            
            if UserDefaults.standard.bool(forKey: "test") == true{
                UserDefaults.standard.set(false, forKey: "test")
            }
            UserDefaults.standard.set(false, forKey: "AutoLoginFAM")
            UserDefaults.standard.set(false, forKey: "AutoLoginON")
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.FmyID1).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.FmyID1).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
     @IBOutlet weak var Image: UIImageView!
    
    //userID tag
    @IBOutlet weak var UID: UILabel!
    var FmyID1 = String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        UID.text = FmyID1
        
        ref = Database.database().reference()
        fetchdata()
        
        //Image.image = UIImage(named: "MCULOGO")
        ref.child("Patient").child(UID.text!).child("Portfolio").child("pictureurl").observe(.value, with: { (snapshot) in
            let url = URL(string: snapshot.value as! String)
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                if error != nil{
                    print(error!)
                    return
                }
                DispatchQueue.main.async {
                    self.Image.image = UIImage(data: data!)
                }
                }.resume()
        }, withCancel: nil)
        
        ref.child("Patient").child(UID.text!).child("Portfolio").child("Name").observe(.value, with: { (snapshot) in
            self.NameLB.text = snapshot.value as? String
        }, withCancel: nil)
        ref.child("Patient").child(UID.text!).child("Portfolio").child("Gender").observe(.value, with: { (snapshot) in
            self.GenderLB.text = snapshot.value as? String
        }, withCancel: nil)
        ref.child("Patient").child(UID.text!).child("Portfolio").child("Nationality").observe(.value, with: { (snapshot) in
            self.NationalityLB.text = snapshot.value as? String
        }, withCancel: nil)
    }
    
    //portfolio
    @IBOutlet weak var NameLB: UILabel!
    @IBOutlet weak var GenderLB: UILabel!
    @IBOutlet weak var NationalityLB: UILabel!
    func fetchdata(){
        Database.database().reference().child("Patient").child(UID.text!).child("Portfolio").observe(.value, with: { (snapshot) in
            //print(snapshot.childrenCount)
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        let content = node.value
                        
                        let info = event()
                        info.mission = tag
                        info.url = content as? String
                        
                        let x = "pictureurl"
                        let y = "Nationality"
                        let z = "Name"
                        let r = "Gender"
                        let w = "Password"
                        
                        if x != info.mission && y != info.mission && z != info.mission && r != info.mission && w != info.mission {
                            self.infolist.append(info)
                            self.portfolioTableview.reloadData()
                        }
                    }
                }
            }
        }, withCancel: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
