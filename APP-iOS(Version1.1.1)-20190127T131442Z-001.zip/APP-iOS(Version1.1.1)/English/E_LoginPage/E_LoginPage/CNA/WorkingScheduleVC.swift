//
//  WorkingScheduleVC.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/8/17.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class WorkingScheduleVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    var schedulelist = [event]()
    
    @IBOutlet weak var scheduleTBV: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSeaching{
            return searchtask.count
        }
        return schedulelist.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as! scheduleCell
        if isSeaching{
            cell.textLabel?.text = searchtask[indexPath.row].mission
            
            return cell
        }else{
            cell.textLabel?.text = schedulelist[indexPath.row].mission
            
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let url = schedulelist[indexPath.row].url
        UIApplication.shared.open(URL(string: url!)!, options: [:], completionHandler: nil)
    }
    
    
    //searchbar
    var searchtask = [event]()
    var isSeaching = false
    @IBOutlet weak var searchTaskBar: UISearchBar!
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isSeaching = true
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        isSeaching = false
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        isSeaching = false
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else{
            searchtask = schedulelist
            scheduleTBV.reloadData()
            return
        }
        searchtask = schedulelist.filter({ (letterstype) -> Bool in
            guard let text = searchBar.text?.lowercased() else {return false}
            return letterstype.mission.lowercased().contains(text.lowercased())
        })
        scheduleTBV.reloadData()
    }
    
    //cancel bottom
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSeaching = false
        searchBar.text = ""
        
        searchTaskBar.endEditing(true)
        
        scheduleTBV.reloadData()
    }
    
    
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let CNAhomepage = storyboard?.instantiateViewController(withIdentifier: "CNAVC") as? CNAVC
        CNAhomepage?.myID = self.UID.text!
        self.present(CNAhomepage!, animated: false, completion: nil)
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var HBpage: UIStackView!
    @IBAction func HamburgerPageIcon(_ sender: UIButton) {
        if(HBpage.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.HBpage.window!.layer.add(transition, forKey: kCATransition)
            
            HBpage.isHidden = false
        }
        else{
            HBpage.isHidden = true
        }
    }
    @IBAction func Portfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "PortfolioVC") as? PortfolioVC
        portfoliopage?.myID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func Task(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionVC") as? TaskInstructionVC
        taskpage?.myID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func workingschedule(_ sender: UIButton) {
        let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "WorkingScheduleVC") as? WorkingScheduleVC
        workingschedulepage?.myID3 = self.UID.text!
        self.present(workingschedulepage!, animated: false, completion: nil)
    }
    @IBAction func workinghour(_ sender: UIButton) {
        let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "WorkingHourVC") as? WorkingHourVC
        workinghourpage?.myID4 = self.UID.text!
        self.present(workinghourpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "CNAAboutUsVC") as? CNAAboutUsVC
        aboutuspage?.CNAAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "help_support") as? help_support
        helpmenu?.myID5 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        
        DoubleConfirm(userMessage: "Are you sure to logout?")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "OK", style: .default, handler:{(action) in
            
            if UserDefaults.standard.bool(forKey: "test") == true{
                UserDefaults.standard.set(false, forKey: "test")
            }
            UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
            UserDefaults.standard.set(false, forKey: "AutoLoginON")
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.myID3).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.myID3).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    

    //userID tag
    @IBOutlet weak var UID: UILabel!
    var myID3 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //userID tag
        UID.text = myID3
        
        fetchschedule()
        
        //MonthFile.isHidden = true
    }
    func fetchschedule(){
        Database.database().reference().child("WorkingSchedule").observe(.childAdded, with: { (snapshot) in
            let scheduledata = event()
            
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        let data = node.value as? String
                        
                        if tag == "titleIOS"{
                            scheduledata.mission = data!
                        }else if tag == "url"{
                            scheduledata.url = data!
                        }
                    }
                }
            }
            
            self.schedulelist.append(scheduledata)
            self.scheduleTBV.reloadData()
            
        }, withCancel: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

class scheduleCell: UITableViewCell {
}
