//
//  TaskInstructionVC.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/8/17.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

var tasklist = [event]()
var typelist = [typeAry2]()
var myIndex = 0

class TaskInstructionVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
     var ref:DatabaseReference!
    
     //tableview setting
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
          if tableView == taskTBV{
               if isSeaching{
                    return searchtask.count
               }
               return tasklist.count
          }
          else{
               return typelist.count
          }
     }
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
          return 56
     }
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          if tableView == taskTBV{
               let cell = tableView.dequeueReusableCell(withIdentifier: "cellIDB", for: indexPath) as! TableViewB
               if isSeaching{
                    ref = Database.database().reference()
                    cell.textLabel?.text = searchtask[indexPath.row].mission

                    return cell
               }else{
                    ref = Database.database().reference()
                    cell.textLabel?.text = tasklist[indexPath.row].mission
                    
                    return cell
               }
          }
          else{
               //let cell = UITableViewCell(style: .default, reuseIdentifier: cellID)
               let cell = tableView.dequeueReusableCell(withIdentifier: "cellIDS", for: indexPath) as! TableViewS
               cell.textLabel?.text = typelist[indexPath.row].typeAry


               return cell
          }
     }
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          if tableView == typeTBV{
               selectBottom.setTitle("\(typelist[indexPath.row].typeAry!)", for: .normal)
               UIView.animate(withDuration: 0.3) {
                    self.typeTBV.isHidden = true
                    
                    tasklist.removeAll()
                    
                    self.ref.child("CNA").child(self.UID.text!).child("Task").child("\(typelist[indexPath.row].typeAry!)").observe(.childAdded, with: { (snapshot) in
                         
                         let task = event()
                         task.mission = snapshot.key

                         tasklist.append(task)
                         self.taskTBV.reloadData()
                         
                    }, withCancel: nil)
               }
          }
          else{
               if isSeaching{
                    if (searchTaskBar.text?.isEmpty)!{
                         if selectBottom.titleLabel?.text == "Select Instruction Type"{
                              
                              let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                              detailpage?.myname = tasklist[indexPath.row].mission
                              detailpage?.mytype = tasklist[indexPath.row].url
                              self.present(detailpage!, animated: true, completion: nil)
                         }
                         else{
                              let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                              detailpage?.myname = tasklist[indexPath.row].mission
                              detailpage?.mytype = (selectBottom.titleLabel?.text)!
                              self.present(detailpage!, animated: true, completion: nil)
                         }
                    }else{
                         if selectBottom.titleLabel?.text == "Select Instruction Type"{
                              let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                              detailpage?.myname = searchtask[indexPath.row].mission
                              detailpage?.mytype = searchtask[indexPath.row].url
                              self.present(detailpage!, animated: true, completion: nil)
                         }
                         else{
                              let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                              detailpage?.myname = searchtask[indexPath.row].mission
                              detailpage?.mytype = (selectBottom.titleLabel?.text)!
                              self.present(detailpage!, animated: true, completion: nil)
                         }
                    }
               }
               else{
                    if selectBottom.titleLabel?.text == "Select Instruction Type"{
                         
                         let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                         detailpage?.myname = tasklist[indexPath.row].mission
                         detailpage?.mytype = tasklist[indexPath.row].url
                         self.present(detailpage!, animated: true, completion: nil)
                    }
                    else{
                         let detailpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionP2") as? TaskInstructionP2
                         detailpage?.myname = tasklist[indexPath.row].mission
                         detailpage?.mytype = (selectBottom.titleLabel?.text)!
                         self.present(detailpage!, animated: true, completion: nil)
                    }
               }
          }
     }
     
     //SelectType bottom
     @IBOutlet weak var selectBottom: UIButton!
     @IBAction func clickonBottom(_ sender: UIButton) {
          if typeTBV.isHidden == true{
               UIView.animate(withDuration: 0.3) {
                    self.typeTBV.isHidden = false
               }
          }
          else{
               UIView.animate(withDuration: 0.3) {
                    self.typeTBV.isHidden = true
               }
          }
          
     }
     
     //tableviewcell data fetching
     @IBOutlet weak var typeTBV: UITableView!
     @IBOutlet weak var taskTBV: UITableView!
     func fetchTask() {
          ref.child("CNA").child(UID.text!).child("Task").observe(.childAdded, with: { (snapshot1) in
               if snapshot1.hasChildren(){
                    for snap in snapshot1.children{
                         if let node = snap as? DataSnapshot{
                              let tag = node.key
//                              let data = node.value as? String
                              
                              let tasks = event()
                              tasks.mission = tag
                              tasks.url = snapshot1.key
                              
                              
                              tasklist.append(tasks)
                              self.taskTBV.reloadData()
                              
                         }
                    }
               }
          }, withCancel: nil)
//          ref.child("TaskInstruction").observe(.childAdded, with: { (snapshot) in
//               if snapshot.hasChildren(){
//                    for snap in snapshot.children{
//                         if let node = snap as? DataSnapshot{
//                              let tag = node.key
//
//                              let tasks = event()
//                              tasks.mission = tag
//                              tasks.url = snapshot.key
//
//                              print(tasks.url)
//                         }
//                    }
//               }
//          }, withCancel: nil)
     }
     func fetchType() {
          ref.child("CNA").child(UID.text!).child("Task").observe(.childAdded, with: { (snapshot) in
               let types = typeAry2()
               types.typeAry = snapshot.key
               
               typelist.append(types)
               self.typeTBV.reloadData()
          }, withCancel: nil)
     }
     
     
     
     //searchbar
     var searchtask = [event]()
     var isSeaching = false
     @IBOutlet weak var searchTaskBar: UISearchBar!
     func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
          isSeaching = true
     }
     func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
          isSeaching = false
     }
     func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
          isSeaching = false
     }
     func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//          searchtask.removeAll(keepingCapacity: false)
//          let predicate = searchBar.text!
//          searchtask = tasklist.filter({$0.mission.lowercased().range(of: predicate.lowercased()) != nil})
//          searchtask.sort {$0.mission < $1.mission}
//          isSeaching = (searchtask.count == 0) ? false:true
//
//          taskTBV.reloadData()
//
//          let searchbarStyle = searchBar.value(forKey: "searchField") as? UITextField
//          searchbarStyle?.clearButtonMode = .never
          guard !searchText.isEmpty else{
               searchtask = tasklist
               taskTBV.reloadData()
               return
          }
          searchtask = tasklist.filter({ (tasktypein) -> Bool in
               guard let text = searchBar.text?.lowercased() else {return false}
               return tasktypein.mission.lowercased().contains(text.lowercased())
          })
          taskTBV.reloadData()
     }
     
     //cancel bottom
     func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
          isSeaching = false
          searchBar.text = ""
        
          searchTaskBar.endEditing(true)
        
          taskTBV.reloadData()
     }
     
     
     

     //homeIcon
     @IBAction func homeIcon(_ sender: UIButton) {
          let CNAhomepage = storyboard?.instantiateViewController(withIdentifier: "CNAVC") as? CNAVC
          CNAhomepage?.myID = self.UID.text!
          self.present(CNAhomepage!, animated: false, completion: nil)
     }
     
     //hamburgerIcon
     @IBOutlet weak var HBpage: UIStackView!
     @IBAction func HamburgerPageIcon(_ sender: UIButton) {
          if(HBpage.isHidden == true){
               let transition = CATransition()
               transition.duration = 0.15
               self.HBpage.window!.layer.add(transition, forKey: kCATransition)
               
               HBpage.isHidden = false
          }
          else{
               HBpage.isHidden = true
          }
     }
     @IBAction func Portfolio(_ sender: UIButton) {
          let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "PortfolioVC") as? PortfolioVC
          portfoliopage?.myID1 = self.UID.text!
          self.present(portfoliopage!, animated: false, completion: nil)
     }
     @IBAction func Task(_ sender: UIButton) {
          let taskpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionVC") as? TaskInstructionVC
          taskpage?.myID2 = self.UID.text!
          self.present(taskpage!, animated: false, completion: nil)
     }
     @IBAction func workingschedule(_ sender: UIButton) {
          let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "WorkingScheduleVC") as? WorkingScheduleVC
          workingschedulepage?.myID3 = self.UID.text!
          self.present(workingschedulepage!, animated: false, completion: nil)
     }
     @IBAction func workinghour(_ sender: UIButton) {
          let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "WorkingHourVC") as? WorkingHourVC
          workinghourpage?.myID4 = self.UID.text!
          self.present(workinghourpage!, animated: false, completion: nil)
     }
     @IBAction func aboutus(_ sender: UIButton) {
          let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "CNAAboutUsVC") as? CNAAboutUsVC
          aboutuspage?.CNAAboutmyID = self.UID.text!
          self.present(aboutuspage!, animated: false, completion: nil)
     }

     
     //help & support
     @IBAction func help(_ sender: UIButton) {
          let helpmenu = storyboard?.instantiateViewController(withIdentifier: "help_support") as? help_support
          helpmenu?.myID5 = self.UID.text!
          self.present(helpmenu!, animated: false, completion: nil)
     }
 
     //logoutIcon
     @IBAction func logoutIcon(_ sender: UIButton) {
          
          DoubleConfirm(userMessage: "Are you sure to logout?")
     }
     func DoubleConfirm(userMessage:String){
        
          let login = storyboard?.instantiateViewController(withIdentifier: "LoginVC")
        
          let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
          confirm.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
          //換到 LoginPage
          confirm.addAction(UIAlertAction(title: "OK", style: .default, handler:{(action) in
               
               if UserDefaults.standard.bool(forKey: "test") == true{
                    UserDefaults.standard.set(false, forKey: "test")
               }
               UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
               UserDefaults.standard.set(false, forKey: "AutoLoginON")
               
               let formatter1 = DateFormatter()
               formatter1.dateFormat = "yyyy-MM-dd"
               let str = formatter1.string(from: Date())
               
               let formatter2 = DateFormatter()
               formatter2.dateFormat = "HH:mm:ss"
               let str2 = formatter2.string(from: Date())
               Database.database().reference().child("AccountStatus").child("App").child(self.myID2).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
               Database.database().reference().child("AccountStatus").child("App").child(self.myID2).child("LatestLogout").setValue("\(str)-\(str2)")
               
               self.present(login!, animated: true, completion:    nil)}))
          present(confirm, animated: true, completion: nil)
     }
     
     
     
     @IBOutlet weak var UID: UILabel!
     var myID2 = String()
    
     override func viewDidLoad() {
          super.viewDidLoad()
        
          UID.text = myID2
        

        
          ref = Database.database().reference()
          tasklist.removeAll()
          fetchTask()
          typelist.removeAll()
          fetchType()
     
     }

     override func didReceiveMemoryWarning() {
          super.didReceiveMemoryWarning()
          // Dispose of any resources that can be recreated.
     }

}



class TableViewS: UITableViewCell {
     
}

class TableViewB: UITableViewCell {
     
}
