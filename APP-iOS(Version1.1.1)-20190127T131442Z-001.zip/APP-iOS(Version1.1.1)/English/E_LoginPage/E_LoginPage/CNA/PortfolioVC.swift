//
//  PortfolioVC.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/8/15.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseStorage

class PortfolioVC: UIViewController, UITableViewDelegate, UITableViewDataSource  {
    
    var infolist = [event]()
    //let cellID = "cellID"
    var ref: DatabaseReference!
    
    @IBOutlet weak var portfolioTableview: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return infolist.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as! portfolioCNATBV
        ref = Database.database().reference()
        
        cell.textLabel?.text = self.infolist[indexPath.row].mission
        cell.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
        
        if infolist[indexPath.row].mission == "CV" || infolist[indexPath.row].mission == "License"{
            cell.detailTextLabel?.text = "Tap to view detail."
            cell.detailTextLabel?.textColor = UIColor.red
            cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20.0)
        }else{
            if infolist[indexPath.row].mission == "Address"{
                cell.detailTextLabel?.text = self.infolist[indexPath.row].url
                cell.detailTextLabel?.textColor = UIColor.black
                cell.selectionStyle = .none
                cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20.0)
                cell.detailTextLabel?.numberOfLines = 0
            }else{
                cell.detailTextLabel?.text = self.infolist[indexPath.row].url
                cell.detailTextLabel?.textColor = UIColor.black
                cell.selectionStyle = .none
                cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20.0)
            }
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if infolist[indexPath.row].mission == "CV" || infolist[indexPath.row].mission == "License"{
            let website = infolist[indexPath.row].url
            if website != nil{
                UIApplication.shared.open(URL(string: website!)!, options: [:], completionHandler: nil)
            }
        }
    }
    
    
    
 
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let CNAhomepage = storyboard?.instantiateViewController(withIdentifier: "CNAVC") as? CNAVC
        CNAhomepage?.myID = self.UID.text!
        self.present(CNAhomepage!, animated: false, completion: nil)
    }
    
    //hamburgerIcon
    @IBOutlet weak var HBpage: UIStackView!
    @IBAction func HamburgerPageIcon(_ sender: UIButton) {
        if(HBpage.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.HBpage.window!.layer.add(transition, forKey: kCATransition)
            
            HBpage.isHidden = false
        }
        else{
            HBpage.isHidden = true
        }
    }
    @IBAction func Portfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "PortfolioVC") as? PortfolioVC
        portfoliopage?.myID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func Task(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionVC") as? TaskInstructionVC
        taskpage?.myID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func workingschedule(_ sender: UIButton) {
        let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "WorkingScheduleVC") as? WorkingScheduleVC
        workingschedulepage?.myID3 = self.UID.text!
        self.present(workingschedulepage!, animated: false, completion: nil)
    }
    @IBAction func workinghour(_ sender: UIButton) {
        let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "WorkingHourVC") as? WorkingHourVC
        workinghourpage?.myID4 = self.UID.text!
        self.present(workinghourpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "CNAAboutUsVC") as? CNAAboutUsVC
        aboutuspage?.CNAAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "help_support") as? help_support
        helpmenu?.myID5 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        
        DoubleConfirm(userMessage: "Are you sure to logout?")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "OK", style: .default, handler:{(action) in
            
            if UserDefaults.standard.bool(forKey: "test") == true{
                UserDefaults.standard.set(false, forKey: "test")
            }
            UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
            UserDefaults.standard.set(false, forKey: "AutoLoginON")
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.myID1).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.myID1).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    

    @IBOutlet weak var Image: UIImageView!
    
    //userID tag1
    @IBOutlet weak var UID: UILabel!
    var myID1 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //useerID tag2
        UID.text = myID1
        
        //portfolio List
        ref = Database.database().reference()
        fetchdata()

        ref.child("CNA").child(UID.text!).child("Portfolio").child("pictureurl").observe(.value, with: { (snapshot) in
            let url = URL(string: snapshot.value as! String)
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                if error != nil{
                    print(error!)
                    return
                }
                DispatchQueue.main.async {
                    self.Image.image = UIImage(data: data!)
                }
                }.resume()
        }, withCancel: nil)
        
        ref.child("CNA").child(UID.text!).child("Portfolio").child("Name").observe(.value, with: { (snapshot) in
            self.NameLB.text = snapshot.value as? String
        }, withCancel: nil)
        ref.child("CNA").child(UID.text!).child("Portfolio").child("Gender").observe(.value, with: { (snapshot) in
            self.GenderLB.text = snapshot.value as? String
        }, withCancel: nil)
        ref.child("CNA").child(UID.text!).child("Portfolio").child("Nationality").observe(.value, with: { (snapshot) in
            self.NationalityLB.text = snapshot.value as? String
        }, withCancel: nil)
        
    }
    
    //portfolio
    @IBOutlet weak var NameLB: UILabel!
    @IBOutlet weak var GenderLB: UILabel!
    @IBOutlet weak var NationalityLB: UILabel!
    func fetchdata(){
    Database.database().reference().child("CNA").child(UID.text!).child("Portfolio").observe(.value, with: { (snapshot) in
            //print(snapshot.childrenCount)
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        let content = node.value
                        
                        let info = event()
                        info.mission = tag
                        info.url = content as? String
                        
                        let x = "pictureurl"
                        let y = "Nationality"
                        let z = "Name"
                        let r = "Gender"
                        let w = "Password"
                        
                        if x != info.mission && y != info.mission && z != info.mission && r != info.mission && w != info.mission {
                            self.infolist.append(info)
                            self.portfolioTableview.reloadData()
                        }
                    }
                }
            }
        }, withCancel: nil)
    }

    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        
        
        // Dispose of any resources that can be recreated.
    }

}

class portfolioCNATBV: UITableViewCell {
    
}
