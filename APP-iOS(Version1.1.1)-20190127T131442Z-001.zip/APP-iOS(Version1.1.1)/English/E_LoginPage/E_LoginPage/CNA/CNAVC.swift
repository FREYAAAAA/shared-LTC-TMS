//
//  CNAViewController.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/8/6.
//  Copyright © 2018年 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseStorage

class CNAVC: UIViewController, UITableViewDelegate, UITableViewDataSource{

    var ref: DatabaseReference!
    
    //AnnouncementBoard
    var eventlist = [event]()
    let cellID = "cellID"
    @IBOutlet weak var announcementboard: UITableView!
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return eventlist.count
    }
    @IBOutlet weak var showAnnouncement: UITextView!
    var myindex = 0
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let cell = announcementboard.dequeueReusableCell(withIdentifier: cellID, for: indexPath)
        ref = Database.database().reference()
        cell.textLabel?.text = self.eventlist[indexPath.row].mission
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        showAnnouncement.text = eventlist[indexPath.row].url
    }
    
    
    @IBAction func schedule(_ sender: UIButton) {

        Database.database().reference().child("CenterSchedule").observe(.childAdded, with: { (snapshot) in
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        if tag == "url"{
                            let url = node.value as? String
                            UIApplication.shared.open(URL(string: url!)!, options: [:], completionHandler: nil)
                        }
                    }
                }
            }
        }, withCancel: nil)
    }
    
    

    //homeIcon
    @IBAction func HomeIcon(_ sender: UIButton) {
        
        eventlist.removeAll()
        
        //refresh ViewController to first response
        let parent = view.superview
        view.removeFromSuperview()
        view = nil
        parent?.addSubview(view)
        
        if(HBpage.isHidden == false){
            HBpage.isHidden = true
        }        
    }
    

    //hamburgerIcon
    @IBOutlet weak var HBpage: UIStackView!
    @IBAction func HamburgerPageIcon(_ sender: UIButton) {
        if(HBpage.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.HBpage.window!.layer.add(transition, forKey: kCATransition)
            
            HBpage.isHidden = false
        }
        else{
           HBpage.isHidden = true
        }
    }
    @IBAction func Portfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "PortfolioVC") as? PortfolioVC
        portfoliopage?.myID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func Task(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "TaskInstructionVC") as? TaskInstructionVC
        taskpage?.myID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func workingschedule(_ sender: UIButton) {
        let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "WorkingScheduleVC") as? WorkingScheduleVC
        workingschedulepage?.myID3 = self.UID.text!
        self.present(workingschedulepage!, animated: false, completion: nil)
    }
    @IBAction func workinghour(_ sender: UIButton) {
        let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "WorkingHourVC") as? WorkingHourVC
        workinghourpage?.myID4 = self.UID.text!
        self.present(workinghourpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "CNAAboutUsVC") as? CNAAboutUsVC
        aboutuspage?.CNAAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "help_support") as? help_support
        helpmenu?.myID5 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func LogoutIcon(_ sender: UIButton) {
        
        DoubleConfirm(userMessage: "Are you sure to logout?")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "OK", style: .default, handler:{(action) in
            
            if UserDefaults.standard.bool(forKey: "test") == true{
                UserDefaults.standard.set(false, forKey: "test")
            }
            UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
            UserDefaults.standard.set(false, forKey: "AutoLoginON")
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            
            Database.database().reference().child("AccountStatus").child("App").child(self.myID).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.myID).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        
        self.present(confirm, animated: true, completion: nil)
    }
    
    
    
    /*func alertMessage(userMessage:String){
        let alert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: .alert)
        let okaction = UIAlertAction(title: "ok", style: .default, handler: nil)
        alert.addAction(okaction)
        self.present(alert, animated: true, completion: nil)
    }*/    
    
    
    //userID tag
    @IBOutlet weak var UID: UILabel!
    var myID = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        showAnnouncement.isEditable = false
        
        //userID tag
        UID.text = myID
        
        //announcemnet
        ref = Database.database().reference()
        fetchEvent()
        
    }
    
    
    //AnnouncementBoard
    func fetchEvent(){
        ref.child("Announcements").observe(.childAdded, with: { (snapshot) in
            if let dictionary = snapshot.value as? [String:AnyObject]{
            
                let events = event()
                events.mission = dictionary["ATitleIOS"] as? String
                events.url = dictionary["AnnouncementIOS"] as? String
                
                /*let str = events.mission
                let start: String.Index = str!.startIndex
                let start3: String.Index = str!.index(start, offsetBy: 3)
                let afterstart3 = str!.index(after: start3)..<str!.endIndex
                var q = String(str![afterstart3])
                
                let end: String.Index = q.endIndex
                let endword: String.Index = q.index(before: end)
                let end4: String.Index = q.index(endword, offsetBy: -4)
                let afterend4 = q.index(after: end4)..<q.endIndex
                
                q.removeSubrange(afterend4)
                
                events.mission = q*/
                
                self.eventlist.append(events)
                self.announcementboard.reloadData()
            }
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
