//
//  helpMenuPage.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/5.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import Foundation
import UIKit

class helpMenuPage: UINavigationController {
    <#code#>
}
