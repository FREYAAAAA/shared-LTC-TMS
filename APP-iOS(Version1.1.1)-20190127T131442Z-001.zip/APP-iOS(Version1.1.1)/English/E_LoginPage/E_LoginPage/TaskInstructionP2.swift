//
//  TaskInstructionP2.swift
//  E_LoginPage
//
//  Created by 林庭鋒 on 2018/9/27.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class TaskInstructionP2: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var stepsAry = [event]()
    @IBOutlet weak var steplist: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stepsAry.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as! StepsTB
        cell.textLabel?.text = stepsAry[indexPath.row].url
        cell.textLabel?.numberOfLines = 0
        
        return cell
    }
    @IBOutlet weak var StepTitle: UILabel!
    @IBOutlet weak var descriptionField: UITextView!
    @IBOutlet weak var imageURL: UIImageView!
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        StepTitle.text = " "
        descriptionField.text = " "
        imageURL.image = nil
        Database.database().reference().child("TaskInstruction").child(mytype).child(myname).child(stepsAry[indexPath.row].mission).observe(.childAdded, with: { (snapshot) in
            if snapshot.key == "MtitleIOS"{
                self.StepTitle.text = snapshot.value as? String
            }
            else if snapshot.key == "MDescriptionIOS"{
                self.descriptionField.text = snapshot.value as? String
            }
            else if snapshot.key == "picurl"{
                let url = URL(string: snapshot.value as! String)
                URLSession.shared.dataTask(with: url!) {(data, response, error) in
                    if error != nil{
                        return
                    }
                    DispatchQueue.main.async {
                        print(data!)
                        self.imageURL.image = UIImage(data: data!)
                    }
                    
                }.resume()
                
            }
        }, withCancel: nil)
    }
    @IBOutlet weak var taskTitle: UILabel!
    @IBOutlet weak var taskName: UILabel!
    @IBOutlet weak var taskType: UILabel!
    @IBOutlet weak var taskflied: UITextView!
    @IBOutlet weak var taskNote: UILabel!
    @IBOutlet weak var VideoReference: UIButton!
    @IBAction func clickURL(_ sender: UIButton) {
        Database.database().reference().child("TaskInstruction").child(mytype).child(myname).child("Info").child("videoURL").observe(.value, with: { (snapshot) in
            UIApplication.shared.open(URL(string: (snapshot.value as? String)!)!, options: [:], completionHandler: nil)
        }, withCancel: nil)
    }
    
    @IBAction func Cancel(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //GET STEPS
        fetchSteps()
        
        //GET INFO
        getName()
        getOutlineNote()
        getVideoURL()
    }
    
    func fetchSteps(){
        Database.database().reference().child("TaskInstruction").child(mytype).child(myname).observe(.childAdded, with: { (snapshot) in
            
            let steps = event()
            steps.mission = snapshot.key
            
            let x = "Info"
            if x != steps.mission{
                
                Database.database().reference().child("TaskInstruction").child(self.mytype).child(self.myname).child(steps.mission).observe(.childAdded, with: { (snapshot1) in
                    if snapshot1.key == "MtitleIOS"{
                        steps.url = "\(snapshot.key). \(snapshot1.value as! String)"
                        
                        self.stepsAry.append(steps)
                        self.steplist.reloadData()
                    }
                }, withCancel: nil)
            }
        }, withCancel: nil)
    }
    
    
    var myname = String()
    var mytype = String()
    
    //Title & Name & Type
    func getName(){
        taskTitle.text = myname
        taskName.text = myname
        taskType.text = "(\(mytype))"
    }
    
    //Outline & Note
    func getOutlineNote(){
        Database.database().reference().child("TaskInstruction").child(mytype).child(myname).child("Info").child("OutlineIOS").observe(.value, with: { (snapshot) in
            self.taskflied.text = snapshot.value as? String
        }, withCancel: nil)
        Database.database().reference().child("TaskInstruction").child(mytype).child(myname).child("Info").child("NoteIOS").observe(.value, with: { (snapshot) in
            self.taskNote.text = snapshot.value as? String
        }, withCancel: nil)
    }
    
    //VideoReference
    func getVideoURL(){
        Database.database().reference().child("TaskInstruction").child(mytype).child(myname).child("Info").child("videoURL").observe(.value, with: { (snapshot) in
            self.VideoReference.setTitle(snapshot.value as? String, for: .normal)
            self.VideoReference.setTitleColor(UIColor.blue, for: .normal)
        }, withCancel: nil)
    }
}

class StepsTB: UITableViewCell {
}
