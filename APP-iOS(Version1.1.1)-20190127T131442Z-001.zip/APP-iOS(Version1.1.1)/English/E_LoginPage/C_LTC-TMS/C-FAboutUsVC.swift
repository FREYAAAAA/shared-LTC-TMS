//
//  C-FAboutUsVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/15.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_FAboutUsVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var sponsorlist = [event]()
    
    @IBOutlet weak var SponsorListTBV: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sponsorlist.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as! sponsorlistTBV
        cell.textLabel?.text = sponsorlist[indexPath.row].mission
        cell.detailTextLabel?.text = sponsorlist[indexPath.row].url1
        
        if let sponsorImageUrl = sponsorlist[indexPath.row].url{
            let url = URL(string: sponsorImageUrl)
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                if error != nil{
                    print(error!)
                    return
                }
                DispatchQueue.main.async {
                    cell.sponsorImage.image = UIImage(data: data!)
                }
                }.resume()
            
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let website = sponsorlist[indexPath.row].url1
        UIApplication.shared.open(URL(string: website!)!, options: [:], completionHandler: nil)
    }
    
    
    
    //homeIcon
    @IBAction func homeIcon(_ sender: Any) {
        let familyhomepage = storyboard?.instantiateViewController(withIdentifier: "C_FamilyVC") as? C_FamilyVC
        familyhomepage?.CFmyID = self.UID.text!
        self.present(familyhomepage!, animated: false, completion: nil)
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var Hamburger: UIStackView!
    @IBAction func HamburgerBottom(_ sender: UIButton) {
        if(Hamburger.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.Hamburger.window!.layer.add(transition, forKey: kCATransition)
            
            Hamburger.isHidden = false
        }
        else{
            Hamburger.isHidden = true
        }
    }
    @IBAction func clickEPortfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_FPortfolioVC") as? C_FPortfolioVC
        portfoliopage?.CFmyID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func clickTask(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_FTaskInstructionVC") as? C_FTaskInstructionVC
        taskpage?.CFmyID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func clickDailyRecord(_ sender: UIButton) {
        let dailypage = storyboard?.instantiateViewController(withIdentifier: "C_DailyStatusVC") as? C_DailyStatusVC
        dailypage?.CFmyID3 = self.UID.text!
        self.present(dailypage!, animated: false, completion: nil)
    }
    @IBAction func clickVitalRecod(_ sender: UIButton) {
        let vitalpage = storyboard?.instantiateViewController(withIdentifier: "C_VitalStatusVC") as? C_VitalStatusVC
        vitalpage?.CFmyID4 = self.UID.text!
        self.present(vitalpage!, animated: false, completion: nil)
    }
    @IBAction func clickAIRecord(_ sender: UIButton) {
        let AIpage = storyboard?.instantiateViewController(withIdentifier: "C_AIStatusVC") as? C_AIStatusVC
        AIpage?.CFmyID5 = self.UID.text!
        self.present(AIpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_FAboutUsVC") as? C_FAboutUsVC
        aboutuspage?.CAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_FHelpSupport") as? C_FHelpSupport
        helpmenu?.CFmyID6 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginFAM")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.CAboutmyID).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CAboutmyID).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    
    @IBOutlet weak var UID: UILabel!
    var CAboutmyID = String()
    
    @IBOutlet weak var descriptionBox: UITextView!
    @IBOutlet weak var CenterName: UILabel!
    @IBOutlet weak var CenterEmail: UILabel!
    @IBOutlet weak var CenterContactNo: UILabel!
    @IBOutlet weak var CenterAddress: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.UID.text = CAboutmyID
        
        fetchsponsor()
        
        //Description
        Database.database().reference().child("CenterInformation").child("ContactInfo").child("Aboutus").observe(.value, with: { (snapshot) in
            self.descriptionBox.text = snapshot.value as? String
        }, withCancel: nil)
        
        //Info
        Database.database().reference().child("CenterInformation").child("ContactInfo").observe(.childAdded, with: { (snapshot) in
            if snapshot.key == "Name"{
                self.CenterName.text = "名稱: \(snapshot.value as! String)"
            }else if snapshot.key == "Email"{
                self.CenterEmail.text = "電子信箱: \(snapshot.value as! String)"
            }else if snapshot.key == "Contact No"{
                self.CenterContactNo.text = "聯絡電話: \(snapshot.value as! String)"
            }else if snapshot.key == "Address"{
                self.CenterAddress.text = "地址: \(snapshot.value as! String)"
            }
        }, withCancel: nil)
        
        SponsorListTBV.register(sponsorlistTBV.self, forCellReuseIdentifier: "cellID")
    }
    
    func fetchsponsor(){
        Database.database().reference().child("CenterInformation").child("Sponsor").observe(.childAdded, with: { (snapshot1) in
            let sponsorURL = event()
            sponsorURL.mission = snapshot1.key
            
            if snapshot1.hasChildren(){
                for snap in snapshot1.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        if tag == "photo"{
                            let Imageurl = node.value as? String
                            sponsorURL.url = Imageurl!
                        }else if tag == "url"{
                            let weburl = node.value as? String
                            sponsorURL.url1 = weburl!
                        }
                    }
                }
                self.sponsorlist.append(sponsorURL)
                self.SponsorListTBV.reloadData()
            }
        }, withCancel: nil)
    }

}
