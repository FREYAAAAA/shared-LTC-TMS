//
//  C-FPortfolioVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/15.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_FPortfolioVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var infolist = [event]()
    let cellID = "cellID"
    
    @IBOutlet weak var portfolioTableview: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return infolist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: cellID)
        cell.textLabel?.text = self.infolist[indexPath.row].mission
        cell.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
        
        if infolist[indexPath.row].mission == "Address"{
            cell.detailTextLabel?.text = self.infolist[indexPath.row].url
            cell.detailTextLabel?.textColor = UIColor.black
            cell.selectionStyle = .none
            cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20.0)
            cell.detailTextLabel?.numberOfLines = 0
        }else{
            cell.detailTextLabel?.text = self.infolist[indexPath.row].url
            cell.detailTextLabel?.textColor = UIColor.black
            cell.selectionStyle = .none
            cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20.0)
        }
        
        return cell
    }
    
    
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let familyhomepage = storyboard?.instantiateViewController(withIdentifier: "C_FamilyVC") as? C_FamilyVC
        familyhomepage?.CFmyID = self.UID.text!
        self.present(familyhomepage!, animated: false, completion: nil)
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var Hamburger: UIStackView!
    @IBAction func HamburgerBottom(_ sender: UIButton) {
        if(Hamburger.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.Hamburger.window!.layer.add(transition, forKey: kCATransition)
            
            Hamburger.isHidden = false
        }
        else{
            Hamburger.isHidden = true
        }
    }
    @IBAction func clickPortfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_FPortfolioVC") as? C_FPortfolioVC
        portfoliopage?.CFmyID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func clickTask(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_FTaskInstructionVC") as? C_FTaskInstructionVC
        taskpage?.CFmyID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func clickDailyRecord(_ sender: UIButton) {
        let dailypage = storyboard?.instantiateViewController(withIdentifier: "C_DailyStatusVC") as? C_DailyStatusVC
        dailypage?.CFmyID3 = self.UID.text!
        self.present(dailypage!, animated: false, completion: nil)
    }
    @IBAction func clickVitalRecod(_ sender: UIButton) {
        let vitalpage = storyboard?.instantiateViewController(withIdentifier: "C_VitalStatusVC") as? C_VitalStatusVC
        vitalpage?.CFmyID4 = self.UID.text!
        self.present(vitalpage!, animated: false, completion: nil)
    }
    @IBAction func clickAIRecord(_ sender: UIButton) {
        let AIpage = storyboard?.instantiateViewController(withIdentifier: "C_AIStatusVC") as? C_AIStatusVC
        AIpage?.CFmyID5 = self.UID.text!
        self.present(AIpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_FAboutUsVC") as? C_FAboutUsVC
        aboutuspage?.CAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_FHelpSupport") as? C_FHelpSupport
        helpmenu?.CFmyID6 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginFAM")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC") as? C_LoginVC
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.CFmyID1).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CFmyID1).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    @IBOutlet weak var Image: UIImageView!
    
    //userID tag
    @IBOutlet weak var UID: UILabel!
    var CFmyID1 = String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        UID.text = CFmyID1
        
        fetchdata()
        
        //Image.image = UIImage(named: "MCULOGO")
        Database.database().reference().child("Patient").child(UID.text!).child("Portfolio").child("pictureurl").observe(.value, with: { (snapshot) in
            let url = URL(string: snapshot.value as! String)
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                if error != nil{
                    print(error!)
                    return
                }
                DispatchQueue.main.async {
                    self.Image.image = UIImage(data: data!)
                }
                }.resume()
        }, withCancel: nil)
        
        Database.database().reference().child("Patient").child(UID.text!).child("Portfolio").child("Name").observe(.value, with: { (snapshot) in
            self.NameLB.text = snapshot.value as? String
        }, withCancel: nil)
        Database.database().reference().child("Patient").child(UID.text!).child("Portfolio").child("Gender").observe(.value, with: { (snapshot) in
            self.GenderLB.text = snapshot.value as? String
        }, withCancel: nil)
        Database.database().reference().child("Patient").child(UID.text!).child("Portfolio").child("Nationality").observe(.value, with: { (snapshot) in
            self.NationalityLB.text = snapshot.value as? String
        }, withCancel: nil)
    }
    
    //portfolio
    @IBOutlet weak var NameLB: UILabel!
    @IBOutlet weak var GenderLB: UILabel!
    @IBOutlet weak var NationalityLB: UILabel!
    func fetchdata(){
        Database.database().reference().child("Patient").child(UID.text!).child("Portfolio").observe(.value, with: { (snapshot) in
            //print(snapshot.childrenCount)
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        let content = node.value
                        
                        let info = event()
                        
                        if tag == "Address"{
                            info.mission = tag.replacingOccurrences(of: "Address", with: "地址")
                        }else if tag == "AdmissionDate"{
                            info.mission = tag.replacingOccurrences(of: "AdmissionDate", with: "入院日")
                        }else if tag == "AdmissionReason"{
                            info.mission = tag.replacingOccurrences(of: "AdmissionReason", with: "入院原由")
                        }else if tag == "AppointmentRecord"{
                            info.mission = tag.replacingOccurrences(of: "AppointmentRecord", with: "預約記錄")
                        }else if tag == "BriefDescription"{
                            info.mission = tag.replacingOccurrences(of: "BriefDescription", with: "簡介")
                        }else if tag == "Contact"{
                            info.mission = tag.replacingOccurrences(of: "Contact", with: "聯絡電話")
                        }else if tag == "DOB"{
                            info.mission = tag.replacingOccurrences(of: "DOB", with: "出生日")
                        }else if tag == "EContact"{
                            info.mission = tag.replacingOccurrences(of: "EContact", with: "緊急聯絡電話")
                        }else if tag == "EName"{
                            info.mission = tag.replacingOccurrences(of: "EName", with: "緊急聯絡人")
                        }else if tag == "ERelationship"{
                            info.mission = tag.replacingOccurrences(of: "ERelationship", with: "緊急聯絡人關係")
                        }else if tag == "Email"{
                            info.mission = tag.replacingOccurrences(of: "Email", with: "電子信箱")
                        }else if tag == "ID"{
                            info.mission = tag
                        }else if tag == "MedicalRecord"{
                            info.mission = tag.replacingOccurrences(of: "MedicalRecord", with: "用藥紀錄")
                        }else if tag == "NationalID"{
                            info.mission = tag.replacingOccurrences(of: "NationalID", with: "身分證字號/ARC")
                        }else if tag == "Position"{
                            info.mission = tag.replacingOccurrences(of: "Position", with: "職位")
                        }else if tag == "patientRoomNo"{
                            info.mission = tag.replacingOccurrences(of: "patientRoomNo", with: "房號")
                        }
                        info.url = content as? String
                        
                        let x = "pictureurl"
                        let y = "Nationality"
                        let z = "Name"
                        let r = "Gender"
                        let w = "Password"
                        
                        if x != tag && y != tag && z != tag && r != tag && w != tag {
                            self.infolist.append(info)
                            self.portfolioTableview.reloadData()
                        }
                    }
                }
            }
        }, withCancel: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
