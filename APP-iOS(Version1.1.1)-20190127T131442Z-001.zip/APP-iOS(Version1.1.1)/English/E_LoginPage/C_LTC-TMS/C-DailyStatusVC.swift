//
//  C-DailyStatusVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/15.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_DailyStatusVC: UIViewController {

    @IBOutlet weak var SelectButton: UIButton!
    @IBOutlet weak var SelectDate: UIDatePicker!
    
    @IBAction func clickbutton(_ sender: UIButton) {
        if SelectDate.isHidden == true{
            //refresh ViewController to first response
            let parent = view.superview
            view.removeFromSuperview()
            view = nil
            parent?.addSubview(view)
            
            SelectDate.isHidden = false
        }
        else{
            SelectDate.isHidden = true
            
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-M-d"
            
            let str = formatter.string(from: SelectDate.date)
            SelectButton.setTitle(str, for: .normal)
            
            //Reposition Posture, Massage, Basic Care, Sanitation Behavior, Special Care
            Database.database().reference().child("Patient").child(UID.text!).child(str).child("daily_status").observe(.childAdded, with: { (snapshot) in
                if snapshot.key == "Positioning Patient_8am"{
                    self.RP8am.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Positioning Patient_10am"{
                    self.RP10am.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Positioning Patient_12pm"{
                    self.RP12pm.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Positioning Patient_2pm"{
                    self.RP2pm.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Positioning Patient_4pm"{
                    self.RP4pm.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Positioning Patient_6pm"{
                    self.RP6pm.image = UIImage(named: "checkbox-on-solid-512")
                }
                if snapshot.key == "Massage_8am"{
                    self.M8am.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Massage_10am"{
                    self.M10am.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Massage_12pm"{
                    self.M12pm.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Massage_2pm"{
                    self.M2pm.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Massage_4pm"{
                    self.M4pm.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Massage_6pm"{
                    self.M6pm.image = UIImage(named: "checkbox-on-solid-512")
                }
                if snapshot.key == "Cut Nail"{
                    self.NailCut.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "Shaved Moustache"{
                    self.MoustacheShaved.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "times_skin_care"{
                    self.SkinCare.text = snapshot.value as? String
                }
                if snapshot.key == "times_urinate"{
                    self.SBurinated.text = snapshot.value as? String
                }else if snapshot.key == "times_defecate"{
                    self.SBdefecated.text = snapshot.value as? String
                }else if snapshot.key == "times_oral_hygiene"{
                    self.SBoralhygiene.text = snapshot.value as? String
                }else if snapshot.key == "times_wash_face"{
                    self.SBfacewashed.text = snapshot.value as? String
                }else if snapshot.key == "times_shower"{
                    self.SBshowered.text = snapshot.value as? String
                }
                if snapshot.key == "total_oxygen_used_ml"{
                    self.SCoxygenused.text = snapshot.value as? String
                }else if snapshot.key == "total_steam_used_ml"{
                    self.SCsteamused.text = snapshot.value as? String
                }
            }, withCancel: nil)
            //Diet
            Database.database().reference().child("Patient").child(UID.text!).child(str).child("daily_status").child("dinner").observe(.childAdded, with: { (snapshot) in
                if snapshot.key == "breakfast_selfFeeding"{
                    self.Bself.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "breakfast_ngFeeding"{
                    self.BNG.image = UIImage(named: "checkbox-on-solid-512")
                }
            }, withCancel: nil)
            Database.database().reference().child("Patient").child(UID.text!).child(str).child("daily_status").child("lunch").observe(.childAdded, with: { (snapshot) in
                if snapshot.key == "lunch_selfFeeding"{
                    self.Lself.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "lunch_ngFeeding"{
                    self.LNG.image = UIImage(named: "checkbox-on-solid-512")
                }
            }, withCancel: nil)
            Database.database().reference().child("Patient").child(UID.text!).child(str).child("daily_status").child("dinner").observe(.childAdded, with: { (snapshot) in
                if snapshot.key == "dinner_selfFeeding"{
                    self.Dself.image = UIImage(named: "checkbox-on-solid-512")
                }else if snapshot.key == "dinner_ngFeeding"{
                    self.DNG.image = UIImage(named: "checkbox-on-solid-512")
                }
            }, withCancel: nil)
        }
    }
    
    //Reposition Posture
    @IBOutlet weak var RP8am: UIImageView!
    @IBOutlet weak var RP10am: UIImageView!
    @IBOutlet weak var RP12pm: UIImageView!
    @IBOutlet weak var RP2pm: UIImageView!
    @IBOutlet weak var RP4pm: UIImageView!
    @IBOutlet weak var RP6pm: UIImageView!
    //Massage
    @IBOutlet weak var M8am: UIImageView!
    @IBOutlet weak var M10am: UIImageView!
    @IBOutlet weak var M12pm: UIImageView!
    @IBOutlet weak var M2pm: UIImageView!
    @IBOutlet weak var M4pm: UIImageView!
    @IBOutlet weak var M6pm: UIImageView!
    //Basic Care
    @IBOutlet weak var NailCut: UIImageView!
    @IBOutlet weak var MoustacheShaved: UIImageView!
    @IBOutlet weak var SkinCare: UILabel!
    //Diet
    @IBOutlet weak var Bself: UIImageView!
    @IBOutlet weak var BNG: UIImageView!
    @IBOutlet weak var Lself: UIImageView!
    @IBOutlet weak var LNG: UIImageView!
    @IBOutlet weak var Dself: UIImageView!
    @IBOutlet weak var DNG: UIImageView!
    //Sanitation Behavior
    @IBOutlet weak var SBurinated: UILabel!
    @IBOutlet weak var SBdefecated: UILabel!
    @IBOutlet weak var SBoralhygiene: UILabel!
    @IBOutlet weak var SBfacewashed: UILabel!
    @IBOutlet weak var SBshowered: UILabel!
    @IBAction func DefecatedDetail(_ sender: UIButton) {
        let str = SelectButton.titleLabel?.text
        
        if str == "請選擇日期"{
            alert(usermessage: "請先選擇日期")
        }
        else{
            let popup = storyboard?.instantiateViewController(withIdentifier: "C_popupVC") as? C_popupVC
            popup?.CFmyIDpop = self.UID.text!
            popup?.Cdatepop = str!
            popup?.Cdetailidentify = "1"
            present(popup!, animated: true, completion: nil)
        }
    }
    //Special Care
    @IBOutlet weak var SCoxygenused: UILabel!
    @IBAction func OxygenDetail(_ sender: UIButton) {
        let str = SelectButton.titleLabel?.text
        
        if str == "請選擇日期"{
            alert(usermessage: "請先選擇日期")
        }
        else{
            let popup = storyboard?.instantiateViewController(withIdentifier: "C_popupVC") as? C_popupVC
            popup?.CFmyIDpop = self.UID.text!
            popup?.Cdatepop = str!
            popup?.Cdetailidentify = "2"
            present(popup!, animated: true, completion: nil)
        }
    }
    @IBOutlet weak var SCsteamused: UILabel!
    @IBAction func SteamDetail(_ sender: Any) {
        let str = SelectButton.titleLabel?.text
        
        if str == "請選擇日期"{
            alert(usermessage: "請先選擇日期")
        }
        else{
            let popup = storyboard?.instantiateViewController(withIdentifier: "C_popupVC") as? C_popupVC
            popup?.CFmyIDpop = self.UID.text!
            popup?.Cdatepop = str!
            popup?.Cdetailidentify = "3"
            present(popup!, animated: true, completion: nil)
        }
    }
    
    //alert
    func alert(usermessage: String){
        let alert = UIAlertController(title: nil, message: usermessage, preferredStyle: .alert)
        let alertaction = UIAlertAction(title: "好", style: .default, handler: nil)
        alert.addAction(alertaction)
        self.present(alert, animated: true, completion: nil)
    }
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let familyhomepage = storyboard?.instantiateViewController(withIdentifier: "C_FamilyVC") as? C_FamilyVC
        familyhomepage?.CFmyID = self.UID.text!
        self.present(familyhomepage!, animated: false, completion: nil)
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var Hamburger: UIStackView!
    @IBAction func HamburgerBottom(_ sender: UIButton) {
        if(Hamburger.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.Hamburger.window!.layer.add(transition, forKey: kCATransition)
            
            Hamburger.isHidden = false
        }
        else{
            Hamburger.isHidden = true
        }
    }
    @IBAction func clickEPortfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_FPortfolioVC") as? C_FPortfolioVC
        portfoliopage?.CFmyID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func clickTask(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_FTaskInstructionVC") as? C_FTaskInstructionVC
        taskpage?.CFmyID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func clickDailyRecord(_ sender: UIButton) {
        let dailypage = storyboard?.instantiateViewController(withIdentifier: "C_DailyStatusVC") as? C_DailyStatusVC
        dailypage?.CFmyID3 = self.UID.text!
        self.present(dailypage!, animated: false, completion: nil)
    }
    @IBAction func clickVitalRecod(_ sender: UIButton) {
        let vitalpage = storyboard?.instantiateViewController(withIdentifier: "C_VitalStatusVC") as? C_VitalStatusVC
        vitalpage?.CFmyID4 = self.UID.text!
        self.present(vitalpage!, animated: false, completion: nil)
    }
    @IBAction func clickAIRecord(_ sender: UIButton) {
        let AIpage = storyboard?.instantiateViewController(withIdentifier: "C_AIStatusVC") as? C_AIStatusVC
        AIpage?.CFmyID5 = self.UID.text!
        self.present(AIpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_FAboutUsVC") as? C_FAboutUsVC
        aboutuspage?.CAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_FHelpSupport") as? C_FHelpSupport
        helpmenu?.CFmyID6 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginFAM")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.CFmyID3).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CFmyID3).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    
    //userID tag
    @IBOutlet weak var UID: UILabel!
    var CFmyID3 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SelectDate.backgroundColor = UIColor.white
        
        UID.text = CFmyID3
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
