//
//  C-LoginVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/12.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase
import MessageUI

class C_LoginVC: UIViewController, MFMailComposeViewControllerDelegate {

    @IBOutlet weak var UserIDTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    
    
    @IBAction func LoginBottom(_ sender: UIButton) {
        
        let userID = UserIDTextField.text;
        let userPassword = PasswordTextField.text;
        
        //if the TextFields are empty or not
        if((userID?.isEmpty)! || (userPassword?.isEmpty)!){
            self.alertMessage(userMessage: "請填寫所有表格。")
            return;
        }
            
            //if id or password correct or not
        else{
            Database.database().reference().child("CNA").child(userID!).child("Portfolio").child("Password").observeSingleEvent(of: .value, with: { (snapshot) in
                if userPassword == (snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""){
                    
                    //policy
                    let message = "1. 請勿嘗試更改應用程式內容。\n2. 請確保用戶個人隱私。\n3. 請確保詳細閱讀系統政策。\n感謝您的配合！"
                    let alert = UIAlertController(title: "歡迎使用 LTC-TMS! 在使用前...", message: message, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "閱讀政策", style: .default, handler: nil))
                    alert.addAction(UIAlertAction(title: "同意", style: .default, handler: { (action) in
                        
                        let formatter1 = DateFormatter()
                        formatter1.dateFormat = "yyyy-MM-dd"
                        let str = formatter1.string(from: Date())
                        
                        let formatter2 = DateFormatter()
                        formatter2.dateFormat = "HH:mm:ss"
                        let str2 = formatter2.string(from: Date())
                        
                        Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LoginHistory").child("\(str)").child("\(str2)").setValue("Manual")
                        Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LatestLogin").setValue("\(str)-\(str2)")
                        
                        let CNAHomePage = self.storyboard?.instantiateViewController(withIdentifier: "C_CNAVC") as? C_CNAVC
                        //userID tag
                        CNAHomePage?.CmyID = self.UserIDTextField.text!
                        self.present(CNAHomePage!, animated: true, completion: nil)
                    }))
                    
                    let paragraphStyle = NSMutableParagraphStyle()
                    paragraphStyle.alignment = .left
                    
                    let messageText = NSMutableAttributedString(string: message, attributes: [
                        NSAttributedStringKey.paragraphStyle: paragraphStyle,
                        NSAttributedStringKey.font: UIFont.systemFont(ofSize: 14.0),
                        NSAttributedStringKey.foregroundColor : UIColor.black])
                    
                    alert.setValue(messageText, forKey: "attributedMessage")
                    self.present(alert, animated: true, completion: nil)
                    
                    
                    
                    //auto login as CNA
                    UserDefaults.standard.set(true, forKey: "AutoLoginCNA")
                    
                }
                else{
                    Database.database().reference().child("Patient").child(userID!).child("Portfolio").child("Password").observeSingleEvent(of: .value, with: { (snapshot) in
                        if userPassword == (snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""){
                            
                            //policy
                            let message = "1. 請勿嘗試更改應用程式內容。\n2. 請確保用戶個人隱私。\n3. 請確保詳細閱讀系統政策。\n感謝您的配合！"
                            let alert = UIAlertController(title: "歡迎使用 LTC-TMS! 再使用前...", message: message, preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "閱讀", style: .default, handler: nil))
                            alert.addAction(UIAlertAction(title: "同意", style: .default, handler: { (action) in
                                
                                let formatter1 = DateFormatter()
                                formatter1.dateFormat = "yyyy-MM-dd"
                                let str = formatter1.string(from: Date())
                                
                                let formatter2 = DateFormatter()
                                formatter2.dateFormat = "HH:mm:ss"
                                let str2 = formatter2.string(from: Date())
                                
                                Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LoginHistory").child("\(str)").child("\(str2)").setValue("Manual")
                                Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LatestLogin").setValue("\(str)-\(str2)")
                                
                                let FamilyHomePage = self.storyboard?.instantiateViewController(withIdentifier: "C_FamilyVC") as? C_FamilyVC
                                //userID tag
                                FamilyHomePage?.CFmyID = self.UserIDTextField.text!
                                self.present(FamilyHomePage!, animated: true, completion: nil)
                            }))
                            
                            let paragraphStyle = NSMutableParagraphStyle()
                            paragraphStyle.alignment = .left
                            
                            let messageText = NSMutableAttributedString(string: message, attributes: [
                                NSAttributedStringKey.paragraphStyle: paragraphStyle,
                                NSAttributedStringKey.font: UIFont.systemFont(ofSize: 14.0),
                                NSAttributedStringKey.foregroundColor : UIColor.black])
                            
                            alert.setValue(messageText, forKey: "attributedMessage")
                            self.present(alert, animated: true, completion: nil)
                            
                            
                            
                            
                            //auto login as Family
                            UserDefaults.standard.set(true, forKey: "AutoLoginFAM")
                        }
                        else{
                            self.alertMessage(userMessage: "您的使用者 ID 或密碼不正確。")
                        }
                    }, withCancel: nil)
                }
            }, withCancel: nil)
        }
        
        //remember ID (1)
        UserDefaults.standard.set(UserIDTextField.text, forKey: "userID")
    }
    
    
    //remember ID CheckBox
    @IBOutlet weak var checkbox: UIButton!
    @IBAction func ClickCheckBox(_ sender: UIButton) {
        if checkbox.isSelected{
            checkbox.isSelected = false
            if checkbox2.isSelected{
                checkbox2.isSelected = false
                UserDefaults.standard.set(false, forKey: "test")
            }
        }
        else{
            checkbox.isSelected = true
        }
        //remember ID (2)
        UserDefaults.standard.set(checkbox.isSelected, forKey: "rememberIDON")
    }
    
    //Auto Login CheckBox
    @IBOutlet weak var checkbox2: UIButton!
    @IBAction func ClickCheckBox2(_ sender: UIButton) {
        if checkbox2.isSelected{
            checkbox2.isSelected = false
            UserDefaults.standard.set(false, forKey: "test")
        }
        else{
            if checkbox.isSelected == false{
                checkbox.isSelected = true
                checkbox2.isSelected = true
                UserDefaults.standard.set(checkbox.isSelected, forKey: "rememberIDON")
                
            }else if checkbox.isSelected == true{
                checkbox2.isSelected = true
                UserDefaults.standard.set(checkbox.isSelected, forKey: "rememberIDON")
            }
        }
        //auto Login
        UserDefaults.standard.set(true, forKey: "test")
        UserDefaults.standard.set(checkbox2.isSelected, forKey: "AutoLoginON")
    }
    
    
    //提示視窗
    func alertMessage(userMessage: String){
        let alert = UIAlertController(title: "提示", message: userMessage, preferredStyle: .alert)
        let okaction = UIAlertAction(title: "好", style: .default, handler: nil)
        alert.addAction(okaction)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    //forgot password
    var IDtextfield:UITextField?
    @IBAction func clickforgotpassword(_ sender: UIButton) {
        forgotAlert(userMessage: "輸入使用者 ID。")
    }
    func forgotAlert(userMessage:String){
        let alert1 = UIAlertController(title: "重設密碼", message: userMessage, preferredStyle: .alert)
        let cancelaction1 = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        let nextaction1 = UIAlertAction(title: "繼續", style: .default) { (action) in
            let IDtextfield = alert1.textFields![0] as UITextField
            
            
            //make sure ID is correct
            Database.database().reference().child("CNA").observe(.childAdded, with: { (snapshot) in
                if (snapshot.key).replacingOccurrences(of: "\"", with: "") == IDtextfield.text{
                    let alert2 = UIAlertController(title: "重設密碼", message: "請輸入下方表格。", preferredStyle: .alert)
                    let cancelaction2 = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                    let nextaction2 = UIAlertAction(title: "繼續", style: .default) { (action) in
                        let name = alert2.textFields![0] as UITextField
                        let questionfield1 = alert2.textFields![1] as UITextField
                        let NationalID = alert2.textFields![2] as UITextField
                        
                        
                        
                        //make sure question is correct
                        Database.database().reference().child("CNA").child(IDtextfield.text!).child("Portfolio").child("Name").observe(.value, with: { (snapshot1) in
                            if (snapshot1.value as? String)?.replacingOccurrences(of: "\"", with: "") == name.text{
                                Database.database().reference().child("CNA").child(IDtextfield.text!).child("Portfolio").child("Email").observe(.value, with: { (snap) in
                                    if snap.value as? String == questionfield1.text{
                                        Database.database().reference().child("CNA").child(IDtextfield.text!).child("Portfolio").child("NationalID").observe(.value, with: { (snap1) in
                                            if snap1.value as? String == NationalID.text{
                                                let alert4 = UIAlertController(title: "重設密碼", message: "請輸入新的密碼。", preferredStyle: .alert)
                                                let cancelaction4 = UIAlertAction(title: "取消", style: .default, handler: nil)
                                                let nextaction4 = UIAlertAction(title: "重設", style: .default, handler: { (action) in
                                                    let newpassword = alert4.textFields![0] as UITextField
                                                    let newpasswordconfirm = alert4.textFields![1] as UITextField
                                                    
                                                    
                                                    //make sure no empty(s) or different password
                                                    if newpassword.text == newpasswordconfirm.text && (newpassword.text?.isEmpty == false || newpasswordconfirm.text?.isEmpty == false) {
                                                        
                                                        //Change Password History
                                                        
                                                        Database.database().reference().child("CNA").child(IDtextfield.text!).child("Portfolio").child("Password").setValue(newpassword.text!)
                                                        
                                                        let dateformatter = DateFormatter()
                                                        dateformatter.dateFormat = "yyyy-MM-dd-HH:mm:ss"
                                                        let str = dateformatter.string(from: Date())
                                                        Database.database().reference().child("CNA").child(IDtextfield.text!).child("Portfolio").child("Password").observe(.value, with: { (snap2) in
                                                            Database.database().reference().child("AccountStatus").child(snapshot.key).child("ChangePasswordHistory").child(str).setValue("PreviousPassword~\(String(describing: (newpassword.text)!))")
                                                        })
                                                        self.alertMessage(userMessage: "成功\n記得用新的密碼登入。")
                                                    }
                                                    else{
                                                        let wrong = UIAlertController(title: "錯誤", message: "有空格存在 或 輸入錯誤，要繼續嗎？", preferredStyle: .actionSheet)
                                                        let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                                                        let continueAlert = UIAlertAction(title: "繼續", style: .default, handler: { (action) in
                                                            self.present(alert4, animated: true, completion: nil)
                                                        })
                                                        wrong.addAction(cancel)
                                                        wrong.addAction(continueAlert)
                                                        self.present(wrong, animated: true, completion: nil)
                                                    }
                                                })
                                                
                                                alert4.addTextField(configurationHandler: { (newpassword) in
                                                    newpassword.placeholder = "新的密碼"
                                                    newpassword.isSecureTextEntry = true
                                                })
                                                alert4.addTextField(configurationHandler: { (confirmpassword) in
                                                    confirmpassword.placeholder = "再一次新的密碼"
                                                    confirmpassword.isSecureTextEntry = true
                                                })
                                                alert4.addAction(cancelaction4)
                                                alert4.addAction(nextaction4)
                                                self.present(alert4, animated: true, completion: nil)
                                            }
                                            else{
                                                let wrong = UIAlertController(title: "錯誤", message: "有空格存在 或 輸入錯誤，要繼續嗎？", preferredStyle: .actionSheet)
                                                let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                                                let continueAlert = UIAlertAction(title: "繼續", style: .default, handler: { (action) in
                                                    self.present(alert2, animated: true, completion: nil)
                                                })
                                                wrong.addAction(cancel)
                                                wrong.addAction(continueAlert)
                                                self.present(wrong, animated: true, completion: nil)
                                                self.alertMessage(userMessage: "有空格存在 或 輸入錯誤。")
                                            }
                                        }, withCancel: nil)
                                    }
                                    else{
                                        let wrong = UIAlertController(title: "錯誤", message: "有空格存在 或 輸入錯誤，要繼續嗎？", preferredStyle: .actionSheet)
                                        let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                                        let continueAlert = UIAlertAction(title: "繼續", style: .default, handler: { (action) in
                                            self.present(alert2, animated: true, completion: nil)
                                        })
                                        wrong.addAction(cancel)
                                        wrong.addAction(continueAlert)
                                        self.present(wrong, animated: true, completion: nil)
                                        self.alertMessage(userMessage: "有空格存在 或 輸入錯誤。")
                                    }
                                }, withCancel: nil)
                                
                                
                            }
                            else{
                                let wrong = UIAlertController(title: "錯誤", message: "有空格存在 或 輸入錯誤，要繼續嗎？", preferredStyle: .actionSheet)
                                let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                                let continueAlert = UIAlertAction(title: "繼續", style: .default, handler: { (action) in
                                    self.present(alert2, animated: true, completion: nil)
                                })
                                wrong.addAction(cancel)
                                wrong.addAction(continueAlert)
                                self.present(wrong, animated: true, completion: nil)
                                self.alertMessage(userMessage: "有空格存在 或 輸入錯誤。")
                            }
                        }, withCancel: nil)
                    }
                    alert2.addTextField(configurationHandler: { (name) in
                        name.placeholder = "姓名"
                    })
                    alert2.addTextField(configurationHandler: { (answerfield) in
                        answerfield.placeholder = "example@example.com"
                    })
                    alert2.addTextField(configurationHandler: { (NationalID) in
                        NationalID.placeholder = "A123456789"
                    })
                    alert2.addAction(cancelaction2)
                    alert2.addAction(nextaction2)
                    self.present(alert2, animated: true, completion: nil)
                    
                }else{
                    Database.database().reference().child("Patient").observe(.childAdded, with: { (snapshot2) in
                        if snapshot2.key == IDtextfield.text{
                            let alert3 = UIAlertController(title: "重設密碼", message: "請輸入下方表格。", preferredStyle: .alert)
                            let cancelaction3 = UIAlertAction(title: "取消", style: .default, handler: nil)
                            let nextaction3 = UIAlertAction(title: "下一步", style: .default) { (action) in
                                let name = alert3.textFields![0] as UITextField
                                let questionfield2 = alert3.textFields![1] as UITextField
                                let NationalID = alert3.textFields![2] as UITextField
                                
                                //make sure question is correct
                                Database.database().reference().child("Patient").child(IDtextfield.text!).child("Portfolio").child("Name").observe(.value, with: { (snapshot1) in
                                    if snapshot1.value as? String == name.text{
                                        Database.database().reference().child("Patient").child(IDtextfield.text!).child("Portfolio").child("Email").observe(.value, with: { (snap) in
                                            if snap.value as? String == questionfield2.text{
                                                Database.database().reference().child("Patient").child(IDtextfield.text!).child("Portfolio").child("NationalID").observe(.value, with: { (snap1) in
                                                    if snap1.value as? String == NationalID.text{
                                                        let alert5 = UIAlertController(title: "重設密碼", message: "請輸入新的密碼。", preferredStyle: .alert)
                                                        let cancelaction5 = UIAlertAction(title: "取消", style: .default, handler: nil)
                                                        let nextaction5 = UIAlertAction(title: "重設", style: .default, handler: { (action) in
                                                            let newpassword = alert5.textFields![0] as UITextField
                                                            let newpasswordconfirm = alert5.textFields![1] as UITextField
                                                            
                                                            
                                                            //make sure no empty(s) or different password
                                                            if newpassword.text == newpasswordconfirm.text && (newpassword.text?.isEmpty == false || newpasswordconfirm.text?.isEmpty == false){
                                                                Database.database().reference().child("Patient").child(IDtextfield.text!).child("Portfolio").child("Password").setValue(newpassword.text!)
                                                                self.alertMessage(userMessage: "成功！")
                                                            }else{
                                                                let wrong = UIAlertController(title: "錯誤", message: "有空格存在 或 輸入錯誤，要繼續嗎？", preferredStyle: .actionSheet)
                                                                let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                                                                let continueAlert = UIAlertAction(title: "繼續", style: .default, handler: { (action) in
                                                                    self.present(alert5, animated: true, completion: nil)
                                                                })
                                                                wrong.addAction(cancel)
                                                                wrong.addAction(continueAlert)
                                                                self.present(wrong, animated: true, completion: nil)
                                                            }
                                                        })
                                                        
                                                        alert5.addTextField(configurationHandler: { (newpassword) in
                                                            newpassword.placeholder = "新的密碼"
                                                            newpassword.isSecureTextEntry = true
                                                        })
                                                        alert5.addTextField(configurationHandler: { (confirmpassword) in
                                                            confirmpassword.placeholder = "再一次新的密碼"
                                                            confirmpassword.isSecureTextEntry = true
                                                        })
                                                        alert5.addAction(cancelaction5)
                                                        alert5.addAction(nextaction5)
                                                        self.present(alert5, animated: true, completion: nil)
                                                    }
                                                    else{
                                                        let wrong = UIAlertController(title: "錯誤", message: "有空格存在 或 輸入錯誤，要繼續嗎？", preferredStyle: .actionSheet)
                                                        let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                                                        let continueAlert = UIAlertAction(title: "繼續", style: .default, handler: { (action) in
                                                            self.present(alert3, animated: true, completion: nil)
                                                        })
                                                        wrong.addAction(cancel)
                                                        wrong.addAction(continueAlert)
                                                        self.present(wrong, animated: true, completion: nil)
                                                        self.alertMessage(userMessage: "有空格存在 或 輸入錯誤。")
                                                    }
                                                }, withCancel: nil)
                                            }
                                            else{
                                                let wrong = UIAlertController(title: "錯誤", message: "有空格存在 或 輸入錯誤，要繼續嗎？", preferredStyle: .actionSheet)
                                                let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                                                let continueAlert = UIAlertAction(title: "繼續", style: .default, handler: { (action) in
                                                    self.present(alert3, animated: true, completion: nil)
                                                })
                                                wrong.addAction(cancel)
                                                wrong.addAction(continueAlert)
                                                self.present(wrong, animated: true, completion: nil)
                                                self.alertMessage(userMessage: "有空格存在 或 輸入錯誤。")
                                            }
                                        }, withCancel: nil)
                                    }
                                    else{
                                        let wrong = UIAlertController(title: "錯誤", message: "有空格存在 或 輸入錯誤，要繼續嗎？", preferredStyle: .actionSheet)
                                        let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                                        let continueAlert = UIAlertAction(title: "繼續", style: .default, handler: { (action) in
                                            self.present(alert3, animated: true, completion: nil)
                                        })
                                        wrong.addAction(cancel)
                                        wrong.addAction(continueAlert)
                                        self.present(wrong, animated: true, completion: nil)
                                        self.alertMessage(userMessage: "有空格存在 或 輸入錯誤。")
                                    }
                                }, withCancel: nil)
                            }
                            alert3.addTextField(configurationHandler: { (name) in
                                name.placeholder = "姓名"
                            })
                            alert3.addTextField(configurationHandler: { (answerfield) in
                                answerfield.placeholder = "example@example.com"
                            })
                            alert3.addTextField(configurationHandler: { (NationalID) in
                                NationalID.placeholder = "A123456789"
                            })
                            alert3.addAction(cancelaction3)
                            alert3.addAction(nextaction3)
                            self.present(alert3, animated: true, completion: nil)
                        }
                        else{
                            self.alertMessage(userMessage: "有空格存在 或 輸入錯誤。")
                        }
                    }, withCancel: nil)
                }
            }, withCancel: nil)
        }
        let forgotID = UIAlertAction(title: "忘記使用者 ID", style: .default) { (action) in
            let IDalert = UIAlertController(title: "找回使用者 ID", message: "請輸入下方表格以找回使用者 ID。 （若是家屬使用者，以下皆為病人資訊）", preferredStyle: .alert)
            let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
            let continueAction = UIAlertAction(title: "繼續", style: .default, handler: { (action) in
                let name = IDalert.textFields![0] as UITextField
                let email = IDalert.textFields![1] as UITextField
                
                Database.database().reference().child("CNA").observe(.childAdded, with: { (snapshot) in
                    Database.database().reference().child("CNA").child(snapshot.key).child("Portfolio").child("Name").observe(.value, with: { (snapshot1) in
                        if name.text == snapshot1.value as? String{
                            Database.database().reference().child("CNA").child(snapshot.key).child("Portfolio").child("Email").observe(.value, with: { (snapshot2) in
                                if email.text == snapshot2.value as? String{
                                    self.alertMessage(userMessage: "您的使用者 ID: \(snapshot.key)")
                                }
                                else{
                                    self.alertMessage(userMessage: "輸入錯誤。")
                                }
                            }, withCancel: nil)
                        }
                        else{
                            Database.database().reference().child("Patient").observe(.childAdded, with: { (snapshot3) in
                                Database.database().reference().child("Patient").child(snapshot3.key).child("Portfolio").child("Name").observe(.value, with: { (snapshot4) in
                                    if name.text == snapshot4.value as? String{
                                        Database.database().reference().child("Patient").child(snapshot3.key).child("Portfolio").child("Email").observe(.value, with: { (snapshot5) in
                                            if email.text == snapshot5.value as? String{
                                                self.alertMessage(userMessage: "您的使用者 ID: \(snapshot3.key)")
                                            }
                                            else{
                                                self.alertMessage(userMessage: "輸入錯誤。")
                                            }
                                        }, withCancel: nil)
                                    }
                                }, withCancel: nil)
                            }, withCancel: nil)
                        }
                    }, withCancel: nil)
                }, withCancel: nil)
            })
            IDalert.addTextField(configurationHandler: { (name) in
                name.placeholder = "姓名"
            })
            IDalert.addTextField(configurationHandler: { (email) in
                email.placeholder = "信箱"
            })
            IDalert.addAction(cancel)
            IDalert.addAction(continueAction)
            self.present(IDalert, animated: true, completion: nil)
        }
        
        alert1.addTextField { (IDtextfield) in
            IDtextfield.placeholder = "請先輸入您的使用者 ID。"
        }
        alert1.addAction(nextaction1)
        alert1.addAction(forgotID)
        alert1.addAction(cancelaction1)
        
        self.present(alert1, animated: true, completion: nil)
    }
    
    @IBAction func readpolicy(_ sender: UIButton) {
        Database.database().reference().child("Policy").child("P1").child("System Policy").observe(.value, with: { (snapshot) in
            UIApplication.shared.open(URL(string: (snapshot.value as? String)!)!, options: [:], completionHandler: nil)
        }, withCancel: nil)
    }
    
    
    
    
    //After typing, touch screen, keyboard will drop down.
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        UserIDTextField.endEditing(true)
        PasswordTextField.endEditing(true)
    }
    
    
    //Call, Email bottom
    @IBAction func CallBottom(_ sender: UIButton) {
        Database.database().reference().child("CenterInformation").child("ContactInfo").child("Contact No").observe(.value) { (snapshot) in
            
            let url : NSURL = URL(string: "TEL://\(snapshot.value as! String)")! as NSURL
            UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
            
        }
    }
    @IBAction func EmailBottom(_ sender: UIButton) {
        let mailsend = MFMailComposeViewController()
        mailsend.mailComposeDelegate = self
        Database.database().reference().child("CenterInformation").child("ContactInfo").child("Email").observe(.value) { (snapshot) in
            
            mailsend.setToRecipients(["\(snapshot.value as! String)"])
            mailsend.setSubject("Test")
        }
        
        if MFMailComposeViewController.canSendMail(){
            self.present(mailsend, animated: true, completion: nil)
        }
        else{
            print("NO")
        }
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //remember ID (3)
        if let y = UserDefaults.standard.object(forKey: "rememberIDON")as? Bool{
            checkbox.isSelected = y
        }
        if(checkbox.isSelected == true){
            if let x = UserDefaults.standard.object(forKey: "userID")as? String{
                UserIDTextField.text = x
            }
        }
        
        
        //auto login
        if let isON = UserDefaults.standard.object(forKey: "AutoLoginON")as? Bool{
            checkbox2.isSelected = isON
        }
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        
        //Auto Login
        if (UserDefaults.standard.bool(forKey: "test") == true){

            //auto login as CNA
            if (UserDefaults.standard.bool(forKey: "AutoLoginCNA") == true){

                let formatter1 = DateFormatter()
                formatter1.dateFormat = "yyyy-MM-dd"
                let str = formatter1.string(from: Date())

                let formatter2 = DateFormatter()
                formatter2.dateFormat = "HH:mm:ss"
                let str2 = formatter2.string(from: Date())

                Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LoginHistory").child("\(str)").child("\(str2)").setValue("Auto")

                let CNAHomePage = self.storyboard?.instantiateViewController(withIdentifier: "C_CNAVC") as? C_CNAVC
                //userID tag
                CNAHomePage?.CmyID = self.UserIDTextField.text!
                self.present(CNAHomePage!, animated: true, completion: nil)

            }else{

                //auto login as Family
                if (UserDefaults.standard.bool(forKey: "AutoLoginFAM") == true){

                    let formatter1 = DateFormatter()
                    formatter1.dateFormat = "yyyy-MM-dd"
                    let str = formatter1.string(from: Date())

                    let formatter2 = DateFormatter()
                    formatter2.dateFormat = "HH:mm:ss"
                    let str2 = formatter2.string(from: Date())

                    Database.database().reference().child("AccountStatus").child("App").child(self.UserIDTextField.text!).child("LoginHistory").child("\(str)").child("\(str2)").setValue("Auto")

                    let FamilyHomePage = self.storyboard?.instantiateViewController(withIdentifier: "C_FamilyVC") as? C_FamilyVC
                    //userID tag
                    FamilyHomePage?.CFmyID = self.UserIDTextField.text!
                    self.present(FamilyHomePage!, animated: true, completion: nil)
                }
            }

        }
    }
}

