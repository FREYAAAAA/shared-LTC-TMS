//
//  C-CNAAboutUsVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/13.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_CNAAboutUsVC: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var sponsorlist = [event]()
    
    @IBOutlet weak var SponsorListTBV: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sponsorlist.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as! sponsorlistTBV
        cell.textLabel?.text = sponsorlist[indexPath.row].mission
        cell.detailTextLabel?.text = sponsorlist[indexPath.row].url1
        
        if let sponsorImageUrl = sponsorlist[indexPath.row].url{
            let url = URL(string: sponsorImageUrl)
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                if error != nil{
                    print(error!)
                    return
                }
                DispatchQueue.main.async {
                    cell.sponsorImage.image = UIImage(data: data!)
                    //                    cell.imageView?.image = UIImage(data: data!)
                }
                }.resume()
            
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let website = sponsorlist[indexPath.row].url1
        UIApplication.shared.open(URL(string: website!)!, options: [:], completionHandler: nil)
    }
    
    
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let CNAhomepage = storyboard?.instantiateViewController(withIdentifier: "C_CNAVC") as? C_CNAVC
        CNAhomepage?.CmyID = self.UID.text!
        self.present(CNAhomepage!, animated: false, completion: nil)
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var HBpage: UIStackView!
    @IBAction func HamburgerPageIcon(_ sender: UIButton) {
        if(HBpage.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.HBpage.window!.layer.add(transition, forKey: kCATransition)
            
            HBpage.isHidden = false
        }
        else{
            HBpage.isHidden = true
        }
    }
    @IBAction func Portfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_PortolioVC") as? C_PortolioVC
        portfoliopage?.CmyID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func Task(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionVC") as? C_TaskInstructionVC
        taskpage?.CmyID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func workingschedule(_ sender: UIButton) {
        let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingScheduleVC") as? C_WorkingScheduleVC
        workingschedulepage?.CmyID3 = self.UID.text!
        self.present(workingschedulepage!, animated: false, completion: nil)
    }
    @IBAction func workinghour(_ sender: UIButton) {
        let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingHourVC") as? C_WorkingHourVC
        workinghourpage?.CmyID4 = self.UID.text!
        self.present(workinghourpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_CNAAboutUsVC") as? C_CNAAboutUsVC
        aboutuspage?.CCNAAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_help_supportVC") as? C_help_supportVC
        helpmenu?.ChelpID = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC") as? C_LoginVC
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            
            Database.database().reference().child("AccountStatus").child("App").child(self.CCNAAboutmyID).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CCNAAboutmyID).child("LatestLogout").setValue("\(str)-\(str2)")
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    
    
    
    
    @IBOutlet weak var UID: UILabel!
    var CCNAAboutmyID = String()
    
    @IBOutlet weak var descriptionBox: UITextView!
    @IBOutlet weak var CenterName: UILabel!
    @IBOutlet weak var CenterEmail: UILabel!
    @IBOutlet weak var CenterContactNo: UILabel!
    @IBOutlet weak var CenterAddress: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.UID.text = CCNAAboutmyID
        
        fetchsponsor()
        
        //Description
        Database.database().reference().child("CenterInformation").child("ContactInfo").child("Aboutus").observe(.value, with: { (snapshot) in
            self.descriptionBox.text = snapshot.value as? String
        }, withCancel: nil)
        
        //Info
        Database.database().reference().child("CenterInformation").child("ContactInfo").observe(.childAdded, with: { (snapshot) in
            if snapshot.key == "Name"{
                self.CenterName.text = "名稱: \(snapshot.value as! String)"
            }else if snapshot.key == "Email"{
                self.CenterEmail.text = "電子信箱: \(snapshot.value as! String)"
            }else if snapshot.key == "Contact No"{
                self.CenterContactNo.text = "聯絡電話: \(snapshot.value as! String)"
            }else if snapshot.key == "Address"{
                self.CenterAddress.text = "地址: \(snapshot.value as! String)"
            }
        }, withCancel: nil)
        
        SponsorListTBV.register(sponsorlistTBV.self, forCellReuseIdentifier: "cellID")
    }
    
    func fetchsponsor(){
        Database.database().reference().child("CenterInformation").child("Sponsor").observe(.childAdded, with: { (snapshot1) in
            let sponsorURL = event()
            sponsorURL.mission = snapshot1.key
            
            if snapshot1.hasChildren(){
                for snap in snapshot1.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        if tag == "photo"{
                            let Imageurl = node.value as? String
                            sponsorURL.url = Imageurl!
                        }else if tag == "url"{
                            let weburl = node.value as? String
                            sponsorURL.url1 = weburl!
                        }
                    }
                }
                self.sponsorlist.append(sponsorURL)
                self.SponsorListTBV.reloadData()
            }
        }, withCancel: nil)
    }
}
