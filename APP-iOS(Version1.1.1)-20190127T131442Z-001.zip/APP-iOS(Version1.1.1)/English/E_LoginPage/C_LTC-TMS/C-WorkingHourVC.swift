//
//  C-WorkingHourVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/13.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_WorkingHourVC: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    
    var hourslist = [event]()
    
    @IBOutlet weak var hoursTBV: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSeaching{
            return searchtask.count
        }
        return hourslist.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath)
        if isSeaching{
            cell.textLabel?.text = searchtask[indexPath.row].mission
            
            return cell
        }else{
            cell.textLabel?.text = hourslist[indexPath.row].mission
            
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let url = hourslist[indexPath.row].url
        UIApplication.shared.open(URL(string: url!)!, options: [:], completionHandler: nil)
    }
    
    
    //searchbar
    var searchtask = [event]()
    var isSeaching = false
    @IBOutlet weak var searchTaskBar: UISearchBar!
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isSeaching = true
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        isSeaching = false
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        isSeaching = false
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        guard !searchText.isEmpty else{
            searchtask = hourslist
            hoursTBV.reloadData()
            return
        }
        searchtask = hourslist.filter({ (letterstype) -> Bool in
            guard let text = searchBar.text?.lowercased() else {return false}
            return letterstype.mission.lowercased().contains(text.lowercased())
        })
        hoursTBV.reloadData()
    }
    //cancel bottom
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSeaching = false
        searchBar.text = ""
        
        searchTaskBar.endEditing(true)
        
        hoursTBV.reloadData()
    }
    
    
    
    //homeICon
    @IBAction func homeIcon(_ sender: UIButton) {
        let CNAhomepage = storyboard?.instantiateViewController(withIdentifier: "C_CNAVC") as? C_CNAVC
        CNAhomepage?.CmyID = self.CmyID4
        self.present(CNAhomepage!, animated: false, completion: nil)
    }
    
    //hamburgerIcon
    @IBOutlet weak var HBpage: UIStackView!
    @IBAction func HamburgerPageIcon(_ sender: UIButton) {
        if(HBpage.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.HBpage.window!.layer.add(transition, forKey: kCATransition)
            
            HBpage.isHidden = false
        }
        else{
            HBpage.isHidden = true
        }
    }
    @IBAction func Portfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_PortolioVC") as? C_PortolioVC
        portfoliopage?.CmyID1 = self.CmyID4
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func Task(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionVC") as? C_TaskInstructionVC
        taskpage?.CmyID2 = self.CmyID4
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func workingschedule(_ sender: UIButton) {
        let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingScheduleVC") as? C_WorkingScheduleVC
        workingschedulepage?.CmyID3 = self.CmyID4
        self.present(workingschedulepage!, animated: false, completion: nil)
    }
    @IBAction func workinghour(_ sender: UIButton) {
        let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingHourVC") as? C_WorkingHourVC
        workinghourpage?.CmyID4 = self.CmyID4
        self.present(workinghourpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_CNAAboutUsVC") as? C_CNAAboutUsVC
        aboutuspage?.CCNAAboutmyID = self.CmyID4
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_help_supportVC") as? C_help_supportVC
        helpmenu?.ChelpID = self.CmyID4
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            
            Database.database().reference().child("AccountStatus").child("App").child(self.CmyID4).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CmyID4).child("LatestLogout").setValue("\(str)-\(str2)")
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    
    
    
    
    //userID tag
    var CmyID4 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchhours()
        
        // Do any additional setup after loading the view.
    }
    func fetchhours(){
        Database.database().reference().child("WorkingHourRecord").observe(.childAdded, with: { (snapshot) in
            let hoursdata = event()
            
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        let data = node.value as? String
                        
                        if tag == "titleIOS"{
                            hoursdata.mission = data!
                        }
                        else if tag == "url"{
                            hoursdata.url = data!
                        }
                    }
                }
            }
            
            self.hourslist.append(hoursdata)
            self.hoursTBV.reloadData()
        }, withCancel: nil)
    }
}
