//
//  C-PortolioVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/13.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_PortolioVC: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var infolist = [event]()
    
    @IBOutlet weak var portfolioTableview: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return infolist.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as! portfolioCNATBV
        
        cell.textLabel?.text = self.infolist[indexPath.row].mission
        cell.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
        
        if infolist[indexPath.row].mission == "執照" || infolist[indexPath.row].mission == "履歷"{
            cell.detailTextLabel?.text = "點擊閱讀"
            cell.detailTextLabel?.textColor = UIColor.red
            cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20.0)
        }else{
            if infolist[indexPath.row].mission == "Address"{
                cell.detailTextLabel?.text = self.infolist[indexPath.row].url
                cell.detailTextLabel?.textColor = UIColor.black
                cell.selectionStyle = .none
                cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20.0)
                cell.detailTextLabel?.numberOfLines = 0
            }else{
                cell.detailTextLabel?.text = self.infolist[indexPath.row].url
                cell.detailTextLabel?.textColor = UIColor.black
                cell.selectionStyle = .none
                cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20.0)
            }
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if infolist[indexPath.row].mission == "執照" || infolist[indexPath.row].mission == "履歷"{
            let website = infolist[indexPath.row].url
            if website != nil{
                UIApplication.shared.open(URL(string: website!)!, options: [:], completionHandler: nil)
            }
        }
    }
    
    
    
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let CNAhomepage = storyboard?.instantiateViewController(withIdentifier: "C_CNAVC") as? C_CNAVC
        CNAhomepage?.CmyID = self.CmyID1
        self.present(CNAhomepage!, animated: false, completion: nil)
    }
    
    //hamburgerIcon
    @IBOutlet weak var HBpage: UIStackView!
    @IBAction func HamburgerPageIcon(_ sender: UIButton) {
        if(HBpage.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.HBpage.window!.layer.add(transition, forKey: kCATransition)
            
            HBpage.isHidden = false
        }
        else{
            HBpage.isHidden = true
        }
    }
    @IBAction func Portfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_PortolioVC") as? C_PortolioVC
        portfoliopage?.CmyID1 = self.CmyID1
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func Task(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionVC") as? C_TaskInstructionVC
        taskpage?.CmyID2 = self.CmyID1
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func workingschedule(_ sender: UIButton) {
        let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingScheduleVC") as? C_WorkingScheduleVC
        workingschedulepage?.CmyID3 = self.CmyID1
        self.present(workingschedulepage!, animated: false, completion: nil)
    }
    @IBAction func workinghour(_ sender: UIButton) {
        let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingHourVC") as? C_WorkingHourVC
        workinghourpage?.CmyID4 = self.CmyID1
        self.present(workinghourpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_CNAAboutUsVC") as? C_CNAAboutUsVC
        aboutuspage?.CCNAAboutmyID = self.CmyID1
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_help_supportVC") as? C_help_supportVC
        helpmenu?.ChelpID = self.CmyID1
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC") as? C_LoginVC
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            
            Database.database().reference().child("AccountStatus").child("App").child(self.CmyID1).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CmyID1).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    @IBOutlet weak var Image: UIImageView!
    
    //userID tag1
    var CmyID1 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //portfolio List
        fetchdata()
        
        Database.database().reference().child("CNA").child(CmyID1).child("Portfolio").child("pictureurl").observe(.value, with: { (snapshot) in
            print(snapshot)
            let url = URL(string: snapshot.value as! String)
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                if error != nil{
                    print(error!)
                    return
                }
                DispatchQueue.main.async {
                    self.Image.image = UIImage(data: data!)
                }
                }.resume()
        }, withCancel: nil)
        
        Database.database().reference().child("CNA").child(CmyID1).child("Portfolio").child("Name").observe(.value, with: { (snapshot) in
            self.NameLB.text = snapshot.value as? String
        }, withCancel: nil)
        Database.database().reference().child("CNA").child(CmyID1).child("Portfolio").child("Gender").observe(.value, with: { (snapshot) in
            self.GenderLB.text = snapshot.value as? String
        }, withCancel: nil)
        Database.database().reference().child("CNA").child(CmyID1).child("Portfolio").child("Nationality").observe(.value, with: { (snapshot) in
            self.NationalityLB.text = snapshot.value as? String
        }, withCancel: nil)
        
    }
    
    //portfolio
    @IBOutlet weak var NameLB: UILabel!
    @IBOutlet weak var GenderLB: UILabel!
    @IBOutlet weak var NationalityLB: UILabel!
    func fetchdata(){
        Database.database().reference().child("CNA").child(CmyID1).child("Portfolio").observe(.value, with: { (snapshot) in
            //print(snapshot.childrenCount)
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        let content = node.value
                        
                        let x = "pictureurl"
                        let y = "Nationality"
                        let z = "Name"
                        let r = "Gender"
                        let w = "Password"
                        
                        let info = event()
                        if tag == "Address"{
                            info.mission = tag.replacingOccurrences(of: "Address", with: "地址")
                        }else if tag == "BriefDescription"{
                            info.mission = tag.replacingOccurrences(of: "BriefDescription", with: "簡介")
                        }else if tag == "CV"{
                            info.mission = tag.replacingOccurrences(of: "CV", with: "履歷")
                        }else if tag == "Contact"{
                            info.mission = tag.replacingOccurrences(of: "Contact", with: "聯絡電話")
                        }else if tag == "DOB"{
                            info.mission = tag.replacingOccurrences(of: "DOB", with: "出生日")
                        }else if tag == "EContact"{
                            info.mission = tag.replacingOccurrences(of: "EContact", with: "緊急聯絡電話")
                        }else if tag == "EName"{
                            info.mission = tag.replacingOccurrences(of: "EName", with: "緊急聯絡人")
                        }else if tag == "Contact"{
                            info.mission = tag.replacingOccurrences(of: "Contact", with: "聯絡電話")
                        }else if tag == "ERelationship"{
                            info.mission = tag.replacingOccurrences(of: "ERelationship", with: "緊急聯絡人關係")
                        }else if tag == "Email"{
                            info.mission = tag.replacingOccurrences(of: "Email", with: "電子信箱")
                        }else if tag == "InitialDate"{
                            info.mission = tag.replacingOccurrences(of: "InitialDate", with: "就職日")
                        }else if tag == "License"{
                            info.mission = tag.replacingOccurrences(of: "License", with: "執照")
                        }else if tag == "NationalID"{
                            info.mission = tag.replacingOccurrences(of: "NationalID", with: "身分證字號/ARC")
                        }else if tag == "Position"{
                            info.mission = tag.replacingOccurrences(of: "Position", with: "職位")
                        }else if tag == "ID"{
                            info.mission = tag.replacingOccurrences(of: "ID", with: "使用者 ID")
                        }

                        info.url = content as? String
                        
                        
                        if x != tag && y != tag && z != tag && r != tag && w != tag {
                            self.infolist.append(info)
                            self.portfolioTableview.reloadData()
                        }
                    }
                }
            }
        }, withCancel: nil)
    }


}
