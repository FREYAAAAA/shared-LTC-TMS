//
//  C-feebackhistory.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/20.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_feebackhistory: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var feedbackIDlist = [event]()
    var datelist = [array1]()
    var repliedlist = [typeAry2]()
    @IBOutlet weak var fbIDTBV: UITableView!
    @IBOutlet weak var dateTBV: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == fbIDTBV{
            return feedbackIDlist.count
        }else{
            return datelist.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == fbIDTBV{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellIDfeedback", for: indexPath) as! feedbackTBV
            cell.textLabel?.text = feedbackIDlist[indexPath.row].mission
            
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellIDdate", for: indexPath) as! DateTBV
            cell.textLabel?.text = datelist[indexPath.row].typesTask
            //cell.detailTextLabel?.text = datelist[indexPath.row].list2
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == fbIDTBV{
            feedbackContent.text = "日期: \(String(describing: feedbackIDlist[indexPath.row].url!))\n時間: \(String(describing: feedbackIDlist[indexPath.row].url1!))\n內容: \(String(describing: feedbackIDlist[indexPath.row].mission!))"
            
            if repliedlist[indexPath.row].typeAry == " "{
                response.text = "\(String(describing: repliedlist[indexPath.row].typeAry!))\n\(String(describing: repliedlist[indexPath.row].Ary2!))"
            }else{
                var ary2 = repliedlist[indexPath.row].typeAry.components(separatedBy: "?")
                response.text = "日期: \(ary2[0])\n時間: \(ary2[1])\n內容: \(String(describing: repliedlist[indexPath.row].Ary2!))"
            }
        }else if tableView == dateTBV{
            
            self.feedbackIDlist.removeAll()
            
            if centerCheckBox.isSelected{
                Database.database().reference().child("Feedback").child(self.CmyID7).child("Center").child(datelist[indexPath.row].typesTask).observe(.childAdded, with: { (snapshot) in
                    if snapshot.hasChildren(){
                        for snap in snapshot.children{
                            if let node = snap as? DataSnapshot{
                                if node.key == "Received"{
                                    
                                    if node.hasChildren(){
                                        for snap2 in node.children{
                                            if let node2 = snap2 as? DataSnapshot{
                                                
                                                let IDlist = event()
                                                
                                                //feedback content
                                                let finalvalue = (node2.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                IDlist.mission = finalvalue
                                                
                                                //feedback date
                                                IDlist.url = self.datelist[indexPath.row].typesTask
                                                
                                                //feedback time
                                                IDlist.url1 = node2.key
                                                
                                                self.feedbackIDlist.append(IDlist)
                                                self.fbIDTBV.reloadData()
                                            }
                                        }
                                    }
                                    
                                    
                                }
                            }
                        }
                    }
                }, withCancel: nil)
            }
                
            else if systemCheckBox.isSelected{
                
                Database.database().reference().child("Feedback").child(self.CmyID7).child("System").child(datelist[indexPath.row].typesTask).observe(.childAdded, with: { (snapshot) in
                    if snapshot.hasChildren(){
                        for snap in snapshot.children{
                            if let node = snap as? DataSnapshot{
                                if node.key == "Received"{
                                    
                                    if node.hasChildren(){
                                        for snap2 in node.children{
                                            if let node2 = snap2 as? DataSnapshot{
                                                
                                                let IDlist = event()
                                                
                                                //feedback content
                                                let finalvalue = (node2.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                IDlist.mission = finalvalue
                                                
                                                //feedback date
                                                IDlist.url = self.datelist[indexPath.row].typesTask
                                                
                                                //feedback time
                                                IDlist.url1 = node2.key
                                                
                                                self.feedbackIDlist.append(IDlist)
                                                self.fbIDTBV.reloadData()
                                            }
                                        }
                                    }
                                    
                                    
                                }
                            }
                        }
                    }
                }, withCancel: nil)
            }
            selectBottom.setTitle(datelist[indexPath.row].typesTask, for: .normal)
        }
        
        
        dateTBV.isHidden = true
        
    }
    @IBOutlet weak var feedbackContent: UITextView!
    @IBOutlet weak var response: UITextView!
    
    
    //checkboxs
    @IBOutlet weak var centerCheckBox: UIButton!
    @IBOutlet weak var systemCheckBox: UIButton!
    @IBAction func clickCenter(_ sender: UIButton) {
        selectBottom.setTitle("請選擇日期", for: .normal)
        
        if centerCheckBox.isSelected == false{
            centerCheckBox.isSelected = true
            systemCheckBox.isSelected = false
            
            //feedbackID tableview
            self.feedbackIDlist.removeAll()
            self.repliedlist.removeAll()
            Database.database().reference().child("Feedback").child(self.CmyID7).child("Center").observe(.childAdded, with: { (snapshot) in
                if snapshot.hasChildren(){
                    for snap in snapshot.children{
                        if let node = snap as? DataSnapshot{
                            
                            if node.hasChildren(){
                                for snap2 in node.children{
                                    if let node2 = snap2 as? DataSnapshot{
                                        
                                        if node2.key == "Received"{
                                            
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let IDlist = event()
                                                        
                                                        //feedback content
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        IDlist.mission = finalvalue
                                                        
                                                        //feedback date
                                                        IDlist.url = snapshot.key
                                                        
                                                        //feedback time
                                                        IDlist.url1 = node3.key
                                                        
                                                        self.feedbackIDlist.append(IDlist)
                                                        self.fbIDTBV.reloadData()
                                                    }
                                                }
                                            }
                                        }else if node2.key == "Replied"{
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let replylist = typeAry2()
                                                        replylist.typeAry = node3.key
                                                        
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        replylist.Ary2 = finalvalue.replacingOccurrences(of: "~", with: " ")
                                                        
                                                        self.repliedlist.append(replylist)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }, withCancel: nil)
            
            //date tableview
            self.datelist.removeAll()
            Database.database().reference().child("Feedback").child(CmyID7).child("Center").observe(.childAdded, with: { (snapshot) in
                let datelist = array1()
                datelist.typesTask = snapshot.key
                
                self.datelist.append(datelist)
                self.dateTBV.reloadData()
            }, withCancel: nil)
            
        }else{
            centerCheckBox.isSelected = false
            
            //feedbackID tableview
            self.feedbackIDlist.removeAll()
            self.repliedlist.removeAll()
            Database.database().reference().child("Feedback").child(self.CmyID7).child("Center").observe(.childAdded, with: { (snapshot) in
                if snapshot.hasChildren(){
                    for snap in snapshot.children{
                        if let node = snap as? DataSnapshot{
                            
                            if node.hasChildren(){
                                for snap2 in node.children{
                                    if let node2 = snap2 as? DataSnapshot{
                                        
                                        if node2.key == "Received"{
                                            
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let IDlist = event()
                                                        
                                                        //feedback content
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        IDlist.mission = finalvalue
                                                        
                                                        //feedback date
                                                        IDlist.url = snapshot.key
                                                        
                                                        //feedback time
                                                        IDlist.url1 = node3.key
                                                        
                                                        self.feedbackIDlist.append(IDlist)
                                                        self.fbIDTBV.reloadData()
                                                    }
                                                }
                                            }
                                        }else if node2.key == "Replied"{
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let replylist = typeAry2()
                                                        replylist.typeAry = node3.key
                                                        
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        replylist.Ary2 = finalvalue.replacingOccurrences(of: "~", with: " ")
                                                        
                                                        self.repliedlist.append(replylist)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }, withCancel: nil)
            Database.database().reference().child("Feedback").child(self.CmyID7).child("System").observe(.childAdded, with: { (snapshot) in
                if snapshot.hasChildren(){
                    for snap in snapshot.children{
                        if let node = snap as? DataSnapshot{
                            
                            if node.hasChildren(){
                                for snap2 in node.children{
                                    if let node2 = snap2 as? DataSnapshot{
                                        
                                        if node2.key == "Received"{
                                            
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let IDlist = event()
                                                        
                                                        //feedback content
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        IDlist.mission = finalvalue
                                                        
                                                        //feedback date
                                                        IDlist.url = snapshot.key
                                                        
                                                        //feedback time
                                                        IDlist.url1 = node3.key
                                                        
                                                        self.feedbackIDlist.append(IDlist)
                                                        self.fbIDTBV.reloadData()
                                                    }
                                                }
                                            }
                                        }else if node2.key == "Replied"{
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let replylist = typeAry2()
                                                        replylist.typeAry = node3.key
                                                        
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        replylist.Ary2 = finalvalue.replacingOccurrences(of: "~", with: " ")
                                                        
                                                        self.repliedlist.append(replylist)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }, withCancel: nil)
            
            //date tableview
            self.datelist.removeAll()
            self.dateTBV.reloadData()
//            Database.database().reference().child("Feedback").child(self.CmyID7).observe(.childAdded, with: { (snapshot) in
//                if snapshot.hasChildren(){
//                    for snap in snapshot.children{
//                        if let node = snap as? DataSnapshot{
//                            let tag = node.key
//
//                            let datelist = array1()
//                            datelist.typesTask = tag
//
//                            self.datelist.append(datelist)
//                            self.dateTBV.reloadData()
//                        }
//                    }
//                }
//            }, withCancel: nil)
            
            
        }
    }
    
    
    
    
    
    
    
    
    @IBAction func clickSystem(_ sender: UIButton) {
        selectBottom.setTitle("請選擇日期", for: .normal)
        
        if systemCheckBox.isSelected == false{
            systemCheckBox.isSelected = true
            centerCheckBox.isSelected = false
            
            //feedbackID tableview
            self.feedbackIDlist.removeAll()
            self.repliedlist.removeAll()
            Database.database().reference().child("Feedback").child(self.CmyID7).child("System").observe(.childAdded, with: { (snapshot) in
                if snapshot.hasChildren(){
                    for snap in snapshot.children{
                        if let node = snap as? DataSnapshot{
                            
                            if node.hasChildren(){
                                for snap2 in node.children{
                                    if let node2 = snap2 as? DataSnapshot{
                                        
                                        if node2.key == "Received"{
                                            
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let IDlist = event()
                                                        
                                                        //feedback content
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        IDlist.mission = finalvalue
                                                        
                                                        //feedback date
                                                        IDlist.url = snapshot.key
                                                        
                                                        //feedback time
                                                        IDlist.url1 = node3.key
                                                        
                                                        self.feedbackIDlist.append(IDlist)
                                                        self.fbIDTBV.reloadData()
                                                    }
                                                }
                                            }
                                        }else if node2.key == "Replied"{
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let replylist = typeAry2()
                                                        replylist.typeAry = node3.key
                                                        
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        replylist.Ary2 = finalvalue.replacingOccurrences(of: "~", with: " ")
                                                        
                                                        self.repliedlist.append(replylist)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }, withCancel: nil)
            
            //date tableview
            self.datelist.removeAll()
            Database.database().reference().child("Feedback").child(CmyID7).child("System").observe(.childAdded, with: { (snapshot) in
                let datelist = array1()
                datelist.typesTask = snapshot.key
                
                self.datelist.append(datelist)
                self.dateTBV.reloadData()
            }, withCancel: nil)
            
        }else{
            systemCheckBox.isSelected = false
            
            //feedbackID tableview
            self.feedbackIDlist.removeAll()
            self.repliedlist.removeAll()
            Database.database().reference().child("Feedback").child(self.CmyID7).child("Center").observe(.childAdded, with: { (snapshot) in
                if snapshot.hasChildren(){
                    for snap in snapshot.children{
                        if let node = snap as? DataSnapshot{
                            
                            if node.hasChildren(){
                                for snap2 in node.children{
                                    if let node2 = snap2 as? DataSnapshot{
                                        
                                        if node2.key == "Received"{
                                            
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let IDlist = event()
                                                        
                                                        //feedback content
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        IDlist.mission = finalvalue
                                                        
                                                        //feedback date
                                                        IDlist.url = snapshot.key
                                                        
                                                        //feedback time
                                                        IDlist.url1 = node3.key
                                                        
                                                        self.feedbackIDlist.append(IDlist)
                                                        self.fbIDTBV.reloadData()
                                                    }
                                                }
                                            }
                                        }else if node2.key == "Replied"{
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let replylist = typeAry2()
                                                        replylist.typeAry = node3.key
                                                        
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        replylist.Ary2 = finalvalue.replacingOccurrences(of: "~", with: " ")
                                                        
                                                        self.repliedlist.append(replylist)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }, withCancel: nil)
            
            Database.database().reference().child("Feedback").child(self.CmyID7).child("System").observe(.childAdded, with: { (snapshot) in
                if snapshot.hasChildren(){
                    for snap in snapshot.children{
                        if let node = snap as? DataSnapshot{
                            
                            if node.hasChildren(){
                                for snap2 in node.children{
                                    if let node2 = snap2 as? DataSnapshot{
                                        
                                        if node2.key == "Received"{
                                            
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let IDlist = event()
                                                        
                                                        //feedback content
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        IDlist.mission = finalvalue
                                                        
                                                        //feedback date
                                                        IDlist.url = snapshot.key
                                                        
                                                        //feedback time
                                                        IDlist.url1 = node3.key
                                                        
                                                        self.feedbackIDlist.append(IDlist)
                                                        self.fbIDTBV.reloadData()
                                                    }
                                                }
                                            }
                                        }else if node2.key == "Replied"{
                                            if node2.hasChildren(){
                                                for snap3 in node2.children{
                                                    if let node3 = snap3 as? DataSnapshot{
                                                        
                                                        let replylist = typeAry2()
                                                        replylist.typeAry = node3.key
                                                        
                                                        let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                        replylist.Ary2 = finalvalue.replacingOccurrences(of: "~", with: " ")
                                                        
                                                        self.repliedlist.append(replylist)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }, withCancel: nil)
            
            
            //date tableview
            self.datelist.removeAll()
            self.dateTBV.reloadData()
//            Database.database().reference().child("Feedback").child(self.CmyID7).observe(.childAdded, with: { (snapshot) in
//                if snapshot.hasChildren(){
//                    for snap in snapshot.children{
//                        if let node = snap as? DataSnapshot{
//                            let tag = node.key
//
//                            let datelist = array1()
//                            datelist.typesTask = tag
//
//                            self.datelist.append(datelist)
//                            self.dateTBV.reloadData()
//                        }
//                    }
//                }
//            }, withCancel: nil)
        }
    }
    
    
    //datepicker
    @IBOutlet weak var selectBottom: UIButton!
    @IBAction func clickonBottom(_ sender: UIButton) {
        if dateTBV.isHidden == true{
            self.dateTBV.isHidden = false
        }
        else{
            self.dateTBV.isHidden = true
        }
    }
    
    
    var CmyID7 = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchdata()
    }
    
    func fetchdata(){
        Database.database().reference().child("Feedback").child(self.CmyID7).child("Center").observe(.childAdded, with: { (snapshot) in
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        
                        if node.hasChildren(){
                            for snap2 in node.children{
                                if let node2 = snap2 as? DataSnapshot{
                                    
                                    if node2.key == "Received"{
                                        
                                        if node2.hasChildren(){
                                            for snap3 in node2.children{
                                                if let node3 = snap3 as? DataSnapshot{
                                                    
                                                    let IDlist = event()
                                                    
                                                    //feedback content
                                                    let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                    IDlist.mission = finalvalue
                                                    
                                                    //feedback date
                                                    IDlist.url = snapshot.key
                                                    
                                                    //feedback time
                                                    IDlist.url1 = node3.key
                                                    
                                                    self.feedbackIDlist.append(IDlist)
                                                    self.fbIDTBV.reloadData()
                                                }
                                            }
                                        }
                                    }else if node2.key == "Replied"{
                                        if node2.hasChildren(){
                                            for snap3 in node2.children{
                                                if let node3 = snap3 as? DataSnapshot{
                                                    
                                                    let replylist = typeAry2()
                                                    replylist.typeAry = node3.key
                                                    
                                                    let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                    replylist.Ary2 = finalvalue.replacingOccurrences(of: "~", with: " ")
                                                    
                                                    self.repliedlist.append(replylist)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }, withCancel: nil)
        Database.database().reference().child("Feedback").child(self.CmyID7).child("System").observe(.childAdded, with: { (snapshot) in
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        
                        if node.hasChildren(){
                            for snap2 in node.children{
                                if let node2 = snap2 as? DataSnapshot{
                                    
                                    if node2.key == "Received"{
                                        
                                        if node2.hasChildren(){
                                            for snap3 in node2.children{
                                                if let node3 = snap3 as? DataSnapshot{
                                                    
                                                    let IDlist = event()
                                                    
                                                    //feedback content
                                                    let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                    IDlist.mission = finalvalue
                                                    
                                                    //feedback date
                                                    IDlist.url = snapshot.key
                                                    
                                                    //feedback time
                                                    IDlist.url1 = node3.key
                                                    
                                                    self.feedbackIDlist.append(IDlist)
                                                    self.fbIDTBV.reloadData()
                                                }
                                            }
                                        }
                                    }else if node2.key == "Replied"{
                                        if node2.hasChildren(){
                                            for snap3 in node2.children{
                                                if let node3 = snap3 as? DataSnapshot{
                                                    
                                                    let replylist = typeAry2()
                                                    replylist.typeAry = node3.key
                                                    
                                                    let finalvalue = (node3.value as? String)!.replacingOccurrences(of: "\"", with: "")
                                                    replylist.Ary2 = finalvalue.replacingOccurrences(of: "~", with: " ")
                                                    
                                                    self.repliedlist.append(replylist)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }, withCancel: nil)
    }
    
    
    @IBAction func finishViewing(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }

}
