//
//  C-ChangePassword.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/15.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_ChangePassword: UIViewController {

    @IBAction func cancelbutton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var currentField: UITextField!
    @IBOutlet weak var newField: UITextField!
    @IBOutlet weak var confirmField: UITextField!
    @IBOutlet weak var savebutton: UIButton!
    @IBAction func savebuttonclick(_ sender: UIButton) {
        
        //CNA user
        Database.database().reference().child("CNA").child(CresetpasswordID).child("Portfolio").child("Password").observe(.value, with: { (snapshot) in
            if self.currentField.text == (snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""){
                
                
                if self.newField.text == self.confirmField.text{
                    
                    if self.newField.text == (snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""){
                        self.alertMessage(userMessage: "新舊密碼請勿相同。")
                    }
                        
                    else if (self.newField.text)!.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "#") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "/") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "\"") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: ",") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: ":") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "@") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "$") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "{") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "}") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "(") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: ")") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "*") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "[") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }else if (self.newField.text)!.range(of: "]") != nil{
                        self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                    }
                        
                    else if self.newField.text!.count < 8{
                        self.alertMessage(userMessage: "密碼必須大於（等於）8 個字。")
                    }
                        
                    else{
                        let finalconfirm = UIAlertController(title: "提示", message: "確定要更改您的密碼？", preferredStyle: .alert)
                        finalconfirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
                        finalconfirm.addAction(UIAlertAction(title: "同意", style: .default, handler: { (action) in
                            
                            let dateformatter = DateFormatter()
                            dateformatter.dateFormat = "yyyy-MM-dd-hh:mm:ss"
                            let str = dateformatter.string(from: Date())
                            
                            Database.database().reference().child("CNA").child(self.CresetpasswordID).child("Portfolio").child("Password").setValue(self.confirmField.text)
                            
                            
                            //Change Password History
                            Database.database().reference().child("AccountStatus").child("App").child(self.CresetpasswordID).child("ChangePasswordHistory").child(str).setValue("\(String(describing: (self.currentField.text)!))~\(String(describing: (self.newField.text)!))")
                            
                            
                            let resetsucceed = UIAlertController(title: "成功", message: "", preferredStyle: .alert)
                            resetsucceed.addAction(UIAlertAction(title: "完成", style: .default, handler: { (action) in
                                self.dismiss(animated: true, completion: nil)
                            }))
                            self.present(resetsucceed, animated: true, completion: nil)
                        }))
                        self.present(finalconfirm, animated: true, completion: nil)
                    }
                }else{
                    let errorMessage = UIAlertController(title: "Oops", message: "密碼不相同。", preferredStyle: .alert)
                    errorMessage.addAction(UIAlertAction(title: "了解", style: .default, handler: nil))
                    self.present(errorMessage, animated: true, completion: nil)
                }
                
            }
                
                
                
                
            else{
                
                //family user
                Database.database().reference().child("Patient").child(self.CresetpasswordID).child("Portfolio").child("Password").observe(.value, with: { (snapshot) in
                    if self.currentField.text == (snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""){
                        
                        
                        if self.newField.text == self.confirmField.text{
                            
                            if self.newField.text == snapshot.value as? String{
                                self.alertMessage(userMessage: "新舊密碼請勿相同。")
                            }
                                
                            else if (self.newField.text)!.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "#") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "/") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "\"") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: ",") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: ":") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "@") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "$") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "{") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "}") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "(") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: ")") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "*") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "[") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }else if (self.newField.text)!.range(of: "]") != nil{
                                self.alertMessage(userMessage: "密碼請勿含有空白格與特殊符號（#, {, ?, @, %）。")
                            }
                                
                            else if self.newField.text!.count < 8{
                                self.alertMessage(userMessage: "密碼必須大於（等於）8 個字。")
                            }
                                
                            else{
                                let finalconfirm = UIAlertController(title: "提示", message: "確定要更改您的密碼？", preferredStyle: .alert)
                                finalconfirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
                                finalconfirm.addAction(UIAlertAction(title: "同意", style: .default, handler: { (action) in
                                    
                                    let dateformatter = DateFormatter()
                                    dateformatter.dateFormat = "yyyy-MM-dd-hh:mm:ss"
                                    let str = dateformatter.string(from: Date())
                                    
                                    Database.database().reference().child("Patient").child(self.CresetpasswordID).child("Portfolio").child("Password").setValue(self.confirmField.text)
                                    
                                    
                                    //Change Password History
                                    Database.database().reference().child("AccountStatus").child("App").child(self.CresetpasswordID).child("ChangePasswordHistory").child(str).setValue("\(String(describing: (self.currentField.text)!))~\(String(describing: (self.newField.text)!))")
                                    
                                    
                                    let resetsucceed = UIAlertController(title: "成功", message: "", preferredStyle: .alert)
                                    resetsucceed.addAction(UIAlertAction(title: "完成", style: .default, handler: { (action) in
                                        self.dismiss(animated: true, completion: nil)
                                    }))
                                    self.present(resetsucceed, animated: true, completion: nil)
                                }))
                                self.present(finalconfirm, animated: true, completion: nil)
                            }
                        }else{
                            let errorMessage = UIAlertController(title: "Oops", message: "密碼不相同。", preferredStyle: .alert)
                            errorMessage.addAction(UIAlertAction(title: "了解", style: .default, handler: nil))
                            self.present(errorMessage, animated: true, completion: nil)
                        }
                    }else{
                        let errorMessage = UIAlertController(title: "Oops", message: "當前密碼錯誤。", preferredStyle: .alert)
                        errorMessage.addAction(UIAlertAction(title: "了解", style: .default, handler: nil))
                        self.present(errorMessage, animated: true, completion: nil)
                    }
                }, withCancel: nil)
            }
        }, withCancel: nil)
        
    }
    
    func alertMessage(userMessage: String){
        let alert = UIAlertController(title: "Oops", message: userMessage, preferredStyle: .alert)
        let okaction = UIAlertAction(title: "了解", style: .default, handler: nil)
        alert.addAction(okaction)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    //set save button enable or not
    @IBAction func Field1(_ sender: UITextField) {
        if currentField.text?.isEmpty == false && newField.text?.isEmpty == false && confirmField.text?.isEmpty == false{
            savebutton.isEnabled = true
        }else if currentField.text?.isEmpty == true || newField.text?.isEmpty == true || confirmField.text?.isEmpty == true{
            savebutton.isEnabled = false
        }
    }
    @IBAction func FIeld2(_ sender: UITextField) {
        if currentField.text?.isEmpty == false && newField.text?.isEmpty == false &&  confirmField.text?.isEmpty == false{
            savebutton.isEnabled = true
        }else if currentField.text?.isEmpty == true || newField.text?.isEmpty == true || confirmField.text?.isEmpty == true{
            savebutton.isEnabled = false
        }
    }
    @IBAction func Field3(_ sender: UITextField) {
        if currentField.text?.isEmpty == false && newField.text?.isEmpty == false && confirmField.text?.isEmpty == false {
            savebutton.isEnabled = true
        }else if currentField.text?.isEmpty == true || newField.text?.isEmpty == true || confirmField.text?.isEmpty == true{
            savebutton.isEnabled = false
        }
    }
    
    
    
    var CresetpasswordID = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        savebutton.isEnabled = false
        
        
    }
}
