//
//  C-help&supportVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/19.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase
import MessageUI

class C_help_supportVC: UIViewController, UITableViewDelegate, UITableViewDataSource, MFMailComposeViewControllerDelegate, UITextViewDelegate {
    
    let conbinelist = [
        ["意見回饋", "回饋記錄"],
        ["立即通話", "寄送郵件", "導航至中心"],
        ["切換語言", "更改密碼", "系統政策"]
    ]
    let headerlist = ["", "", ""]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return conbinelist[section].count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return conbinelist.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let label = UILabel()
        label.text = headerlist[section]
        
        return label
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cellID")
        let name = conbinelist[indexPath.section][indexPath.row]
        
        
        cell.textLabel?.text = name
        cell.textLabel?.font = UIFont(descriptor: .init(), size: 20)
        //cell.backgroundColor = UIColor.init(displayP3Red: 229/255, green: 255/255, blue: 223/255, alpha: 1.0)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let name = conbinelist[indexPath.section][indexPath.row]
        if name == "意見回饋"{
            let helppage = storyboard?.instantiateViewController(withIdentifier: "C_HelpVC") as? C_HelpVC
            helppage?.CmyID6 = self.ChelpID
            self.present(helppage!, animated: true, completion: nil)
        }
        else if name == "回饋記錄"{
            let FBhistory = storyboard?.instantiateViewController(withIdentifier: "C_feebackhistory") as? C_feebackhistory
            FBhistory?.CmyID7 = self.ChelpID
            self.present(FBhistory!, animated: true, completion: nil)
        }
        else if name == "立即通話"{
            Database.database().reference().child("CenterInformation").child("ContactInfo").child("Contact No").observe(.value) { (snapshot) in
                
                let url : NSURL = URL(string: "TEL://\(snapshot.value as! String)")! as NSURL
                UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
                
            }
        }
        else if name == "寄送郵件"{
            let mailsend = MFMailComposeViewController()
            mailsend.mailComposeDelegate = self
            Database.database().reference().child("CenterInformation").child("ContactInfo").child("Email").observe(.value) { (snapshot) in
                
                mailsend.setToRecipients(["\(snapshot.value as! String)"])
                mailsend.setSubject("Test")
            }
            
            if MFMailComposeViewController.canSendMail(){
                self.present(mailsend, animated: true, completion: nil)
            }
            else{
                print("NO")
            }
        }
        else if name == "導航至位置"{
            UIApplication.shared.open(URL(string: "https://www.google.com.tw/maps/place/%E9%8A%98%E5%82%B3%E5%A4%A7%E5%AD%B8+%E6%A1%83%E5%9C%92%E6%A0%A1%E5%8D%80/@24.985171,121.339809,17z/data=!4m8!1m2!2m1!1z6YqY5YKz5aSn5a24!3m4!1s0x34681e8f88001f51:0xde8e62ebe5442d75!8m2!3d24.9844926!4d121.3423688")!, options: [:], completionHandler: nil)
        }
        else if name == "切換語言"{
            let switchlanguage = UIAlertController(title: "選擇語言", message: "", preferredStyle: .alert)
            switchlanguage.addAction(UIAlertAction(title: "English", style: .default, handler: { (action) in
                let languageswitch = self.storyboard?.instantiateViewController(withIdentifier: "help_support") as? help_support
                languageswitch?.myID5 = self.ChelpID
                self.present(languageswitch!, animated: false, completion: nil)
            }))
            switchlanguage.addAction(UIAlertAction(title: "中文", style: .default, handler: nil))
            
            present(switchlanguage, animated: true, completion: nil)
        }
        else if name == "更改密碼"{
            let passwordpage = storyboard?.instantiateViewController(withIdentifier: "C_ChangePassword") as? C_ChangePassword
            passwordpage?.CresetpasswordID = self.ChelpID
            self.present(passwordpage!, animated: true, completion: nil)
        }
        else if name == "系統政策"{
            Database.database().reference().child("Policy").child("P1").child("System Policy").observe(.value, with: { (snapshot) in
                UIApplication.shared.open(URL(string: (snapshot.value as? String)!)!, options: [:], completionHandler: nil)
            }, withCancel: nil)
        }
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let CNAhomepage = storyboard?.instantiateViewController(withIdentifier: "C_CNAVC") as? C_CNAVC
        CNAhomepage?.CmyID = self.ChelpID
        self.present(CNAhomepage!, animated: false, completion: nil)
    }

    //hamburgerIcon
    @IBOutlet weak var HBpage: UIStackView!
    @IBAction func HamburgerPageIcon(_ sender: UIButton) {
        if(HBpage.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.HBpage.window!.layer.add(transition, forKey: kCATransition)

            HBpage.isHidden = false
        }
        else{
            HBpage.isHidden = true
        }
    }
    @IBAction func Portfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_PortolioVC") as? C_PortolioVC
        portfoliopage?.CmyID1 = self.ChelpID
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func Task(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionVC") as? C_TaskInstructionVC
        taskpage?.CmyID2 = self.ChelpID
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func workingschedule(_ sender: UIButton) {
        let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingScheduleVC") as? C_WorkingScheduleVC
        workingschedulepage?.CmyID3 = self.ChelpID
        self.present(workingschedulepage!, animated: false, completion: nil)
    }
    @IBAction func workinghour(_ sender: UIButton) {
        let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingHourVC") as? C_WorkingHourVC
        workinghourpage?.CmyID4 = self.ChelpID
        self.present(workinghourpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_CNAAboutUsVC") as? C_CNAAboutUsVC
        aboutuspage?.CCNAAboutmyID = self.ChelpID
        self.present(aboutuspage!, animated: false, completion: nil)
    }

    //help & support
    @IBAction func helpIcon(_ sender: UIButton) {
        if HBpage.isHidden == false{
            HBpage.isHidden = true
        }
    }


    //logoutIcon
    @IBAction func LogoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){

        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC") as? C_LoginVC

        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            
            Database.database().reference().child("AccountStatus").child("App").child(self.ChelpID).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.ChelpID).child("LatestLogout").setValue("\(str)-\(str2)")
            self.present(login!, animated: true, completion: nil)}))

        self.present(confirm, animated: true, completion: nil)
    }

    var ChelpID = String()
    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
