//
//  C-FamilyVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/15.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_FamilyVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    //AnnouncementBoard
    var eventlist = [event]()
    let cellID = "cellID"
    @IBOutlet weak var announcementboard: UITableView!
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return eventlist.count
    }
    @IBOutlet weak var showAnnouncement: UITextView!
    var myindex = 0
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let cell = announcementboard.dequeueReusableCell(withIdentifier: cellID, for: indexPath)
        cell.textLabel?.text = self.eventlist[indexPath.row].mission
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        showAnnouncement.text = eventlist[indexPath.row].url
    }
    
    @IBAction func centerschedule(_ sender: UIButton) {
        Database.database().reference().child("CenterSchedule").observe(.childAdded, with: { (snapshot) in
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        if tag == "url"{
                            let url = node.value as? String
                            UIApplication.shared.open(URL(string: url!)!, options: [:], completionHandler: nil)
                        }
                    }
                }
            }
        }, withCancel: nil)
    }
    
    
    
    
    //HomeIcon
    @IBAction func HomeIcon(_ sender: UIButton) {
        
        eventlist.removeAll()
        
        //refresh ViewController to first response
        let parent = view.superview
        view.removeFromSuperview()
        view = nil
        parent?.addSubview(view)
        
        if(Hamburger.isHidden == false){
            Hamburger.isHidden = true
        }
    }
    
    
    //HamburgerPageIcon
    @IBOutlet weak var Hamburger: UIStackView!
    @IBAction func HamburgerBottom(_ sender: UIButton) {
        if(Hamburger.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.Hamburger.window!.layer.add(transition, forKey: kCATransition)
            
            Hamburger.isHidden = false
        }
        else{
            Hamburger.isHidden = true
        }
    }
    @IBAction func clickPortfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_FPortfolioVC") as? C_FPortfolioVC
        portfoliopage?.CFmyID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func clickTask(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_FTaskInstructionVC") as? C_FTaskInstructionVC
        taskpage?.CFmyID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func clickDailyRecord(_ sender: UIButton) {
        let dailypage = storyboard?.instantiateViewController(withIdentifier: "C_DailyStatusVC") as? C_DailyStatusVC
        dailypage?.CFmyID3 = self.UID.text!
        self.present(dailypage!, animated: false, completion: nil)
    }
    @IBAction func clickVitalRecod(_ sender: UIButton) {
        let vitalpage = storyboard?.instantiateViewController(withIdentifier: "C_VitalStatusVC") as? C_VitalStatusVC
        vitalpage?.CFmyID4 = self.UID.text!
        self.present(vitalpage!, animated: false, completion: nil)
    }
    @IBAction func clickAIRecord(_ sender: UIButton) {
        let AIpage = storyboard?.instantiateViewController(withIdentifier: "C_AIStatusVC") as? C_AIStatusVC
        AIpage?.CFmyID5 = self.UID.text!
        self.present(AIpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_FAboutUsVC") as? C_FAboutUsVC
        aboutuspage?.CAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_FHelpSupport") as? C_FHelpSupport
        helpmenu?.CFmyID6 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //LogoutIcon
    @IBAction func LogoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginFAM")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage: String){
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC") as? C_LoginVC
        
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler: { (action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.CFmyID).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CFmyID).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)
        }))
        self.present(confirm, animated: true, completion: nil)
    }
    
    
    //userID tag
    @IBOutlet weak var UID: UILabel!
    var CFmyID = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showAnnouncement.isEditable = false
        
        //userID tag
        UID.text = CFmyID
        
        fetchEvent()
    }
    
    
    func fetchEvent(){
        Database.database().reference().child("Announcements").observe(.childAdded, with: { (snapshot) in
            if let dictionary = snapshot.value as? [String:AnyObject]{
                
                let events = event()
                events.mission = dictionary["ATitleIOS"] as? String
                events.url = dictionary["AnnouncementIOS"] as? String
                
                self.eventlist.append(events)
                self.announcementboard.reloadData()
            }
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
