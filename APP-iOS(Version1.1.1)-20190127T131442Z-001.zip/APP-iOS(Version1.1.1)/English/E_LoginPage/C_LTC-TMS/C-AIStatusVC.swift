//
//  C-AIStatusVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/15.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_AIStatusVC: UIViewController, UITableViewDelegate, UITableViewDataSource {

    //Current Step, Current Heart Rate
    @IBOutlet weak var CurrentStep: UILabel!
    @IBOutlet weak var CurrentHeartRate: UILabel!
    
    
    //DatePicker, Step
    @IBOutlet weak var selectButton: UIButton!
    @IBOutlet weak var selectDate: UIDatePicker!
    @IBAction func clickbutton(_ sender: UIButton) {
        
        if selectDate.isHidden == true{
            selectDate.isHidden = false
            
            if PlaceTBV.isHidden == false || RoomTBV.isHidden == false{
                PlaceTBV.isHidden = true
                RoomTBV.isHidden = true
            }
            self.SelectDateStep.text = "無資料"
        }
        else{
            selectDate.isHidden = true
            
            self.selectplace.setTitle("select", for: .normal)
            self.selectroom.setTitle("select", for: .normal)
            
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-M-d"
            let str = formatter.string(from: selectDate.date)
            selectButton.setTitle(str, for: .normal)
            
            
            //Steps
            Database.database().reference().child("Activities").child(UID.text!).child(str).child("AI").child("Step").observe(.childAdded, with: { (snapshot) in
                let data = (snapshot.value as? String)!.replacingOccurrences(of: "?", with: " ")
                let finaldata = data.replacingOccurrences(of: "~", with: ":")
                self.SelectDateStep.text = finaldata
            }, withCancel: nil)
            
            
            //Heart Rate
            self.HeartRateRecord.removeAll()
            self.HeartRateTBV.reloadData()
            Database.database().reference().child("Activities").child(UID.text!).child(str).child("AI").child("HeartRateRecord").observe(.childAdded, with: { (snapshot) in
                let listHR = HRrecord()
                let tag = (snapshot.key).replacingOccurrences(of: "?", with: " ")
                let finaltag = tag.replacingOccurrences(of: "~", with: ":")
                let data = (snapshot.value as! String).replacingOccurrences(of: " ", with: "")
                
                listHR.HRlist = "\(finaltag), \(data)bpm"
                
                self.HeartRateRecord.append(listHR)
                self.HeartRateTBV.reloadData()
            }, withCancel: nil)
            
            
            //LocationPlace
            self.Times.removeAll()
            self.Places.removeAll()
            self.PlaceTBV.reloadData()
            self.LocationTBV.reloadData()
            Database.database().reference().child("Activities").child(UID.text!).child(str).child("AI").child("Location").observe(.childAdded, with: { (snapshot) in
                let placelist = LOC()
                placelist.place = snapshot.key
                
                self.Places.append(placelist)
                self.PlaceTBV.reloadData()
            }, withCancel: nil)
            
            
            //Environmnent Status
            self.Rooms.removeAll()
            self.Temp.removeAll()
            self.RoomTBV.reloadData()
            self.TempTBV.reloadData()
            
            Database.database().reference().child("Activities").child("EnvironmentStatus").child(str).observe(.childAdded, with: { (snapshot) in
                let rooms = Room()
                rooms.roomlist = snapshot.key
                
                self.Rooms.append(rooms)
                self.RoomTBV.reloadData()
            }, withCancel: nil)
        }
    }
    @IBOutlet weak var SelectDateStep: UILabel!
    
    
    //Heart Rate
    var HeartRateRecord = [HRrecord]()
    @IBOutlet weak var HeartRateTBV: UITableView!
    
    //Times
    var Times = [times]()
    @IBOutlet weak var LocationTBV: UITableView!
    //Places
    var Places = [LOC]()
    @IBOutlet weak var PlaceTBV: UITableView!
    
    //PlacesEnv
    var Rooms = [Room]()
    @IBOutlet weak var RoomTBV: UITableView!
    //Temp
    var Temp = [TempRecord]()
    @IBOutlet weak var TempTBV: UITableView!
    
    
    //information
    @IBAction func clickInfo(_ sender: UIButton) {
        let alert = UIAlertController(title: "濕度指標", message: "高於55% = 潮濕\n45%~55% = 舒適\n低於45% = 乾燥", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "了解", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    
    //tableview setting
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == HeartRateTBV{
            return HeartRateRecord.count
        }else if tableView == PlaceTBV{
            return Places.count
        }else if tableView == LocationTBV{
            return Times.count
        }else if tableView == RoomTBV{
            return Rooms.count
        }else{
            return Temp.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == HeartRateTBV{
            let cell = tableView.dequeueReusableCell(withIdentifier: "HeartCellID", for: indexPath)
            cell.textLabel?.text = HeartRateRecord[indexPath.row].HRlist
            cell.textLabel?.font = UIFont.systemFont(ofSize: 14.0)
            return cell
        }
        else if tableView == PlaceTBV{
            let cell = tableView.dequeueReusableCell(withIdentifier: "PlaceCellID", for: indexPath)
            cell.textLabel?.text = Places[indexPath.row].place
            return cell
        }
        else if tableView == LocationTBV{
            let cell = tableView.dequeueReusableCell(withIdentifier: "TimesCellID", for: indexPath)
            cell.textLabel?.text = Times[indexPath.row].times
            cell.textLabel?.font = UIFont.systemFont(ofSize: 14.0)
            return cell
        }
        else if tableView == RoomTBV{
            let cell = tableView.dequeueReusableCell(withIdentifier: "RoomCellID", for: indexPath)
            cell.textLabel?.text = Rooms[indexPath.row].roomlist
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "EnvCellID", for: indexPath)
            cell.textLabel?.text = Temp[indexPath.row].templist
            cell.textLabel?.font = UIFont.systemFont(ofSize: 14.0)
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == PlaceTBV{
            self.Times.removeAll()
            Database.database().reference().child("Activities").child(UID.text!).child((selectButton.titleLabel?.text)!).child("AI").child("Location").child(Places[indexPath.row].place).observe(.childAdded, with: { (snapshot) in
                let timeslist = times()
                let tag = snapshot.key.replacingOccurrences(of: "~", with: ":")
                let data = snapshot.value as! String
                
                
                timeslist.times = "\(tag):\(data)"
                
                self.Times.append(timeslist)
                self.LocationTBV.reloadData()
                
                self.PlaceTBV.isHidden = true
                self.selectplace.setTitle(self.Places[indexPath.row].place, for: .normal)
            }, withCancel: nil)
        }
        else if tableView == RoomTBV{
            self.Temp.removeAll()
            Database.database().reference().child("Activities").child("EnvironmentStatus").child((selectButton.titleLabel?.text)!).child(Rooms[indexPath.row].roomlist).observe(.childAdded, with: { (snapshot) in
                let templist = TempRecord()
                let tag = snapshot.key
                let data = snapshot.value as? String
                let replacedata = data?.replacingOccurrences(of: "&", with: ", ")
                let replacedata1 = replacedata?.replacingOccurrences(of: "?", with: "")
                
                let finaldata = "\(tag)  \(replacedata1!)"
                
                templist.templist = finaldata
                
                self.Temp.append(templist)
                self.TempTBV.reloadData()
                
                self.RoomTBV.isHidden = true
                self.selectroom.setTitle(self.Rooms[indexPath.row].roomlist, for: .normal)
            }, withCancel: nil)
        }
    }
    
    //SelectLocation buttom
    @IBOutlet weak var selectplace: UIButton!
    @IBAction func clickonBottom(_ sender: UIButton) {
        //        self.Times.removeAll()
        //        self.LocationTBV.reloadData()
        if PlaceTBV.isHidden == true{
            UIView.animate(withDuration: 0.3) {
                self.PlaceTBV.isHidden = false
            }
        }
        else{
            UIView.animate(withDuration: 0.3) {
                self.PlaceTBV.isHidden = true
            }
        }
        
    }
    
    //SelectRoom buttom
    @IBOutlet weak var selectroom: UIButton!
    @IBAction func clickonButtom(_ sender: UIButton) {
        //        self.Temp.removeAll()
        //        self.TempTBV.reloadData()
        if RoomTBV.isHidden == true{
            UIView.animate(withDuration: 0.3) {
                self.RoomTBV.isHidden = false
            }
        }
        else{
            UIView.animate(withDuration: 0.3) {
                self.RoomTBV.isHidden = true
            }
        }
        
    }
    
    
    
    //user tag
    @IBOutlet weak var UID: UILabel!
    var CFmyID5 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //user tag
        UID.text = CFmyID5
        
        //Current Step, Current Heart Rate
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-M-d"
        let str = dateFormatter.string(from: Date())
        
        Database.database().reference().child("Activities").child(UID.text!).child(str).child("AI").child("Step").observe(.childAdded, with: { (snapshot) in
            let str = snapshot.value as? String
            let str2 = str!.replacingOccurrences(of: "~", with: ":")
            let finalstring = str2.replacingOccurrences(of: "?", with: " ")
            self.CurrentStep.text = "目前累積步數: \(finalstring)"
        }, withCancel: nil)
        Database.database().reference().child("Activities").child(UID.text!).child(str).child("AI").child("HeartRate").observe(.childAdded, with: { (snapshot) in
            let string1 = (snapshot.value as? String)!.replacingOccurrences(of: "~", with: ":")
            let finalstring = string1.replacingOccurrences(of: "?", with: " ")
            self.CurrentHeartRate.text = "目前心率: \(finalstring)bpm"
        }, withCancel: nil)
        
        
        //datepicker color
        selectDate.backgroundColor = UIColor.white
        
        
        
        
    }
    
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let familyhomepage = storyboard?.instantiateViewController(withIdentifier: "C_FamilyVC") as? C_FamilyVC
        familyhomepage?.CFmyID = self.UID.text!
        self.present(familyhomepage!, animated: false, completion: nil)
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var Hamburger: UIStackView!
    @IBAction func HamburgerBottom(_ sender: UIButton) {
        if(Hamburger.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.Hamburger.window!.layer.add(transition, forKey: kCATransition)
            
            Hamburger.isHidden = false
        }
        else{
            Hamburger.isHidden = true
        }
    }
    @IBAction func clickEPortfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_FPortfolioVC") as? C_FPortfolioVC
        portfoliopage?.CFmyID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func clickTask(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_FTaskInstructionVC") as? C_FTaskInstructionVC
        taskpage?.CFmyID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func clickDailyRecord(_ sender: UIButton) {
        let dailypage = storyboard?.instantiateViewController(withIdentifier: "C_DailyStatusVC") as? C_DailyStatusVC
        dailypage?.CFmyID3 = self.UID.text!
        self.present(dailypage!, animated: false, completion: nil)
    }
    @IBAction func clickVitalRecod(_ sender: UIButton) {
        let vitalpage = storyboard?.instantiateViewController(withIdentifier: "C_VitalStatusVC") as? C_VitalStatusVC
        vitalpage?.CFmyID4 = self.UID.text!
        self.present(vitalpage!, animated: false, completion: nil)
    }
    @IBAction func clickAIRecord(_ sender: UIButton) {
        let AIpage = storyboard?.instantiateViewController(withIdentifier: "C_AIStatusVC") as? C_AIStatusVC
        AIpage?.CFmyID5 = self.UID.text!
        self.present(AIpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_FAboutUsVC") as? C_FAboutUsVC
        aboutuspage?.CAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_FHelpSupport") as? C_FHelpSupport
        helpmenu?.CFmyID6 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginFAM")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.CFmyID5).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CFmyID5).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
