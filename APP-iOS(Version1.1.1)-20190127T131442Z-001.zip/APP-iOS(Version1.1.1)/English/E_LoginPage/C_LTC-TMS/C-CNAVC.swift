//
//  C-CNAVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/12.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_CNAVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    //AnnouncementBoard
    var eventlist = [event]()
    let cellID = "cellID"
    @IBOutlet weak var announcementboard: UITableView!
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return eventlist.count
    }
    @IBOutlet weak var showAnnouncement: UITextView!
    var myindex = 0
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let cell = announcementboard.dequeueReusableCell(withIdentifier: cellID, for: indexPath)
        cell.textLabel?.text = self.eventlist[indexPath.row].mission
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        showAnnouncement.text = eventlist[indexPath.row].url
    }
    
    
    @IBAction func schedule(_ sender: UIButton) {
        
        Database.database().reference().child("CenterSchedule").observe(.childAdded, with: { (snapshot) in
            if snapshot.hasChildren(){
                for snap in snapshot.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        if tag == "url"{
                            let url = node.value as? String
                            UIApplication.shared.open(URL(string: url!)!, options: [:], completionHandler: nil)
                        }
                    }
                }
            }
        }, withCancel: nil)
    }
    
    
    
    //homeIcon
    @IBAction func HomeIcon(_ sender: UIButton) {
        
        eventlist.removeAll()
        
        //refresh ViewController to first response
        let parent = view.superview
        view.removeFromSuperview()
        view = nil
        parent?.addSubview(view)
        
        if(HBpage.isHidden == false){
            HBpage.isHidden = true
        }
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var HBpage: UIStackView!
    @IBAction func HamburgerPageIcon(_ sender: UIButton) {
        if(HBpage.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.HBpage.window!.layer.add(transition, forKey: kCATransition)
            
            HBpage.isHidden = false
        }
        else{
            HBpage.isHidden = true
        }
    }
    @IBAction func Portfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_PortolioVC") as? C_PortolioVC
        portfoliopage?.CmyID1 = self.CmyID
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func Task(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionVC") as? C_TaskInstructionVC
        taskpage?.CmyID2 = self.CmyID
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func workingschedule(_ sender: UIButton) {
        let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingScheduleVC") as? C_WorkingScheduleVC
        workingschedulepage?.CmyID3 = self.CmyID
        self.present(workingschedulepage!, animated: false, completion: nil)
    }
    @IBAction func workinghour(_ sender: UIButton) {
        let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingHourVC") as? C_WorkingHourVC
        workinghourpage?.CmyID4 = self.CmyID
        self.present(workinghourpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_CNAAboutUsVC") as? C_CNAAboutUsVC
        aboutuspage?.CCNAAboutmyID = self.CmyID
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_help_supportVC") as? C_help_supportVC
        helpmenu?.ChelpID = self.CmyID
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func LogoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC") as? C_LoginVC
        
        let confirm = UIAlertController(title: "提示", message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            
            Database.database().reference().child("AccountStatus").child("App").child(self.CmyID).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CmyID).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        
        self.present(confirm, animated: true, completion: nil)
    }
    
    
    //userID tag
    var CmyID = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showAnnouncement.isEditable = false
        
        fetchEvent()
        
    }
    
    
    //AnnouncementBoard
    func fetchEvent(){
        Database.database().reference().child("Announcements").observe(.childAdded, with: { (snapshot) in
            if let dictionary = snapshot.value as? [String:AnyObject]{
                
                let events = event()
                events.mission = dictionary["ATitleIOS"] as? String
                events.url = dictionary["AnnouncementIOS"] as? String
                
                self.eventlist.append(events)
                self.announcementboard.reloadData()
            }
        })
    }
}
