//
//  C-VitalStatusVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/15.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_VitalStatusVC: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var templist = [event]()
    var bloodlist = [typeAry2]()
    
    
    @IBOutlet weak var tempTBV: UITableView!
    @IBOutlet weak var bloodTBV: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tempTBV{
            return templist.count
        }
        else{
            return bloodlist.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tempTBV{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellIDTemperature", for: indexPath) as! temperatureTBV
            cell.textLabel?.text = templist[indexPath.row].mission
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellIDBlood", for: indexPath) as! bloodpressureTBV
            cell.textLabel?.text = bloodlist[indexPath.row].typeAry
            return cell
        }
    }
    
    //DatePicker
    @IBOutlet weak var selectButton: UIButton!
    @IBOutlet weak var selectDate: UIDatePicker!
    @IBAction func clickDate(_ sender: UIButton) {
        if selectDate.isHidden == true{
            selectDate.isHidden = false
        }
        else{
            selectDate.isHidden = true
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-M-d"
            let str = formatter.string(from: selectDate.date)
            selectButton.setTitle(str, for: .normal)
            
            self.templist.removeAll()
            self.bloodlist.removeAll()
            //Fetch data
            Database.database().reference().child("Patient").child(UID.text!).child(str).child("vital_status").observe(.childAdded, with: { (snapshot) in
                let TBVdata = event()
                TBVdata.mission = snapshot.key
                TBVdata.url = ((snapshot.value as? String)?.replacingOccurrences(of: "\"", with: ""))?.replacingOccurrences(of: "~", with: "/")
                
                let TBVdata2 = typeAry2()
                
                // firebase's data have "_" so try to separated by "_"
                var TBVdataArr = TBVdata.mission.components(separatedBy: "_")
                let name = TBVdataArr[0]
                let time = TBVdataArr[1]
                if name == "Temperature"{
                    let finalData = "\(time)   \(TBVdata.url!)"
                    TBVdata.mission = finalData
                    
                    self.templist.append(TBVdata)
                    self.tempTBV.reloadData()
                }
                else if name == "Blood Pressure"{
                    let finalData = "\(time)   \(TBVdata.url!)"
                    TBVdata2.typeAry = finalData
                    
                    self.bloodlist.append(TBVdata2)
                    self.bloodTBV.reloadData()
                }
                
            }, withCancel: nil)
            self.tempTBV.reloadData()
            self.bloodTBV.reloadData()
        }
    }
    
    //fetchdata for tableview
    func fetchTemp() {
        
    }
    
    //homeIcon
    @IBAction func homeIcon(_ sender: Any) {
        let familyhomepage = storyboard?.instantiateViewController(withIdentifier: "C_FamilyVC") as? C_FamilyVC
        familyhomepage?.CFmyID = self.UID.text!
        self.present(familyhomepage!, animated: false, completion: nil)
    }
    
    
    //hamburgerIcon
    @IBOutlet weak var Hamburger: UIStackView!
    @IBAction func HamburgerBottom(_ sender: UIButton) {
        if(Hamburger.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.Hamburger.window!.layer.add(transition, forKey: kCATransition)
            
            Hamburger.isHidden = false
        }
        else{
            Hamburger.isHidden = true
        }
    }
    @IBAction func clickEPortfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_FPortfolioVC") as? C_FPortfolioVC
        portfoliopage?.CFmyID1 = self.UID.text!
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func clickTask(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_FTaskInstructionVC") as? C_FTaskInstructionVC
        taskpage?.CFmyID2 = self.UID.text!
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func clickDailyRecord(_ sender: UIButton) {
        let dailypage = storyboard?.instantiateViewController(withIdentifier: "C_DailyStatusVC") as? C_DailyStatusVC
        dailypage?.CFmyID3 = self.UID.text!
        self.present(dailypage!, animated: false, completion: nil)
    }
    @IBAction func clickVitalRecod(_ sender: UIButton) {
        let vitalpage = storyboard?.instantiateViewController(withIdentifier: "C_VitalStatusVC") as? C_VitalStatusVC
        vitalpage?.CFmyID4 = self.UID.text!
        self.present(vitalpage!, animated: false, completion: nil)
    }
    @IBAction func clickAIRecord(_ sender: UIButton) {
        let AIpage = storyboard?.instantiateViewController(withIdentifier: "C_AIStatusVC") as? C_AIStatusVC
        AIpage?.CFmyID5 = self.UID.text!
        self.present(AIpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_FAboutUsVC") as? C_FAboutUsVC
        aboutuspage?.CAboutmyID = self.UID.text!
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_FHelpSupport") as? C_FHelpSupport
        helpmenu?.CFmyID6 = self.UID.text!
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginFAM")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            Database.database().reference().child("AccountStatus").child("App").child(self.CFmyID4).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CFmyID4).child("LatestLogout").setValue("\(str)-\(str2)")
            
            self.present(login!, animated: true, completion: nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    
    
    //userID tag
    @IBOutlet weak var UID: UILabel!
    var CFmyID4 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //datepicker color
        selectDate.backgroundColor = UIColor.white
        
        UID.text = CFmyID4
        
        
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
