//
//  C-TaskInstructionVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/13.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_TaskInstructionVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {

    //tableview setting
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == taskTBV{
            if isSeaching{
                return searchtask.count
            }
            return tasklist.count
        }
        else{
            return typelist.count
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == taskTBV{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellIDB", for: indexPath) as! TableViewB
            if isSeaching{
                cell.textLabel?.text = searchtask[indexPath.row].mission
                
                return cell
            }else{
                cell.textLabel?.text = tasklist[indexPath.row].mission
                
                return cell
            }
        }
        else{
            //let cell = UITableViewCell(style: .default, reuseIdentifier: cellID)
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellIDS", for: indexPath) as! TableViewS
            cell.textLabel?.text = typelist[indexPath.row].typeAry
            
            
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == typeTBV{
            selectBottom.setTitle("\(typelist[indexPath.row].typeAry!)", for: .normal)
            UIView.animate(withDuration: 0.3) {
                self.typeTBV.isHidden = true
                
                tasklist.removeAll()
                
                Database.database().reference().child("CNA").child(self.CmyID2).child("Task").child("\(typelist[indexPath.row].typeAry!)").observe(.childAdded, with: { (snapshot) in
                    
                    let task = event()
                    task.mission = snapshot.key
                    
                    tasklist.append(task)
                    self.taskTBV.reloadData()
                    
                }, withCancel: nil)
            }
        }
        else{
            if isSeaching{
                if (searchTaskBar.text?.isEmpty)!{
                    if selectBottom.titleLabel?.text == "請選擇類型"{
                        
                        let detailpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionP2") as? C_TaskInstructionP2
                        detailpage?.Cmyname = tasklist[indexPath.row].mission
                        detailpage?.Cmytype = tasklist[indexPath.row].url
                        self.present(detailpage!, animated: true, completion: nil)
                    }
                    else{
                        let detailpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionP2") as? C_TaskInstructionP2
                        detailpage?.Cmyname = tasklist[indexPath.row].mission
                        detailpage?.Cmytype = (selectBottom.titleLabel?.text)!
                        self.present(detailpage!, animated: true, completion: nil)
                    }
                }else{
                    if selectBottom.titleLabel?.text == "請選擇類型"{
                        let detailpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionP2") as? C_TaskInstructionP2
                        detailpage?.Cmyname = searchtask[indexPath.row].mission
                        detailpage?.Cmytype = searchtask[indexPath.row].url
                        self.present(detailpage!, animated: true, completion: nil)
                    }
                    else{
                        let detailpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionP2") as? C_TaskInstructionP2
                        detailpage?.Cmyname = searchtask[indexPath.row].mission
                        detailpage?.Cmytype = (selectBottom.titleLabel?.text)!
                        self.present(detailpage!, animated: true, completion: nil)
                    }
                }
            }
            else{
                if selectBottom.titleLabel?.text == "請選擇類型"{
                    
                    let detailpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionP2") as? C_TaskInstructionP2
                    detailpage?.Cmyname = tasklist[indexPath.row].mission
                    detailpage?.Cmytype = tasklist[indexPath.row].url
                    self.present(detailpage!, animated: true, completion: nil)
                }
                else{
                    let detailpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionP2") as? C_TaskInstructionP2
                    detailpage?.Cmyname = tasklist[indexPath.row].mission
                    detailpage?.Cmytype = (selectBottom.titleLabel?.text)!
                    self.present(detailpage!, animated: true, completion: nil)
                }
            }
        }
    }
    
    //SelectType bottom
    @IBOutlet weak var selectBottom: UIButton!
    @IBAction func clickonBottom(_ sender: UIButton) {
        if typeTBV.isHidden == true{
            UIView.animate(withDuration: 0.3) {
                self.typeTBV.isHidden = false
            }
        }
        else{
            UIView.animate(withDuration: 0.3) {
                self.typeTBV.isHidden = true
            }
        }
        
    }
    
    //tableviewcell data fetching
    @IBOutlet weak var typeTBV: UITableView!
    @IBOutlet weak var taskTBV: UITableView!
    func fetchTask() {
        Database.database().reference().child("CNA").child(CmyID2).child("Task").observe(.childAdded, with: { (snapshot1) in
            if snapshot1.hasChildren(){
                for snap in snapshot1.children{
                    if let node = snap as? DataSnapshot{
                        let tag = node.key
                        
                        let tasks = event()
                        tasks.mission = tag
                        tasks.url = snapshot1.key
                        
                        
                        tasklist.append(tasks)
                        self.taskTBV.reloadData()
                        
                    }
                }
            }
        }, withCancel: nil)
    }
    func fetchType() {
        Database.database().reference().child("CNA").child(CmyID2).child("Task").observe(.childAdded, with: { (snapshot) in
            let types = typeAry2()
            types.typeAry = snapshot.key
            
            typelist.append(types)
            self.typeTBV.reloadData()
        }, withCancel: nil)
    }
    
    
    
    //searchbar
    var searchtask = [event]()
    var isSeaching = false
    @IBOutlet weak var searchTaskBar: UISearchBar!
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isSeaching = true
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        isSeaching = false
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        isSeaching = false
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else{
            searchtask = tasklist
            taskTBV.reloadData()
            return
        }
        searchtask = tasklist.filter({ (tasktypein) -> Bool in
            guard let text = searchBar.text?.lowercased() else {return false}
            return tasktypein.mission.lowercased().contains(text.lowercased())
        })
        taskTBV.reloadData()
    }
    
    //cancel bottom
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSeaching = false
        searchBar.text = ""
        
        searchTaskBar.endEditing(true)
        
        taskTBV.reloadData()
    }
    
    
    
    
    //homeIcon
    @IBAction func homeIcon(_ sender: UIButton) {
        let CNAhomepage = storyboard?.instantiateViewController(withIdentifier: "C_CNAVC") as? C_CNAVC
        CNAhomepage?.CmyID = self.CmyID2
        self.present(CNAhomepage!, animated: false, completion: nil)
    }
    
    //hamburgerIcon
    @IBOutlet weak var HBpage: UIStackView!
    @IBAction func HamburgerPageIcon(_ sender: UIButton) {
        if(HBpage.isHidden == true){
            let transition = CATransition()
            transition.duration = 0.15
            self.HBpage.window!.layer.add(transition, forKey: kCATransition)
            
            HBpage.isHidden = false
        }
        else{
            HBpage.isHidden = true
        }
    }
    @IBAction func Portfolio(_ sender: UIButton) {
        let portfoliopage = storyboard?.instantiateViewController(withIdentifier: "C_PortolioVC") as? C_PortolioVC
        portfoliopage?.CmyID1 = self.CmyID2
        self.present(portfoliopage!, animated: false, completion: nil)
    }
    @IBAction func Task(_ sender: UIButton) {
        let taskpage = storyboard?.instantiateViewController(withIdentifier: "C_TaskInstructionVC") as? C_TaskInstructionVC
        taskpage?.CmyID2 = self.CmyID2
        self.present(taskpage!, animated: false, completion: nil)
    }
    @IBAction func workingschedule(_ sender: UIButton) {
        let workingschedulepage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingScheduleVC") as? C_WorkingScheduleVC
        workingschedulepage?.CmyID3 = self.CmyID2
        self.present(workingschedulepage!, animated: false, completion: nil)
    }
    @IBAction func workinghour(_ sender: UIButton) {
        let workinghourpage = storyboard?.instantiateViewController(withIdentifier: "C_WorkingHourVC") as? C_WorkingHourVC
        workinghourpage?.CmyID4 = self.CmyID2
        self.present(workinghourpage!, animated: false, completion: nil)
    }
    @IBAction func aboutus(_ sender: UIButton) {
        let aboutuspage = storyboard?.instantiateViewController(withIdentifier: "C_CNAAboutUsVC") as? C_CNAAboutUsVC
        aboutuspage?.CCNAAboutmyID = self.CmyID2
        self.present(aboutuspage!, animated: false, completion: nil)
    }
    
    
    //help & support
    @IBAction func help(_ sender: UIButton) {
        let helpmenu = storyboard?.instantiateViewController(withIdentifier: "C_help_supportVC") as? C_help_supportVC
        helpmenu?.ChelpID = self.CmyID2
        self.present(helpmenu!, animated: false, completion: nil)
    }
    
    //logoutIcon
    @IBAction func logoutIcon(_ sender: UIButton) {
        if UserDefaults.standard.bool(forKey: "test") == true{
            UserDefaults.standard.set(false, forKey: "test")
        }
        UserDefaults.standard.set(false, forKey: "AutoLoginCNA")
        UserDefaults.standard.set(false, forKey: "AutoLoginON")
        DoubleConfirm(userMessage: "確定要登出？")
    }
    func DoubleConfirm(userMessage:String){
        
        let login = storyboard?.instantiateViewController(withIdentifier: "C_LoginVC")
        
        let confirm = UIAlertController(title: nil, message: userMessage, preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
        //換到 LoginPage
        confirm.addAction(UIAlertAction(title: "確認", style: .default, handler:{(action) in
            
            let formatter1 = DateFormatter()
            formatter1.dateFormat = "yyyy-MM-dd"
            let str = formatter1.string(from: Date())
            
            let formatter2 = DateFormatter()
            formatter2.dateFormat = "HH:mm:ss"
            let str2 = formatter2.string(from: Date())
            
            Database.database().reference().child("AccountStatus").child("App").child(self.CmyID2).child("LogoutHistory").child("\(str)").child("\(str2)").setValue("True")
            Database.database().reference().child("AccountStatus").child("App").child(self.CmyID2).child("LatestLogout").setValue("\(str)-\(str2)")
            self.present(login!, animated: true, completion:    nil)}))
        present(confirm, animated: true, completion: nil)
    }
    
    
    var CmyID2 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tasklist.removeAll()
        fetchTask()
        typelist.removeAll()
        fetchType()
        
    }
}
