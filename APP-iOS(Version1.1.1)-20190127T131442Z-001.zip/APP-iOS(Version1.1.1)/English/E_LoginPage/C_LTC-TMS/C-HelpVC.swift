//
//  C-HelpVC.swift
//  LTC-TMS
//
//  Created by 林庭鋒 on 2018/11/20.
//  Copyright © 2018 TingFeng. All rights reserved.
//

import UIKit
import FirebaseDatabase

class C_HelpVC: UIViewController, UITextViewDelegate {

    //checkboxs
    @IBOutlet weak var centerCheckBox: UIButton!
    @IBOutlet weak var systemCheckBox: UIButton!
    @IBAction func clickCenter(_ sender: UIButton) {
        if centerCheckBox.isSelected{
            centerCheckBox.isSelected = true
        }else{
            centerCheckBox.isSelected = true
            systemCheckBox.isSelected = false
        }
    }
    @IBAction func clickSystem(_ sender: UIButton) {
        if systemCheckBox.isSelected{
            systemCheckBox.isSelected = true
        }else{
            systemCheckBox.isSelected = true
            centerCheckBox.isSelected = false
        }
    }
    
    
    //feedback ID
    @IBOutlet weak var feedbackID: UILabel!
    
    
    //submit button
    @IBAction func Submit(_ sender: UIButton) {
        
        let formatter1 = DateFormatter()
        formatter1.dateFormat = "yyyy-M-d"
        let str = formatter1.string(from: Date())
        
        let formatter2 = DateFormatter()
        formatter2.dateFormat = "HH:mm:ss"
        let str2 = formatter2.string(from: Date())
        
        if feedbackField.text == "歡迎留下任何意見與問題。" || feedbackField.text.isEmpty == true{
            let failmessage = UIAlertController(title: "提示", message: "尚未輸入任何意見。", preferredStyle: .alert)
            let ok = UIAlertAction(title: "了解", style: .default, handler: nil)
            failmessage.addAction(ok)
            self.present(failmessage, animated: true, completion: nil)
        }else{
            
            if centerCheckBox.isSelected{
                let alert = UIAlertController(title: "提示", message: "確定要提交？", preferredStyle: .alert)
                let cancelaction = UIAlertAction(title: "取消", style: .default, handler: nil)
                let okaction = UIAlertAction(title: "確認", style: .default, handler: {(action) in
                    
                    let x = Int((self.feedbackID.text!).replacingOccurrences(of: "\"", with: ""))! + 1
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("Center").child(str).child("ID-\(x)").child("Received").child(str2).setValue("\"\(String(describing: (self.feedbackField.text)!))\"")
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("Center").child(str).child("ID-\(x)").child("Replied").child(" ").setValue(" ")
                    
                    
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("TimesOfFeedback").setValue("\(x)")
                    
                    self.alertMessage(userMessage: "感謝您的回饋。")
                    
                })
                alert.addAction(cancelaction)
                alert.addAction(okaction)
                self.present(alert, animated: true, completion: nil)
            }
            else{
                let alert = UIAlertController(title: "提示", message: "確定要提交？", preferredStyle: .alert)
                let cancelaction = UIAlertAction(title: "取消", style: .default, handler: nil)
                let okaction = UIAlertAction(title: "確認", style: .default, handler: {(action) in
                    
                    let x = Int((self.feedbackID.text!).replacingOccurrences(of: "\"", with: ""))! + 1
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("System").child(str).child("ID-\(x)").child("Received").child(str2).setValue("\"\(String(describing: (self.feedbackField.text)!))\"")
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("System").child(str).child("ID-\(x)").child("Replied").child(" ").setValue(" ")
                    
                    Database.database().reference().child("Feedback").child(self.UID.text!).child("TimesOfFeedback").setValue("\(x)")
                    
                    self.alertMessage(userMessage: "感謝您的回饋。")
                    
                })
                alert.addAction(cancelaction)
                alert.addAction(okaction)
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func alertMessage(userMessage: String){
        let alert2 = UIAlertController(title: "成功", message: userMessage, preferredStyle: .alert)
        let thanks = UIAlertAction(title: "完成", style: .default) { (action) in
            self.dismiss(animated: true, completion: nil)
        }
        alert2.addAction(thanks)
        self.present(alert2, animated: true, completion: nil)
    }
    
    
    
    //dismiss VC
    @IBAction func Done(_ sender: Any) {
        if feedbackField.text.isEmpty == true || feedbackField.text == "歡迎留下任何意見與問題。"{
            dismiss(animated: true, completion: nil)
        }else{
            let alert = UIAlertController(title: "提示", message: "尚未提交您的回饋，確定要離開？", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "取消", style: .default, handler: nil))
            alert.addAction(UIAlertAction(title: "離開", style: .default, handler: { (action) in
                self.dismiss(animated: true, completion: nil)
            }))
            present(alert, animated: true, completion: nil)
        }
        
    }
    
    //keyboard down
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        feedbackField.endEditing(true)
    }
    
    @IBOutlet weak var feedbackField: UITextView!
    @IBOutlet weak var UID: UILabel!
    var CmyID6 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UID.text = CmyID6
        
        //feedbackID
        Database.database().reference().child("Feedback").observe(.childAdded, with: { (snapshot) in
            if snapshot.key == self.UID.text{
                Database.database().reference().child("Feedback").child(self.UID.text!).child("TimesOfFeedback").observe(.value, with: { (snapshot1) in
                    self.feedbackID.text = "\(String(describing: (snapshot1.value as! String).replacingOccurrences(of: "\"", with: "")))"
                    
                }, withCancel: nil)
            }
        }, withCancel: nil)
        
        
        //placeholder
        feedbackField.text = "歡迎留下任何意見與問題。"
        feedbackField.textColor = UIColor.lightGray
        feedbackField.delegate = self
    }
    
    
    
    //placeholder
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == "歡迎留下任何意見與問題。"{
            textView.text = ""
            textView.textColor = UIColor.black
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text == ""{
            textView.text = "歡迎留下任何意見與問題。"
            textView.textColor = UIColor.lightGray
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}
